"""Breakout detection: multiple methods to identify breakout conditions.

Combines volume breakouts, price range breakouts, momentum surges, and
order-flow imbalance spikes into a unified breakout score per symbol.
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field

from learning.pretrain import BreakoutProfile
from typing import Deque, Dict, List, Optional, Tuple


@dataclass
class BreakoutState:
    """Rolling state for one symbol's breakout detection."""
    prices: Deque[float] = field(default_factory=lambda: deque(maxlen=200))
    volumes: Deque[float] = field(default_factory=lambda: deque(maxlen=200))
    highs: Deque[float] = field(default_factory=lambda: deque(maxlen=200))
    lows: Deque[float] = field(default_factory=lambda: deque(maxlen=200))
    spreads: Deque[float] = field(default_factory=lambda: deque(maxlen=100))
    ofi_history: Deque[float] = field(default_factory=lambda: deque(maxlen=100))
    last_breakout_score: float = 0.0
    last_direction: int = 0  # 1=bullish, -1=bearish, 0=none
    cooldown_until: float = 0.0


def _std(vals: List[float]) -> float:
    if len(vals) < 2:
        return 0.0
    mu = sum(vals) / len(vals)
    var = sum((x - mu) ** 2 for x in vals) / (len(vals) - 1)
    return math.sqrt(max(0.0, var))


def _rolling_high(highs: Deque[float], lookback: int) -> float:
    subset = list(highs)[-lookback:]
    return max(subset) if subset else 0.0


def _rolling_low(lows: Deque[float], lookback: int) -> float:
    subset = list(lows)[-lookback:]
    return min(subset) if subset else 0.0


class BreakoutDetector:
    """Multi-method breakout detection for a single symbol.

    Methods:
      1. Range breakout: price exceeds N-bar high/low by threshold
      2. Volume surge: current volume >> rolling average
      3. Volatility expansion: realized vol spike vs recent baseline
      4. OFI spike: order flow imbalance exceeds historical norm
      5. Momentum: consecutive same-direction moves

    Each method returns a component score [0..1]. The composite breakout
    score is a weighted blend. Direction is inferred from the dominant signals.
    """

    def __init__(
        self,
        range_lookback: int = 36,
        range_breakout_pct: float = 0.0015,
        volume_lookback: int = 50,
        volume_surge_mult: float = 2.0,
        vol_expand_lookback: int = 50,
        vol_expand_mult: float = 1.6,
        ofi_lookback: int = 40,
        ofi_z_threshold: float = 1.5,
        momentum_bars: int = 5,
        weights: Optional[Dict[str, float]] = None,
    ):
        self.range_lookback = range_lookback
        self.range_breakout_pct = range_breakout_pct
        self.volume_lookback = volume_lookback
        self.volume_surge_mult = volume_surge_mult
        self.vol_expand_lookback = vol_expand_lookback
        self.vol_expand_mult = vol_expand_mult
        self.ofi_lookback = ofi_lookback
        self.ofi_z_threshold = ofi_z_threshold
        self.momentum_bars = momentum_bars
        self.weights = weights or {
            "range": 0.30,
            "volume": 0.20,
            "vol_expand": 0.20,
            "ofi": 0.15,
            "momentum": 0.12,
            "profile": 0.03,
        }

    def update_and_score(
        self, state: BreakoutState, price: float, high: float, low: float,
        volume: float, spread_bps: float, ofi: float,
        profile: Optional[BreakoutProfile] = None,
    ) -> Tuple[float, int, Dict[str, float]]:
        """Push new data, return (composite_score, direction, component_scores)."""
        state.prices.append(price)
        state.highs.append(high)
        state.lows.append(low)
        state.volumes.append(volume)
        state.spreads.append(spread_bps)
        state.ofi_history.append(ofi)

        components: Dict[str, float] = {}
        directions: Dict[str, int] = {}

        # 1. Range breakout
        range_score, range_dir = self._range_breakout(state, price, profile=profile)
        components["range"] = range_score
        directions["range"] = range_dir

        # 2. Volume surge
        components["volume"] = self._volume_surge(state, profile=profile)
        directions["volume"] = 0  # volume is direction-neutral

        # 3. Volatility expansion
        components["vol_expand"] = self._vol_expansion(state, profile=profile)
        directions["vol_expand"] = 0

        # 4. OFI spike
        ofi_score, ofi_dir = self._ofi_spike(state, ofi, profile=profile)
        components["ofi"] = ofi_score
        directions["ofi"] = ofi_dir

        # 5. Momentum
        mom_score, mom_dir = self._momentum(state)
        components["momentum"] = mom_score
        directions["momentum"] = mom_dir

        if profile is not None:
            components["profile"] = max(0.0, min(1.0, profile.confidence))
            directions["profile"] = 0

        # Composite
        composite = sum(self.weights.get(k, 0.0) * v for k, v in components.items())
        composite = max(0.0, min(1.0, composite))

        # Direction: weighted vote from directional signals
        dir_vote = 0.0
        dir_weight_total = 0.0
        for k in ("range", "ofi", "momentum"):
            w = self.weights.get(k, 0.0) * components.get(k, 0.0)
            dir_vote += directions.get(k, 0) * w
            dir_weight_total += w
        direction = 0
        if dir_weight_total > 0.01:
            normalized = dir_vote / dir_weight_total
            if normalized > 0.2:
                direction = 1
            elif normalized < -0.2:
                direction = -1

        state.last_breakout_score = composite
        state.last_direction = direction
        return composite, direction, components

    def _range_breakout(self, state: BreakoutState, price: float, profile: Optional[BreakoutProfile] = None) -> Tuple[float, int]:
        if len(state.highs) < self.range_lookback + 1:
            return 0.0, 0
        # Use all-but-last bar for the range
        prev_highs = list(state.highs)[-(self.range_lookback + 1):-1]
        prev_lows = list(state.lows)[-(self.range_lookback + 1):-1]
        if not prev_highs:
            return 0.0, 0
        hi = max(prev_highs)
        lo = min(prev_lows)
        if hi <= 0:
            return 0.0, 0
        range_breakout_pct = profile.range_breakout_pct if profile is not None else self.range_breakout_pct
        thr_up = hi * (1.0 + range_breakout_pct)
        thr_dn = lo * (1.0 - range_breakout_pct)
        if price > thr_up:
            excess = (price - thr_up) / (hi * max(range_breakout_pct, 1e-9))
            return min(1.0, 0.5 + excess * 0.5), 1
        if price < thr_dn:
            excess = (thr_dn - price) / (lo * max(range_breakout_pct, 1e-9))
            return min(1.0, 0.5 + excess * 0.5), -1
        return 0.0, 0

    def _volume_surge(self, state: BreakoutState, profile: Optional[BreakoutProfile] = None) -> float:
        vols = list(state.volumes)
        if len(vols) < self.volume_lookback + 1:
            return 0.0
        baseline = vols[-(self.volume_lookback + 1):-1]
        avg_vol = sum(baseline) / len(baseline) if baseline else 0.0
        if avg_vol <= 0:
            return 0.0
        ratio = vols[-1] / avg_vol
        volume_surge_mult = profile.volume_surge_mult if profile is not None else self.volume_surge_mult
        if ratio >= volume_surge_mult:
            return min(1.0, (ratio - 1.0) / max(volume_surge_mult - 1.0, 0.5))
        return 0.0

    def _vol_expansion(self, state: BreakoutState, profile: Optional[BreakoutProfile] = None) -> float:
        prices = list(state.prices)
        if len(prices) < self.vol_expand_lookback + 10:
            return 0.0
        recent = prices[-10:]
        baseline = prices[-(self.vol_expand_lookback + 10):-10]
        from .breakout_detector import _std
        recent_vol = _std(recent)
        baseline_vol = _std(baseline)
        if baseline_vol <= 1e-12:
            return 0.0
        ratio = recent_vol / baseline_vol
        vol_expand_mult = profile.vol_expand_mult if profile is not None else self.vol_expand_mult
        if ratio >= vol_expand_mult:
            return min(1.0, (ratio - 1.0) / max(vol_expand_mult - 1.0, 0.5))
        return 0.0

    def _ofi_spike(self, state: BreakoutState, ofi: float, profile: Optional[BreakoutProfile] = None) -> Tuple[float, int]:
        history = list(state.ofi_history)
        if len(history) < self.ofi_lookback:
            return 0.0, 0
        baseline = history[-self.ofi_lookback:]
        mu = sum(baseline) / len(baseline)
        sd = _std(baseline)
        if sd <= 1e-9:
            return 0.0, 0
        z = (ofi - mu) / sd
        ofi_z_threshold = profile.ofi_z_threshold if profile is not None else self.ofi_z_threshold
        if abs(z) >= ofi_z_threshold:
            score = min(1.0, (abs(z) - ofi_z_threshold) / 2.0 + 0.5)
            direction = 1 if z > 0 else -1
            return score, direction
        return 0.0, 0

    def _momentum(self, state: BreakoutState) -> Tuple[float, int]:
        prices = list(state.prices)
        if len(prices) < self.momentum_bars + 1:
            return 0.0, 0
        recent = prices[-(self.momentum_bars + 1):]
        ups = sum(1 for a, b in zip(recent, recent[1:]) if b > a)
        downs = sum(1 for a, b in zip(recent, recent[1:]) if b < a)
        bars = self.momentum_bars
        if ups >= bars - 1:
            return min(1.0, ups / bars), 1
        if downs >= bars - 1:
            return min(1.0, downs / bars), -1
        return 0.0, 0
