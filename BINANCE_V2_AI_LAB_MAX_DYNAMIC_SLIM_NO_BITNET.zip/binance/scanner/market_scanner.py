"""Market scanner: continuously scan all tradable symbols, detect breakouts,
rank opportunities, and emit actionable signals for the orchestrator.

This scanner now uses a two-stage pipeline for speed:
  1. Fast bulk scan across all tradable symbols using cheap endpoints only
  2. Deep research scan only on the shortlisted candidates
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from research.client import PublicFuturesClient
from research.features import (
    SymbolSnapshot, build_snapshot, series_from_klines,
    safe_float,
)
from research.strategies import run_all_strategies
from research.optimizer import build_recommendation, SymbolRecommendation
from scanner.breakout_detector import BreakoutDetector, BreakoutState
from learning.pretrain import BreakoutProfile

LOG = logging.getLogger("aster.scanner")


@dataclass
class BreakoutSignal:
    """Emitted when a symbol meets breakout conditions."""
    symbol: str
    score: float          # 0..1 composite breakout score
    direction: int        # 1=LONG, -1=SHORT
    components: Dict[str, float]
    recommendation: Optional[SymbolRecommendation]
    snapshot: Optional[SymbolSnapshot]
    timestamp: float = 0.0

    def __post_init__(self):
        if self.timestamp <= 0:
            self.timestamp = time.time()


@dataclass
class ScannerConfig:
    """Configuration for the market scanner."""
    scan_interval_sec: float = 10.0       # fast bulk scan interval
    deep_scan_interval_sec: float = 30.0  # deep breakout scan over shortlist
    kline_interval: str = "5m"
    kline_limit: int = 200
    breakout_threshold: float = 0.45      # min composite score to emit signal
    min_quote_volume_24h: float = 1_000_000.0
    max_spread_bps: float = 25.0
    max_concurrent_symbols: int = 5       # max symbols traded at once
    cooldown_after_signal_sec: float = 120.0
    research_refresh_sec: float = 300.0   # full research re-run interval
    top_n_research: int = 30              # deep research shortlist size
    fast_candidate_limit: int = 20        # shortlist scanned for breakouts each pass
    min_fast_abs_momentum_bps: float = 0.5
    base_url: str = "https://fapi.asterdex.com"
    exclude_symbols: List[str] = field(default_factory=list)
    include_symbols: Optional[List[str]] = None  # None = all


@dataclass
class FastSymbolState:
    last_price: float = 0.0
    prev_price: float = 0.0
    spread_bps: float = 9999.0
    quote_volume_24h: float = 0.0
    bid_qty: float = 0.0
    ask_qty: float = 0.0
    momentum_bps: float = 0.0
    liquidity_score: float = 0.0
    spread_score: float = 0.0
    momentum_score: float = 0.0
    volume_score: float = 0.0
    fast_score: float = 0.0
    updated_ts: float = 0.0


class MarketScanner:
    """Background scanner that monitors all markets for breakout conditions.

    Workflow:
      1. Fast bulk scan (every scan_interval_sec)
         - Fetches current tickers + book data for all symbols
         - Computes cheap per-symbol scores and maintains shortlist
      2. Periodic deep research scan (every research_refresh_sec)
         - Fetches klines only for shortlisted symbols
         - Runs strategy sims and refreshes recommendations
      3. Deep breakout scan (every deep_scan_interval_sec)
         - Updates breakout detector on shortlist only
         - Emits BreakoutSignal when threshold exceeded
    """

    def __init__(self, config: ScannerConfig, on_signal: Optional[Callable[[BreakoutSignal], None]] = None):
        self.config = config
        self.on_signal = on_signal
        self.client = PublicFuturesClient(base_url=config.base_url)
        self.detector = BreakoutDetector()

        self._breakout_states: Dict[str, BreakoutState] = {}
        self._recommendations: Dict[str, SymbolRecommendation] = {}
        self._snapshots: Dict[str, SymbolSnapshot] = {}
        self._tradable_symbols: List[str] = []
        self._symbol_filters: Dict[str, Dict[str, Any]] = {}
        self._fast_states: Dict[str, FastSymbolState] = {}
        self._fast_candidates: List[str] = []
        self._breakout_profiles: Dict[str, BreakoutProfile] = {}

        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_research_ts: float = 0.0
        self._last_deep_scan_ts: float = 0.0

        self._recent_signals: List[BreakoutSignal] = []
        self._active_symbols: set = set()
        self._homeostatic_threshold_offset: float = 0.0
        self._homeostatic_cooldown_mult: float = 1.0
        self._homeostatic_max_concurrent_symbols: Optional[int] = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run_loop, name="MarketScanner", daemon=True)
        self._thread.start()
        LOG.info("MarketScanner started")

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=10)
        LOG.info("MarketScanner stopped")

    def get_signals(self, min_score: float = 0.0) -> List[BreakoutSignal]:
        with self._lock:
            return [s for s in self._recent_signals if s.score >= min_score]

    def pop_best_signal(self) -> Optional[BreakoutSignal]:
        with self._lock:
            max_active = self._homeostatic_max_concurrent_symbols or self.config.max_concurrent_symbols
            candidates = [
                s for s in self._recent_signals
                if s.symbol not in self._active_symbols
                and len(self._active_symbols) < max_active
            ]
            if not candidates:
                return None
            best = max(candidates, key=lambda s: s.score)
            self._recent_signals.remove(best)
            return best

    def mark_active(self, symbol: str) -> None:
        with self._lock:
            self._active_symbols.add(symbol)

    def mark_inactive(self, symbol: str) -> None:
        with self._lock:
            self._active_symbols.discard(symbol)

    def get_recommendation(self, symbol: str) -> Optional[SymbolRecommendation]:
        with self._lock:
            return self._recommendations.get(symbol)

    def get_snapshot(self, symbol: str) -> Optional[SymbolSnapshot]:
        with self._lock:
            return self._snapshots.get(symbol)

    def get_all_recommendations(self) -> Dict[str, SymbolRecommendation]:
        with self._lock:
            return dict(self._recommendations)

    def get_active_symbols(self) -> set:
        with self._lock:
            return set(self._active_symbols)

    def set_homeostatic_controls(
        self,
        threshold_offset: float = 0.0,
        cooldown_mult: float = 1.0,
        max_concurrent_symbols: Optional[int] = None,
    ) -> None:
        with self._lock:
            self._homeostatic_threshold_offset = float(threshold_offset)
            self._homeostatic_cooldown_mult = max(0.50, min(2.00, float(cooldown_mult)))
            self._homeostatic_max_concurrent_symbols = int(max_concurrent_symbols) if max_concurrent_symbols is not None else None

    def set_breakout_profiles(self, profiles: Dict[str, BreakoutProfile]) -> None:
        with self._lock:
            self._breakout_profiles = dict(profiles or {})
        if profiles:
            LOG.info("Loaded %d pretrain breakout profiles into scanner", len(profiles))

    def _run_loop(self) -> None:
        self._refresh_tradable_symbols()
        self._refresh_fast_market_snapshot()
        self._run_research_scan()

        while not self._stop_event.is_set():
            try:
                now = time.time()
                self._refresh_fast_market_snapshot()

                if now - self._last_research_ts >= self.config.research_refresh_sec:
                    self._run_research_scan()

                if now - self._last_deep_scan_ts >= self.config.deep_scan_interval_sec:
                    self._fast_tick_scan()
                    self._last_deep_scan_ts = now

                self._stop_event.wait(timeout=self.config.scan_interval_sec)
            except Exception as e:
                LOG.error("Scanner loop error: %s", e, exc_info=True)
                self._stop_event.wait(timeout=5.0)

    def _refresh_tradable_symbols(self) -> None:
        info = self.client.exchange_info()
        symbols_raw = info.get("symbols", []) if isinstance(info, dict) else []
        tradable = []
        for s in symbols_raw:
            sym = s.get("symbol", "")
            if s.get("status") != "TRADING":
                continue
            if s.get("contractType") != "PERPETUAL":
                continue
            if s.get("quoteAsset") != "USDT":
                continue
            if sym in self.config.exclude_symbols:
                continue
            if self.config.include_symbols and sym not in self.config.include_symbols:
                continue
            tradable.append(sym)
            filters = {}
            for f_ in s.get("filters", []):
                if f_.get("filterType") == "LOT_SIZE":
                    filters["min_qty"] = safe_float(f_.get("minQty"), 0.001)
                    filters["qty_step"] = safe_float(f_.get("stepSize"), 0.001)
                if f_.get("filterType") in ("PRICE_FILTER", "PRICE"):
                    filters["price_tick"] = safe_float(f_.get("tickSize"), 0.0001)
            self._symbol_filters[sym] = filters

        with self._lock:
            self._tradable_symbols = tradable
        LOG.info("Scanner found %d tradable symbols", len(tradable))

    def _refresh_fast_market_snapshot(self) -> None:
        symbols = self._tradable_symbols[:]
        if not symbols:
            return

        tickers = {x.get("symbol"): x for x in self.client.tickers_24h() if isinstance(x, dict)}
        books = {x.get("symbol"): x for x in self.client.book_tickers() if isinstance(x, dict)}
        now = time.time()
        ranked: List[tuple[float, str]] = []

        for sym in symbols:
            try:
                t = tickers.get(sym, {})
                b = books.get(sym, {})
                last_price = safe_float(t.get("lastPrice"))
                qv = safe_float(t.get("quoteVolume"))
                bid = safe_float(b.get("bidPrice"))
                ask = safe_float(b.get("askPrice"))
                bid_qty = safe_float(b.get("bidQty"))
                ask_qty = safe_float(b.get("askQty"))
                mid = (bid + ask) / 2.0 if bid > 0 and ask > 0 else last_price
                spread_bps = ((ask - bid) / mid * 10000.0) if mid > 0 and bid > 0 and ask > 0 else 9999.0
                if mid <= 0 or qv < self.config.min_quote_volume_24h or spread_bps > self.config.max_spread_bps:
                    continue

                fs = self._fast_states.get(sym)
                if fs is None:
                    fs = FastSymbolState()
                    self._fast_states[sym] = fs
                fs.prev_price = fs.last_price if fs.last_price > 0 else mid
                fs.last_price = mid
                fs.spread_bps = spread_bps
                fs.quote_volume_24h = qv
                fs.bid_qty = bid_qty
                fs.ask_qty = ask_qty
                fs.updated_ts = now
                fs.momentum_bps = ((fs.last_price - fs.prev_price) / fs.prev_price * 10000.0) if fs.prev_price > 0 else 0.0

                liquidity_score = min(1.0, qv / 100_000_000.0)
                spread_score = max(0.0, 1.0 - (spread_bps / max(self.config.max_spread_bps, 1.0)))
                momentum_abs = abs(fs.momentum_bps)
                momentum_score = min(1.0, momentum_abs / 12.0)
                volume_score = min(1.0, (bid_qty + ask_qty) / 50_000.0)
                fs.liquidity_score = liquidity_score
                fs.spread_score = spread_score
                fs.momentum_score = momentum_score
                fs.volume_score = volume_score
                fs.fast_score = (
                    liquidity_score * 0.35 +
                    momentum_score * 0.35 +
                    spread_score * 0.20 +
                    volume_score * 0.10
                )

                if momentum_abs >= self.config.min_fast_abs_momentum_bps:
                    ranked.append((fs.fast_score, sym))

                if sym not in self._breakout_states:
                    self._breakout_states[sym] = BreakoutState()
                bs = self._breakout_states[sym]
                bs.prices.append(mid)
                bs.highs.append(max(mid, bs.highs[-1]) if bs.highs else mid)
                bs.lows.append(min(mid, bs.lows[-1]) if bs.lows else mid)
                bs.volumes.append(max(bid_qty + ask_qty, 0.0))
                bs.spreads.append(spread_bps)
                total = bid_qty + ask_qty
                bs.ofi_history.append((bid_qty - ask_qty) / total if total > 0 else 0.0)
            except Exception as e:
                LOG.debug("Fast snapshot error for %s: %s", sym, e)

        ranked.sort(reverse=True)
        candidates = [sym for _, sym in ranked[:max(self.config.top_n_research, self.config.fast_candidate_limit)]]
        with self._lock:
            self._fast_candidates = candidates
        if candidates:
            LOG.debug("Fast scan shortlisted %d symbols", len(candidates))

    def _run_research_scan(self) -> None:
        self._last_research_ts = time.time()
        symbols = self._fast_candidates[:]
        if not symbols:
            self._refresh_fast_market_snapshot()
            symbols = self._fast_candidates[:]
        if not symbols:
            return

        LOG.info("Research scan: analyzing %d shortlisted symbols", len(symbols))
        tickers24 = {x.get("symbol"): x for x in self.client.tickers_24h() if isinstance(x, dict)}
        books = {x.get("symbol"): x for x in self.client.book_tickers() if isinstance(x, dict)}
        premium = {x.get("symbol"): x for x in self.client.premium_index() if isinstance(x, dict)}
        funding_cfg = {x.get("symbol"): x for x in self.client.funding_info() if isinstance(x, dict)}

        new_recs: Dict[str, SymbolRecommendation] = {}
        new_snaps: Dict[str, SymbolSnapshot] = {}

        for sym in symbols[:self.config.top_n_research]:
            try:
                t24 = tickers24.get(sym, {})
                qv = safe_float(t24.get("quoteVolume"))
                if qv < self.config.min_quote_volume_24h:
                    continue

                kl = self.client.klines(sym, interval=self.config.kline_interval, limit=self.config.kline_limit)
                candles = series_from_klines(kl)
                if len(candles.close) < 60:
                    continue

                snapshot = build_snapshot(
                    symbol=sym,
                    ticker24=t24,
                    book_ticker=books.get(sym, {}),
                    premium=premium.get(sym, {}),
                    funding_cfg=funding_cfg.get(sym, {}),
                    candles=candles,
                )
                if snapshot is None or snapshot.spread_bps > self.config.max_spread_bps:
                    continue

                results = run_all_strategies(candles)
                rec = build_recommendation(snapshot, results)
                new_recs[sym] = rec
                new_snaps[sym] = snapshot

                if sym not in self._breakout_states:
                    self._breakout_states[sym] = BreakoutState()
                bs = self._breakout_states[sym]
                bs.prices.clear(); bs.highs.clear(); bs.lows.clear(); bs.volumes.clear()
                for i in range(len(candles.close)):
                    bs.prices.append(candles.close[i])
                    bs.highs.append(candles.high[i])
                    bs.lows.append(candles.low[i])
                    bs.volumes.append(candles.quote_volume[i] if candles.quote_volume else candles.volume[i])
                time.sleep(0.01)
            except Exception as e:
                LOG.debug("Research scan failed for %s: %s", sym, e)

        with self._lock:
            self._recommendations = new_recs
            self._snapshots = new_snaps
        LOG.info(
            "Research scan complete: %d symbols profiled, top scorers: %s",
            len(new_recs),
            ", ".join(r.symbol for r in sorted(new_recs.values(), key=lambda x: x.score, reverse=True)[:5])
        )

    def _fast_tick_scan(self) -> None:
        recs = self._recommendations.copy()
        candidates = self._fast_candidates[:self.config.fast_candidate_limit]
        if not recs or not candidates:
            return

        now = time.time()
        new_signals: List[BreakoutSignal] = []
        for sym in candidates:
            rec = recs.get(sym)
            fs = self._fast_states.get(sym)
            if rec is None or fs is None:
                continue
            try:
                price = fs.last_price
                spread_bps = fs.spread_bps
                if price <= 0 or spread_bps > self.config.max_spread_bps:
                    continue
                bid_qty = fs.bid_qty
                ask_qty = fs.ask_qty
                total = bid_qty + ask_qty
                ofi = (bid_qty - ask_qty) / total if total > 0 else 0.0
                volume_proxy = total if total > 0 else fs.quote_volume_24h / 1440.0

                bs = self._breakout_states.setdefault(sym, BreakoutState())
                if now < bs.cooldown_until:
                    continue
                high = max(price, max(bs.highs) if bs.highs else price)
                low = min(price, min(bs.lows) if bs.lows else price)
                profile = self._breakout_profiles.get(sym)
                score, direction, components = self.detector.update_and_score(
                    bs, price, high, low, volume_proxy, spread_bps, ofi, profile=profile
                )

                research_boost = max(0.0, min(0.3, rec.score * 0.1))
                fast_boost = max(0.0, min(0.2, fs.fast_score * 0.2))
                profile_boost = 0.0
                final_threshold = self.config.breakout_threshold + self._homeostatic_threshold_offset
                cooldown_mult = self._homeostatic_cooldown_mult
                if profile is not None:
                    profile_boost = max(0.0, min(0.08, profile.confidence * 0.08))
                    final_threshold = max(0.25, min(0.80, self.config.breakout_threshold + profile.score_bias))
                    cooldown_mult = max(0.75, min(1.20, profile.cooldown_mult))
                    components["profile_conf"] = profile.confidence
                    components["profile_bias"] = profile.score_bias
                final_score = min(1.0, score + research_boost + fast_boost + profile_boost)
                if final_score >= final_threshold and direction != 0:
                    signal = BreakoutSignal(
                        symbol=sym,
                        score=final_score,
                        direction=direction,
                        components={**components, "fast": fs.fast_score},
                        recommendation=rec,
                        snapshot=self._snapshots.get(sym),
                    )
                    new_signals.append(signal)
                    bs.cooldown_until = now + (self.config.cooldown_after_signal_sec * cooldown_mult)
                    LOG.info(
                        "BREAKOUT SIGNAL: %s score=%.3f thr=%.3f dir=%s components=%s",
                        sym, final_score, final_threshold, "LONG" if direction > 0 else "SHORT",
                        {k: f"{v:.3f}" for k, v in signal.components.items()}
                    )
            except Exception as e:
                LOG.debug("Fast scan error for %s: %s", sym, e)

        if new_signals:
            new_signals.sort(key=lambda s: s.score, reverse=True)
            with self._lock:
                self._recent_signals.extend(new_signals)
                cutoff = now - 300.0
                self._recent_signals = [s for s in self._recent_signals if s.timestamp > cutoff]
                self._recent_signals.sort(key=lambda s: s.score, reverse=True)
                self._recent_signals = self._recent_signals[:20]

            if self.on_signal:
                for sig in new_signals:
                    try:
                        self.on_signal(sig)
                    except Exception as e:
                        LOG.error("Signal callback error: %s", e)
