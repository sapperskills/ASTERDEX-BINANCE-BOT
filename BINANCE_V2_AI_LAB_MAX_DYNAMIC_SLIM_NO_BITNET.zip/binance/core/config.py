"""Config dataclass + JSON loader. Add new params here — they auto-load from config.json."""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

LOG = logging.getLogger("aster")


@dataclass
class Config:
    # --- MODE ---
    SIMULATION_MODE: bool = False
    LIVE_PROFILE: bool = True

    # --- AUTH / ENDPOINTS ---
    API_KEY: str = ""
    API_SECRET: str = ""
    SYMBOL: str = "BTCUSDT"
    BASE_URL: str = "https://fapi.asterdex.com"
    EXCHANGE: str = ""  # auto-detected from BASE_URL if empty: "aster" or "binance"

    # --- RECONCILE ---
    RECONCILE_ENABLE: bool = True
    RECONCILE_EVERY_SEC: float = 1.0
    RECONCILE_CANCEL_OPEN_ORDERS_ON_MISMATCH: bool = True
    RECONCILE_CANCEL_OPEN_ORDERS_ON_ADOPT: bool = True
    RECONCILE_MIN_QTY_EPS: Decimal = Decimal("0.00000001")

    # --- LEVERAGE / SIZING ---
    LEVERAGE: int = 25
    USE_MARGIN_TARGET: bool = True
    TARGET_MARGIN_USDT: Decimal = Decimal("80")
    TARGET_NOTIONAL_USDT: Decimal = Decimal("2000")
    MAX_MARGIN_FRACTION_OF_AVAILABLE: Decimal = Decimal("0.75")
    NOTIONAL_SAFETY_MULT: Decimal = Decimal("0.97")

    # --- EXECUTION ---
    MAKER_ONLY_ENTRY: bool = True
    MAKER_ONLY_EXIT: bool = True
    MAKER_REPRICE_SLEEP: float = 0.28
    MAKER_ENTRY_LIFE_SEC: float = 10.0
    MAKER_EXIT_LIFE_SEC: float = 12.0
    ENTRY_MAX_SECONDS_TOTAL: float = 22.0
    EXIT_MAX_SECONDS_TOTAL: float = 30.0
    EXIT_FORCE_COMPLETE: bool = False
    ENTRY_ALLOW_IOC_ESCALATION: bool = False
    EXIT_ALLOW_IOC_ESCALATION: bool = True
    HARDSTOP_IOC_LIFE_SEC: float = 0.8
    IOC_EMERGENCY_SLIPPAGE_TICKS: int = 3
    MAX_CONSEC_BAD_ORDER_ATTEMPTS: int = 5
    BAD_ORDER_COOLDOWN_SEC: float = 8.0

    # --- MARKET DATA ---
    DEPTH_LIMIT: int = 1000
    DEPTH_CACHE_SEC: float = 0.35
    ACCOUNT_CACHE_SEC: float = 1.8

    # --- SIGNAL WINDOW ---
    MA_LENGTH: int = 21
    MA_SLOPE_LEN: int = 10
    VOL_ROLL_LEN: int = 90

    # --- WALL BAND ---
    WALL_BAND_BPS_DEFAULT: Decimal = Decimal("25")
    WALL_BAND_BPS_MIN: Decimal = Decimal("12")
    WALL_BAND_BPS_MAX: Decimal = Decimal("100")

    # --- QUALITY GATES ---
    MAX_SPREAD_BPS: Decimal = Decimal("11.0")
    MIN_WALL_TOTAL: Decimal = Decimal("300000")
    MIN_VOL_BPS: Decimal = Decimal("1.2")
    MAX_VOL_BPS: Decimal = Decimal("800")
    VOL_EXPAND_MULT: Decimal = Decimal("1.10")

    # --- CALIBRATION ---
    CALIB_ENABLE: bool = True
    CALIB_WARMUP_SAMPLES: int = 250
    CALIB_WARMUP_SAMPLES_PRETRAINED: int = 140
    CALIB_WARMUP_SAMPLES_PROFILE_REFRESH: int = 100
    CALIB_SPREAD_PCT: float = 90.0
    CALIB_WALL_PCT: float = 32.0
    CALIB_VOL_MIN_PCT: float = 22.0
    CALIB_VOL_MED_PCT: float = 50.0
    CALIB_VOL_EXPAND_MULT: Decimal = Decimal("1.08")
    CALIB_WALL_BAND_FROM_VOL: bool = True

    # --- COSTS ---
    TAKER_FEE_RATE: Decimal = Decimal("0.0004")
    MAKER_FEE_RATE: Decimal = Decimal("0.0002")

    # --- ATR ---
    ATR_LEN: int = 24
    ATR_MIN_PRICE: Decimal = Decimal("0.00000001")

    # --- TP/SL ---
    ENFORCE_CONFIG_TPSL: bool = True
    TP_USD_FIXED: Decimal = Decimal("7.00")
    SL_USD_FIXED: Decimal = Decimal("6.50")
    TP_USD_FLOOR: Decimal = Decimal("7.00")
    SL_USD_FLOOR: Decimal = Decimal("6.50")
    TP_ATR_MULT: Decimal = Decimal("2.35")
    SL_ATR_MULT: Decimal = Decimal("1.45")
    HARD_SL_MULT: Decimal = Decimal("1.80")

    # --- TRAILING ---
    BE_LOCK_COST_MULT: Decimal = Decimal("1.00")
    TRAIL_START_FRAC_TP: Decimal = Decimal("0.45")
    TRAIL_ATR_GAP_MULT: Decimal = Decimal("0.80")
    BREAK_EVEN_AFTER_FRAC_TP: Decimal = Decimal("0.35")

    # --- EXIT ENGINE ---
    MAX_HOLD_SEC: float = 240.0
    STAGNATION_HOLD_SEC: float = 45.0
    STAGNATION_MIN_UNREAL_USD: Decimal = Decimal("0.30")
    REVERSAL_EXIT_ON_OFI: bool = True

    # --- DYNAMIC TP/SL ---
    DYN_TPSL_ENABLE: bool = False
    DYN_TPSL_REFRESH_SEC: float = 2.2
    DYN_TP_WIDEN_MAX_MULT: Decimal = Decimal("1.70")
    DYN_SL_MIN_TIGHTEN_MULT: Decimal = Decimal("0.70")
    DYN_TP_WIDEN_MIN_STEP_USD: Decimal = Decimal("0.75")
    DYN_SL_TIGHTEN_MIN_STEP_USD: Decimal = Decimal("0.50")
    DYN_REQUIRE_HELD_SEC: float = 1.0

    # --- DECISION ---
    HEUR_OFI_MIN: Decimal = Decimal("0.070")
    HEUR_SLOPE_MIN: int = 1
    MIN_MODEL_EXAMPLES_TO_TRUST: int = 250
    MODEL_LONG_TH: float = 0.63
    MODEL_SHORT_TH: float = 0.37
    MODEL_MIN_CONF: float = 0.04
    ENTRY_CONFIRM_TICKS: int = 4
    ENTRY_QUALITY_MIN: float = 0.46

    # --- SAFETY ---
    KILL_SWITCH_FILE: str = "KILL.txt"
    COOLDOWN_AFTER_EXIT_SEC: float = 2.0
    COOLDOWN_AFTER_LOSS_SEC: float = 12.0
    MAX_DAILY_LOSS_USD: Decimal = Decimal("40")
    MAX_CONSEC_LOSSES: int = 5

    # --- LEARNING ---
    LEARN_HORIZON_TICKS: int = 90
    LEARN_LABEL_BPS_MIN: Decimal = Decimal("2.2")
    LEARN_TRAIN_EVERY: int = 100
    LEARN_LR: float = 0.018
    LEARN_L2: float = 0.0012
    LEARN_CLIP: float = 5.0

    # --- FILES (will be per-symbol at runtime) ---
    STATE_FILE: str = "aster_state.json"
    TRADE_LOG: str = "trades.csv"
    CENTRAL_LOG_JSONL: str = "central_log.jsonl"
    LEARNING_LOG_JSONL: str = "learning_log.jsonl"
    MODEL_FILE: str = "lr_model.json"
    PROFILE_FILE: str = "symbol_profile.json"

    # --- LOOP ---
    HEARTBEAT_SEC: float = 5.0
    LOOP_SLEEP: float = 0.20

    # --- SPAWN WARMUP ---
    PRETRAINED_MODEL_EXAMPLES: int = 100
    SIM_WARMUP_TICKS_COLD: int = 50
    SIM_WARMUP_TICKS_PRETRAINED: int = 25
    SIM_WARMUP_TICKS_PRETRAINED_PROFILED: int = 15
    LIVE_WARMUP_TICKS_COLD: int = 60
    LIVE_WARMUP_TICKS_PRETRAINED: int = 35
    LIVE_WARMUP_TICKS_PRETRAINED_PROFILED: int = 25

    # --- POPULATION / HOMEOSTASIS ---
    POP_TARGET_LIVE_MIN: int = 1
    POP_TARGET_LIVE_MAX: int = 3
    POP_TARGET_SIM_MIN: int = 3
    POP_TARGET_SIM_MAX: int = 8
    POP_HEALTHY_LIVE_WR: float = 0.52
    POP_HEALTHY_LIVE_PNL: float = 0.0
    POP_STRESS_LOSS_STREAK: int = 2
    POP_STRESS_LIVE_PNL: float = -10.0
    POP_UPDATE_INTERVAL_SEC: float = 15.0

    # --- AI LAB V2 ---
    AI_LAB_ENABLE: bool = True
    AI_LAB_INTERVAL_SEC: float = 120.0
    AI_LAB_MIN_TRADES_PER_SYMBOL: int = 6
    AI_LAB_PROMOTION_MIN_WINRATE: float = 0.55
    AI_LAB_REQUIRE_REGIME_FILTER: bool = True
    AI_LAB_SCORE_BOOST: float = 0.03

    # --- DASHBOARD WEB ---
    DASHBOARD_AUTOSTART: bool = True
    DASHBOARD_HOST: str = "127.0.0.1"
    DASHBOARD_PORT: int = 8765

    # --- HTTP ---
    HTTP_MAX_RETRIES: int = 3
    HTTP_BACKOFF_BASE: float = 0.30
    SIGNED_RECV_WINDOW: int = 60000


def per_symbol_paths(cfg: Config) -> None:
    """Prefix all file paths with the symbol name."""
    s = cfg.SYMBOL.strip().upper()
    cfg.STATE_FILE = f"{s}_state.json"
    cfg.TRADE_LOG = f"{s}_trades.csv"
    cfg.CENTRAL_LOG_JSONL = f"{s}_central_log.jsonl"
    cfg.LEARNING_LOG_JSONL = f"{s}_learning_log.jsonl"
    cfg.MODEL_FILE = f"{s}_lr_model.json"
    cfg.PROFILE_FILE = f"{s}_symbol_profile.json"


# ── JSON loader ──────────────────────────────────────────────────────────────
# Type maps — add new fields to Config AND the matching set below.

_DECIMAL_FIELDS = {
    "TARGET_MARGIN_USDT", "TARGET_NOTIONAL_USDT",
    "MAX_MARGIN_FRACTION_OF_AVAILABLE", "NOTIONAL_SAFETY_MULT",
    "WALL_BAND_BPS_DEFAULT", "WALL_BAND_BPS_MIN", "WALL_BAND_BPS_MAX",
    "MAX_SPREAD_BPS", "MIN_WALL_TOTAL", "MIN_VOL_BPS", "MAX_VOL_BPS",
    "VOL_EXPAND_MULT", "TAKER_FEE_RATE", "MAKER_FEE_RATE",
    "ATR_MIN_PRICE", "TP_USD_FIXED", "SL_USD_FIXED",
    "TP_USD_FLOOR", "SL_USD_FLOOR", "TP_ATR_MULT", "SL_ATR_MULT",
    "HARD_SL_MULT", "BE_LOCK_COST_MULT", "TRAIL_START_FRAC_TP",
    "BREAK_EVEN_AFTER_FRAC_TP",
    "STAGNATION_MIN_UNREAL_USD",
    "TRAIL_ATR_GAP_MULT", "DYN_TP_WIDEN_MAX_MULT", "DYN_SL_MIN_TIGHTEN_MULT",
    "DYN_TP_WIDEN_MIN_STEP_USD", "DYN_SL_TIGHTEN_MIN_STEP_USD",
    "HEUR_OFI_MIN", "MAX_DAILY_LOSS_USD", "LEARN_LABEL_BPS_MIN",
    "CALIB_VOL_EXPAND_MULT", "RECONCILE_MIN_QTY_EPS",
}

_INT_FIELDS = {
    "LEVERAGE", "DEPTH_LIMIT", "MA_LENGTH", "MA_SLOPE_LEN", "VOL_ROLL_LEN",
    "ATR_LEN", "ENTRY_CONFIRM_TICKS", "HEUR_SLOPE_MIN",
    "MIN_MODEL_EXAMPLES_TO_TRUST", "MAX_CONSEC_LOSSES",
    "MAX_CONSEC_BAD_ORDER_ATTEMPTS", "IOC_EMERGENCY_SLIPPAGE_TICKS",
    "LEARN_HORIZON_TICKS", "LEARN_TRAIN_EVERY",
    "CALIB_WARMUP_SAMPLES", "CALIB_WARMUP_SAMPLES_PRETRAINED",
    "CALIB_WARMUP_SAMPLES_PROFILE_REFRESH", "HTTP_MAX_RETRIES", "SIGNED_RECV_WINDOW",
    "PRETRAINED_MODEL_EXAMPLES", "SIM_WARMUP_TICKS_COLD",
    "SIM_WARMUP_TICKS_PRETRAINED", "SIM_WARMUP_TICKS_PRETRAINED_PROFILED",
    "LIVE_WARMUP_TICKS_COLD", "LIVE_WARMUP_TICKS_PRETRAINED",
    "LIVE_WARMUP_TICKS_PRETRAINED_PROFILED",
    "POP_TARGET_LIVE_MIN", "POP_TARGET_LIVE_MAX", "POP_TARGET_SIM_MIN",
    "POP_TARGET_SIM_MAX", "POP_STRESS_LOSS_STREAK",
}

_FLOAT_FIELDS = {
    "RECONCILE_EVERY_SEC", "MAKER_REPRICE_SLEEP",
    "MAKER_ENTRY_LIFE_SEC", "MAKER_EXIT_LIFE_SEC",
    "ENTRY_MAX_SECONDS_TOTAL", "EXIT_MAX_SECONDS_TOTAL",
    "HARDSTOP_IOC_LIFE_SEC", "BAD_ORDER_COOLDOWN_SEC",
    "DEPTH_CACHE_SEC", "ACCOUNT_CACHE_SEC",
    "MODEL_LONG_TH", "MODEL_SHORT_TH", "MODEL_MIN_CONF",
    "ENTRY_QUALITY_MIN",
    "COOLDOWN_AFTER_EXIT_SEC", "COOLDOWN_AFTER_LOSS_SEC",
    "MAX_HOLD_SEC", "STAGNATION_HOLD_SEC",
    "DYN_TPSL_REFRESH_SEC", "DYN_REQUIRE_HELD_SEC",
    "LEARN_LR", "LEARN_L2", "LEARN_CLIP",
    "CALIB_SPREAD_PCT", "CALIB_WALL_PCT", "CALIB_VOL_MIN_PCT", "CALIB_VOL_MED_PCT",
    "HEARTBEAT_SEC", "LOOP_SLEEP", "HTTP_BACKOFF_BASE",
    "POP_HEALTHY_LIVE_WR", "POP_HEALTHY_LIVE_PNL", "POP_STRESS_LIVE_PNL",
    "POP_UPDATE_INTERVAL_SEC",
    "AI_LAB_INTERVAL_SEC", "AI_LAB_PROMOTION_MIN_WINRATE", "AI_LAB_SCORE_BOOST",
}

_BOOL_FIELDS = {
    "SIMULATION_MODE", "LIVE_PROFILE", "RECONCILE_ENABLE",
    "RECONCILE_CANCEL_OPEN_ORDERS_ON_MISMATCH",
    "RECONCILE_CANCEL_OPEN_ORDERS_ON_ADOPT",
    "USE_MARGIN_TARGET", "MAKER_ONLY_ENTRY", "MAKER_ONLY_EXIT",
    "EXIT_FORCE_COMPLETE", "ENTRY_ALLOW_IOC_ESCALATION",
    "EXIT_ALLOW_IOC_ESCALATION", "ENFORCE_CONFIG_TPSL",
    "DYN_TPSL_ENABLE", "CALIB_ENABLE", "CALIB_WALL_BAND_FROM_VOL",
    "AI_LAB_ENABLE", "AI_LAB_REQUIRE_REGIME_FILTER", "DASHBOARD_AUTOSTART",
    "REVERSAL_EXIT_ON_OFI",
}

_STR_FIELDS = {
    "API_KEY", "API_SECRET", "SYMBOL", "BASE_URL", "EXCHANGE", "KILL_SWITCH_FILE",
    "DASHBOARD_HOST",
    "STATE_FILE", "TRADE_LOG", "CENTRAL_LOG_JSONL", "LEARNING_LOG_JSONL",
    "MODEL_FILE", "PROFILE_FILE"
}


def _coerce_bool(val: Any) -> bool:
    """Parse booleans safely from JSON/native values."""
    if isinstance(val, bool):
        return val
    if isinstance(val, (int, float)):
        return bool(val)
    if isinstance(val, str):
        v = val.strip().lower()
        if v in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if v in {"0", "false", "f", "no", "n", "off", ""}:
            return False
        raise ValueError(f"invalid boolean value: {val!r}")
    return bool(val)


def _strip_json_comments(source: str) -> str:
    source = re.sub(r"/\*.*?\*/", "", source, flags=re.DOTALL)
    source = re.sub(r"(^|\s)//.*?$", "", source, flags=re.MULTILINE)
    source = re.sub(r"(^|\s)#.*?$", "", source, flags=re.MULTILINE)
    return source


def _strip_trailing_commas(source: str) -> str:
    return re.sub(r",(?=\s*[}\]])", "", source)


def load_json_file(path: str) -> Any:
    """Load JSON with small quality-of-life fixes for comments and trailing commas."""
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()
    try:
        return json.loads(raw)
    except json.JSONDecodeError as first_err:
        cleaned = _strip_trailing_commas(_strip_json_comments(raw)).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as second_err:
            raise json.JSONDecodeError(
                f"{second_err.msg}. Tip: remove comments/trailing commas near line {second_err.lineno}",
                second_err.doc,
                second_err.pos,
            ) from first_err


def load_config_json(cfg: Config, path: str) -> int:
    """Load JSON config, apply typed values. Returns count applied."""
    if not os.path.exists(path):
        LOG.warning("Config file not found: %s — using defaults", path)
        return 0
    try:
        data = load_json_file(path)
    except Exception as e:
        LOG.error("Failed to parse %s: %s", path, e)
        return 0

    applied = 0
    for key, val in data.items():
        if key.startswith("_"):
            continue
        if not hasattr(cfg, key):
            continue
        try:
            if key in _DECIMAL_FIELDS:
                setattr(cfg, key, Decimal(str(val)))
            elif key in _INT_FIELDS:
                setattr(cfg, key, int(val))
            elif key in _FLOAT_FIELDS:
                setattr(cfg, key, float(val))
            elif key in _BOOL_FIELDS:
                setattr(cfg, key, _coerce_bool(val))
            elif key in _STR_FIELDS:
                setattr(cfg, key, str(val).strip())
            else:
                setattr(cfg, key, val)
            applied += 1
        except Exception as e:
            LOG.warning("Config key %s: %s", key, e)

    LOG.info("Config loaded from %s: %d params applied", path, applied)
    finalize_config(cfg)
    return applied


# ── Exchange detection ──────────────────────────────────────────────────────

KNOWN_EXCHANGES = {
    "aster":   "https://fapi.asterdex.com",
    "binance": "https://fapi.binance.com",
    "binance_testnet": "https://testnet.binancefuture.com",
}


def detect_exchange(base_url: str) -> str:
    """Detect exchange name from BASE_URL. Returns 'aster', 'binance', or 'unknown'."""
    url = base_url.lower().rstrip("/")
    if "asterdex" in url:
        return "aster"
    if "binance" in url:
        return "binance"
    return "unknown"


def finalize_config(cfg: Config) -> None:
    """Auto-detect EXCHANGE from BASE_URL if not explicitly set."""
    if not cfg.EXCHANGE:
        cfg.EXCHANGE = detect_exchange(cfg.BASE_URL)
    LOG.info("Exchange: %s | BASE_URL: %s | SYMBOL: %s", cfg.EXCHANGE, cfg.BASE_URL, cfg.SYMBOL)
