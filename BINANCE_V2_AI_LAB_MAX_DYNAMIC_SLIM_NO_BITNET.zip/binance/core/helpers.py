"""Pure utility functions. No I/O, no state, no side effects."""

from __future__ import annotations

import json
import math
import os
from datetime import datetime
from decimal import Decimal, ROUND_DOWN
from typing import Any, List

D0 = Decimal("0")
D1 = Decimal("1")


def utc_ts() -> str:
    return datetime.utcnow().isoformat(timespec="milliseconds") + "Z"


def d(x: Any) -> Decimal:
    if isinstance(x, Decimal):
        return x
    return Decimal(str(x))


def clamp(x: Decimal, lo: Decimal, hi: Decimal) -> Decimal:
    return max(lo, min(hi, x))


def round_step(x: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        return x
    return (x / step).to_integral_value(rounding=ROUND_DOWN) * step


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def file_exists(path: str) -> bool:
    try:
        return os.path.exists(path)
    except Exception:
        return False


def atomic_write_json(path: str, payload: dict) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def append_jsonl(path: str, obj: dict) -> None:
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")
    except Exception:
        pass


def sigmoidf(x: float) -> float:
    x = max(min(x, 40.0), -40.0)
    return 1.0 / (1.0 + math.exp(-x))


def log1p_pos(x: Decimal) -> Decimal:
    if x <= 0:
        return D0
    return d(math.log1p(max(0.0, float(x))))


def bps_move(a: Decimal, b: Decimal) -> Decimal:
    if a <= 0:
        return D0
    return ((b - a) / a) * Decimal("10000")


def percentile_dec(xs: List[Decimal], pct: float) -> Decimal:
    if not xs:
        return D0
    ys = sorted(xs)
    pct = max(0.0, min(100.0, pct))
    k = int(round((pct / 100.0) * (len(ys) - 1)))
    return ys[k]


def qty_str(x: Decimal) -> str:
    return f"{x:.8f}".rstrip("0").rstrip(".")


def px_str(x: Decimal) -> str:
    return f"{x:.12f}".rstrip("0").rstrip(".")
