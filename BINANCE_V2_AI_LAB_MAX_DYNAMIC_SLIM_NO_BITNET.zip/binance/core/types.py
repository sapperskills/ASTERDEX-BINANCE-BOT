"""Shared data types used across modules."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from decimal import Decimal
from typing import Optional

from core.helpers import D0, d, clamp, atomic_write_json
from core.config import Config


# ── Symbol filters (from exchangeInfo) ───────────────────────────────────────

@dataclass
class SymbolFilters:
    min_qty: Decimal = Decimal("0.001")
    qty_step: Decimal = Decimal("0.001")
    price_tick: Decimal = Decimal("0.0001")


# ── Market snapshot (immutable per tick) ─────────────────────────────────────

@dataclass(frozen=True)
class Snapshot:
    mid: Decimal
    best_bid: Decimal
    best_ask: Decimal
    spread: Decimal
    spread_bps: Decimal
    wall_total: Decimal
    ofi: Decimal
    ma: Optional[Decimal]
    slope: int
    vol_bps: Decimal
    atr_price: Decimal
    wall_band_bps: Decimal


# ── Symbol profile (built during calibration) ───────────────────────────────

@dataclass
class SymbolProfile:
    symbol: str
    ts: str
    wall_band_bps: Decimal
    min_wall_total: Decimal
    max_spread_bps: Decimal
    min_vol_bps: Decimal
    vol_med_bps: Decimal
    vol_expand_mult: Decimal

    def to_payload(self) -> dict:
        return {
            "symbol": self.symbol,
            "ts": self.ts,
            "wall_band_bps": str(self.wall_band_bps),
            "min_wall_total": str(self.min_wall_total),
            "max_spread_bps": str(self.max_spread_bps),
            "min_vol_bps": str(self.min_vol_bps),
            "vol_med_bps": str(self.vol_med_bps),
            "vol_expand_mult": str(self.vol_expand_mult),
        }

    @staticmethod
    def from_payload(p: dict) -> Optional[SymbolProfile]:
        try:
            return SymbolProfile(
                symbol=str(p.get("symbol", "")),
                ts=str(p.get("ts", "")),
                wall_band_bps=d(p.get("wall_band_bps", "0")),
                min_wall_total=d(p.get("min_wall_total", "0")),
                max_spread_bps=d(p.get("max_spread_bps", "0")),
                min_vol_bps=d(p.get("min_vol_bps", "0")),
                vol_med_bps=d(p.get("vol_med_bps", "0")),
                vol_expand_mult=d(p.get("vol_expand_mult", "0")),
            )
        except Exception:
            return None


def apply_profile_to_cfg(cfg: Config, prof: SymbolProfile) -> None:
    cfg.MIN_WALL_TOTAL = max(Decimal("1"), prof.min_wall_total)
    cfg.MAX_SPREAD_BPS = max(Decimal("1"), prof.max_spread_bps)
    cfg.MIN_VOL_BPS = max(Decimal("0.1"), prof.min_vol_bps)
    cfg.VOL_EXPAND_MULT = max(Decimal("1.0"), prof.vol_expand_mult)
    cfg.WALL_BAND_BPS_DEFAULT = clamp(prof.wall_band_bps, cfg.WALL_BAND_BPS_MIN, cfg.WALL_BAND_BPS_MAX)


def load_symbol_profile(cfg: Config) -> Optional[SymbolProfile]:
    if not os.path.exists(cfg.PROFILE_FILE):
        return None
    try:
        with open(cfg.PROFILE_FILE, "r", encoding="utf-8") as f:
            p = json.load(f)
        prof = SymbolProfile.from_payload(p)
        if prof and prof.symbol.upper() == cfg.SYMBOL.upper():
            return prof
        return None
    except Exception:
        return None


def save_symbol_profile(cfg: Config, prof: SymbolProfile) -> None:
    try:
        atomic_write_json(cfg.PROFILE_FILE, prof.to_payload())
    except Exception:
        pass
