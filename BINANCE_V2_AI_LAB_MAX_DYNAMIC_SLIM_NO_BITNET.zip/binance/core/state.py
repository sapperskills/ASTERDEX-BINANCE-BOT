"""Bot state: position tracking, persistence, serialization."""

from __future__ import annotations

import json
import logging
import os
from collections import deque
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Deque, Optional, Dict

from core.helpers import D0, d, atomic_write_json
from core.config import Config

LOG = logging.getLogger("aster")


@dataclass
class BotState:
    position: Optional[str] = None  # LONG / SHORT / None
    qty: Decimal = D0
    entry_price: Decimal = D0
    entry_time: float = 0.0

    tp_usd: Decimal = D0
    sl_usd: Decimal = D0
    trail_usd: Decimal = D0
    peak_unreal: Decimal = D0
    entry_est_cost: Decimal = D0

    tp_init: Decimal = D0
    sl_init: Decimal = D0
    last_tpsl_refresh: float = 0.0

    tp_touched: bool = False
    tp_touch_ts: float = 0.0

    bad_order_attempts: int = 0

    loss_streak: int = 0
    trade_outcomes: Deque[int] = field(default_factory=lambda: deque(maxlen=200))
    realized_day_pnl: Decimal = D0
    current_day: str = ""
    daily_pnl: Dict[str, str] = field(default_factory=dict)

    next_entry_time: float = 0.0

    ofi_ema: Decimal = D0
    ofi_prev: float = 0.0
    prev_mid: Optional[Decimal] = None
    confirm_streak_long: int = 0
    confirm_streak_short: int = 0

    peak_wallet_usdt: Decimal = D0
    pnl_history: Deque[Decimal] = field(default_factory=lambda: deque(maxlen=200))

    last_reconcile_ts: float = 0.0
    adopted_from_exchange: bool = False

    # ── Convenience ──────────────────────────────────────────────────────

    def is_flat(self) -> bool:
        return self.position is None or self.qty <= 0

    def unreal(self, mid: Decimal) -> Decimal:
        if self.is_flat():
            return D0
        if self.position == "LONG":
            return (mid - self.entry_price) * self.qty
        return (self.entry_price - mid) * self.qty

    def clear(self) -> None:
        self.position = None
        self.qty = D0
        self.entry_price = D0
        self.entry_time = 0.0
        self.tp_usd = D0
        self.sl_usd = D0
        self.trail_usd = D0
        self.peak_unreal = D0
        self.entry_est_cost = D0
        self.tp_init = D0
        self.sl_init = D0
        self.last_tpsl_refresh = 0.0
        self.tp_touched = False
        self.tp_touch_ts = 0.0
        self.bad_order_attempts = 0
        self.confirm_streak_long = 0
        self.confirm_streak_short = 0
        self.adopted_from_exchange = False

    # ── Serialization ────────────────────────────────────────────────────

    def to_payload(self) -> dict:
        return {
            "position": self.position,
            "qty": str(self.qty),
            "entry_price": str(self.entry_price),
            "entry_time": float(self.entry_time),
            "tp_usd": str(self.tp_usd),
            "sl_usd": str(self.sl_usd),
            "trail_usd": str(self.trail_usd),
            "peak_unreal": str(self.peak_unreal),
            "entry_est_cost": str(self.entry_est_cost),
            "tp_init": str(self.tp_init),
            "sl_init": str(self.sl_init),
            "last_tpsl_refresh": float(self.last_tpsl_refresh),
            "tp_touched": bool(self.tp_touched),
            "tp_touch_ts": float(self.tp_touch_ts),
            "bad_order_attempts": int(self.bad_order_attempts),
            "loss_streak": int(self.loss_streak),
            "trade_outcomes": list(self.trade_outcomes),
            "realized_day_pnl": str(self.realized_day_pnl),
            "current_day": str(self.current_day),
            "daily_pnl": dict(self.daily_pnl),
            "next_entry_time": float(self.next_entry_time),
            "ofi_ema": str(self.ofi_ema),
            "ofi_prev": float(self.ofi_prev),
            "prev_mid": str(self.prev_mid) if self.prev_mid is not None else "",
            "confirm_streak_long": int(self.confirm_streak_long),
            "confirm_streak_short": int(self.confirm_streak_short),
            "peak_wallet_usdt": str(self.peak_wallet_usdt),
            "pnl_history": [str(x) for x in self.pnl_history],
            "last_reconcile_ts": float(self.last_reconcile_ts),
            "adopted_from_exchange": bool(self.adopted_from_exchange),
        }

    @staticmethod
    def from_payload(p: dict) -> BotState:
        s = BotState()
        s.position = p.get("position")
        s.qty = d(p.get("qty", "0"))
        s.entry_price = d(p.get("entry_price", "0"))
        s.entry_time = float(p.get("entry_time", 0.0))
        s.tp_usd = d(p.get("tp_usd", "0"))
        s.sl_usd = d(p.get("sl_usd", "0"))
        s.trail_usd = d(p.get("trail_usd", "0"))
        s.peak_unreal = d(p.get("peak_unreal", "0"))
        s.entry_est_cost = d(p.get("entry_est_cost", "0"))
        s.tp_init = d(p.get("tp_init", str(s.tp_usd or D0)))
        s.sl_init = d(p.get("sl_init", str(s.sl_usd or D0)))
        s.last_tpsl_refresh = float(p.get("last_tpsl_refresh", 0.0))
        s.tp_touched = bool(p.get("tp_touched", False))
        s.tp_touch_ts = float(p.get("tp_touch_ts", 0.0))
        s.bad_order_attempts = int(p.get("bad_order_attempts", 0))
        s.loss_streak = int(p.get("loss_streak", 0))
        s.trade_outcomes = deque((int(x) for x in (p.get("trade_outcomes") or [])), maxlen=200)
        s.realized_day_pnl = d(p.get("realized_day_pnl", "0"))
        s.current_day = str(p.get("current_day", ""))
        s.daily_pnl = {str(k): str(v) for k, v in (p.get("daily_pnl") or {}).items()}
        s.next_entry_time = float(p.get("next_entry_time", 0.0))
        s.ofi_ema = d(p.get("ofi_ema", "0"))
        s.ofi_prev = float(p.get("ofi_prev", 0.0))
        pm = str(p.get("prev_mid", ""))
        s.prev_mid = d(pm) if pm not in ("", "None", None) else None
        s.confirm_streak_long = int(p.get("confirm_streak_long", 0))
        s.confirm_streak_short = int(p.get("confirm_streak_short", 0))
        s.peak_wallet_usdt = d(p.get("peak_wallet_usdt", "0"))
        ph = p.get("pnl_history") or []
        try:
            s.pnl_history = deque((d(x) for x in ph), maxlen=200)
        except Exception:
            s.pnl_history = deque(maxlen=200)
        s.last_reconcile_ts = float(p.get("last_reconcile_ts", 0.0))
        s.adopted_from_exchange = bool(p.get("adopted_from_exchange", False))
        if s.tp_init <= 0 and s.tp_usd > 0:
            s.tp_init = s.tp_usd
        if s.sl_init <= 0 and s.sl_usd > 0:
            s.sl_init = s.sl_usd
        return s


# ── File persistence ─────────────────────────────────────────────────────────

def state_load(cfg: Config) -> Optional[BotState]:
    if not os.path.exists(cfg.STATE_FILE):
        return None
    try:
        with open(cfg.STATE_FILE, "r", encoding="utf-8") as f:
            return BotState.from_payload(json.load(f))
    except Exception as e:
        LOG.warning("STATE load failed: %s", e)
        return None


def state_save(cfg: Config, st: BotState) -> None:
    try:
        atomic_write_json(cfg.STATE_FILE, st.to_payload())
    except Exception:
        pass


def rolling_wr(outcomes: Deque[int]) -> Decimal:
    if not outcomes:
        return Decimal("0.50")
    return d(sum(outcomes)) / d(len(outcomes))
