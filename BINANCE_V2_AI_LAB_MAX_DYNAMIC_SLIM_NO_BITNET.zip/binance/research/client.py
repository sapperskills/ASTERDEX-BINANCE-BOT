from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import requests


@dataclass
class PublicFuturesClient:
    """Universal public API client for Aster DEX and Binance Futures.

    Both exchanges use identical /fapi/v1/ endpoints with the same
    request/response format. Only the base_url differs:
      - Aster:   https://fapi.asterdex.com
      - Binance: https://fapi.binance.com
    """
    base_url: str = "https://fapi.asterdex.com"
    timeout_connect: float = 4.0
    timeout_read: float = 20.0
    max_retries: int = 4
    backoff_sec: float = 0.4

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")
        self.sess = requests.Session()

    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Any:
        url = f"{self.base_url}{endpoint}"
        params = params or {}
        for attempt in range(self.max_retries):
            try:
                resp = self.sess.get(url, params=params, timeout=(self.timeout_connect, self.timeout_read))
                if resp.status_code == 200:
                    return resp.json()
                if resp.status_code in (418, 429, 500, 502, 503, 504):
                    time.sleep(self.backoff_sec * (attempt + 1))
                    continue
                return None
            except requests.RequestException:
                time.sleep(self.backoff_sec * (attempt + 1))
        return None

    def exchange_info(self) -> Dict[str, Any]:
        data = self.get("/fapi/v1/exchangeInfo")
        return data if isinstance(data, dict) else {}

    def tickers_24h(self) -> List[Dict[str, Any]]:
        data = self.get("/fapi/v1/ticker/24hr")
        return data if isinstance(data, list) else []

    def book_tickers(self) -> List[Dict[str, Any]]:
        data = self.get("/fapi/v1/ticker/bookTicker")
        return data if isinstance(data, list) else []

    def premium_index(self) -> List[Dict[str, Any]]:
        data = self.get("/fapi/v1/premiumIndex")
        return data if isinstance(data, list) else []

    def funding_info(self) -> List[Dict[str, Any]]:
        data = self.get("/fapi/v1/fundingInfo")
        return data if isinstance(data, list) else []

    def klines(self, symbol: str, interval: str, limit: int) -> List[List[Any]]:
        data = self.get("/fapi/v1/klines", {"symbol": symbol, "interval": interval, "limit": limit})
        return data if isinstance(data, list) else []
