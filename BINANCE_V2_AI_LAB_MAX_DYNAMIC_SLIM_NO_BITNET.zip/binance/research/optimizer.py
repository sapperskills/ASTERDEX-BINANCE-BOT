from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List

from .features import SymbolSnapshot, choose_max_spread, choose_min_vol, choose_min_wall_total, choose_wall_band
from .strategies import StrategyResult


@dataclass
class SymbolRecommendation:
    symbol: str
    best_strategy: str
    second_strategy: str
    score: float
    robustness: float
    trades: int
    win_rate: float
    avg_ret: float
    total_ret: float
    sharpe_like: float
    max_drawdown: float
    regime_bias: str
    risk_tier: str
    liquidity_tier: str
    patch: Dict[str, Any]
    patch_reasons: Dict[str, str]
    notes: str

    def profile_payload(self) -> Dict[str, str]:
        return {
            "symbol": self.symbol,
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "wall_band_bps": f"{self.patch['WALL_BAND_BPS_DEFAULT']:.8f}",
            "min_wall_total": f"{self.patch['MIN_WALL_TOTAL']:.8f}",
            "max_spread_bps": f"{self.patch['MAX_SPREAD_BPS']:.8f}",
            "min_vol_bps": f"{self.patch['MIN_VOL_BPS']:.8f}",
            "vol_med_bps": f"{self.patch['VOL_MED_BPS']:.8f}",
            "vol_expand_mult": f"{self.patch['VOL_EXPAND_MULT']:.8f}",
        }


def _base_patch(snapshot: SymbolSnapshot, best: StrategyResult) -> Dict[str, Any]:
    hold = int(best.params.get("hold_bars", 8))
    trendy = snapshot.trend_bucket == "trend"
    return {
        "MAX_SPREAD_BPS": round(choose_max_spread(snapshot.spread_bps, snapshot.vol_bps), 6),
        "MIN_VOL_BPS": round(choose_min_vol(snapshot.vol_bps), 6),
        "MIN_WALL_TOTAL": round(choose_min_wall_total(snapshot.quote_volume_24h), 6),
        "WALL_BAND_BPS_DEFAULT": round(choose_wall_band(snapshot.vol_bps), 6),
        "VOL_MED_BPS": round(snapshot.vol_bps, 6),
        "VOL_EXPAND_MULT": round(1.10 if snapshot.vol_bps >= 20 else 1.08, 6),
        "TP_ATR_MULT": round(max(1.1, min(3.0, 1.15 + (0.40 if trendy else 0.15) + hold * 0.03)), 6),
        "SL_ATR_MULT": round(max(0.8, min(2.2, 0.90 + hold * 0.02 + (0.10 if snapshot.risk_tier == 'HIGH' else 0.0))), 6),
        "TRAIL_START_FRAC_TP": round(max(0.25, min(0.80, 0.34 + hold * 0.01 + (0.08 if trendy else 0.02))), 6),
        "ENTRY_CONFIRM_TICKS": int(max(2, min(8, hold // 2 if hold >= 4 else 2))),
        "MA_LENGTH": int(max(12, min(55, hold * 3))),
        "MA_SLOPE_LEN": int(max(4, min(20, hold))),
        "HEUR_OFI_MIN": round(0.05 if snapshot.liquidity_tier.startswith("A") else 0.03, 6),
    }


def build_recommendation(snapshot: SymbolSnapshot, results: List[StrategyResult]) -> SymbolRecommendation:
    best = results[0]
    second = results[1] if len(results) > 1 else results[0]
    patch = _base_patch(snapshot, best)

    if best.strategy == "mean_reversion":
        patch["TP_ATR_MULT"] = round(max(1.0, patch["TP_ATR_MULT"] - 0.20), 6)
        patch["SL_ATR_MULT"] = round(min(1.8, 0.90 + int(best.params.get("hold_bars", 8)) * 0.015), 6)
    elif best.strategy == "breakout":
        patch["ENTRY_CONFIRM_TICKS"] = int(min(8, patch["ENTRY_CONFIRM_TICKS"] + 1))
        patch["TRAIL_START_FRAC_TP"] = round(min(0.85, patch["TRAIL_START_FRAC_TP"] + 0.06), 6)
    elif best.strategy == "momentum_pullback":
        patch["MA_LENGTH"] = int(max(14, min(55, patch["MA_LENGTH"] + 3)))
    elif best.strategy == "maker_fade":
        patch["MAX_SPREAD_BPS"] = round(min(12.0, patch["MAX_SPREAD_BPS"] * 0.90), 6)
        patch["ENTRY_CONFIRM_TICKS"] = int(max(2, patch["ENTRY_CONFIRM_TICKS"] - 1))

    patch_reasons = {
        "MAX_SPREAD_BPS": f"Recent median spread was {snapshot.spread_bps:.3f} bps; patch widens to {patch['MAX_SPREAD_BPS']:.3f} bps to preserve fills while avoiding degraded microstructure.",
        "MIN_VOL_BPS": f"Recent realized volatility was {snapshot.vol_bps:.2f} bps; patch requires at least {patch['MIN_VOL_BPS']:.2f} bps so the engine avoids dead tape.",
        "MIN_WALL_TOTAL": f"24h quote volume was {snapshot.quote_volume_24h:,.0f}; patch scales wall threshold to {patch['MIN_WALL_TOTAL']:,.0f} so liquidity gates match the symbol.",
        "WALL_BAND_BPS_DEFAULT": f"Volatility bucket is {snapshot.vol_bucket}; patch sets wall band to {patch['WALL_BAND_BPS_DEFAULT']:.2f} bps for symbol-aware wall scanning.",
        "TP_ATR_MULT": f"Best simulation was {best.strategy} with hold={int(best.params.get('hold_bars', 0))}; patch sets TP_ATR_MULT to {patch['TP_ATR_MULT']:.2f}.",
        "SL_ATR_MULT": f"Best simulation max drawdown was {best.max_drawdown:.4f}; patch sets SL_ATR_MULT to {patch['SL_ATR_MULT']:.2f} for tighter downside control.",
        "TRAIL_START_FRAC_TP": f"Patch starts trailing at {patch['TRAIL_START_FRAC_TP']:.2f} of TP to align with {best.strategy} exit behavior.",
        "ENTRY_CONFIRM_TICKS": f"Patch uses {patch['ENTRY_CONFIRM_TICKS']} confirm ticks based on the best strategy hold horizon of {int(best.params.get('hold_bars', 0))} bars.",
        "MA_LENGTH": f"Patch uses MA_LENGTH={patch['MA_LENGTH']} to match the best strategy's holding profile.",
        "MA_SLOPE_LEN": f"Patch uses MA_SLOPE_LEN={patch['MA_SLOPE_LEN']} to keep slope detection aligned with current regime {snapshot.regime}.",
        "HEUR_OFI_MIN": f"Liquidity tier {snapshot.liquidity_tier} suggests OFI threshold {patch['HEUR_OFI_MIN']:.3f}.",
    }
    return SymbolRecommendation(
        symbol=snapshot.symbol,
        best_strategy=best.strategy,
        second_strategy=second.strategy,
        score=round(best.score, 6),
        robustness=round(best.robustness, 6),
        trades=best.trades,
        win_rate=round(best.win_rate, 6),
        avg_ret=round(best.avg_ret, 8),
        total_ret=round(best.total_ret, 8),
        sharpe_like=round(best.sharpe_like, 6),
        max_drawdown=round(best.max_drawdown, 8),
        regime_bias=snapshot.regime,
        risk_tier=snapshot.risk_tier,
        liquidity_tier=snapshot.liquidity_tier,
        patch=patch,
        patch_reasons=patch_reasons,
        notes=snapshot.notes,
    )


def write_outputs(out_dir: str, rows: List[Dict[str, Any]], recs: List[SymbolRecommendation], metadata: Dict[str, Any]) -> Dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    per_symbol = out / "per_symbol"
    per_symbol.mkdir(parents=True, exist_ok=True)

    import csv
    if rows:
        with (out / "all_symbols_research.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

    top_profiles = {rec.symbol: rec.profile_payload() for rec in recs}
    (out / "top_symbol_profiles.json").write_text(json.dumps(top_profiles, indent=2), encoding="utf-8")

    update_pack = {
        **metadata,
        "top_symbols": [asdict(rec) for rec in recs],
    }
    (out / "strategy_update_pack.json").write_text(json.dumps(update_pack, indent=2), encoding="utf-8")

    for rec in recs:
        (per_symbol / f"config_patch_{rec.symbol}.json").write_text(json.dumps(rec.patch, indent=2), encoding="utf-8")
        (per_symbol / f"config_patch_{rec.symbol}_with_reasons.json").write_text(json.dumps(asdict(rec), indent=2), encoding="utf-8")
        (per_symbol / f"{rec.symbol}_symbol_profile.json").write_text(json.dumps(rec.profile_payload(), indent=2), encoding="utf-8")

    return {
        "csv": str(out / "all_symbols_research.csv"),
        "profiles": str(out / "top_symbol_profiles.json"),
        "update_pack": str(out / "strategy_update_pack.json"),
        "per_symbol": str(per_symbol),
    }
