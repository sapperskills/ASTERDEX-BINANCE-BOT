from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import median
from typing import Any, Dict, Iterable, List, Optional


@dataclass
class CandleSeries:
    ts: List[int]
    open: List[float]
    high: List[float]
    low: List[float]
    close: List[float]
    volume: List[float]
    quote_volume: List[float]


@dataclass
class RegimeInfo:
    regime: str
    vol_bucket: str
    trend_bucket: str
    liquidity_bucket: str
    spread_bucket: str
    trend_strength: float
    mean_reversion_strength: float
    efficiency_ratio: float
    realized_vol_bps: float
    spread_bps: float


@dataclass
class SymbolSnapshot:
    symbol: str
    last_price: float
    spread_bps: float
    quote_volume_24h: float
    volume_24h: float
    funding_rate: float
    funding_interval_hours: float
    atr_pct: float
    vol_bps: float
    trend_strength: float
    mean_reversion_strength: float
    efficiency_ratio: float
    regime: str
    vol_bucket: str
    trend_bucket: str
    liquidity_tier: str
    risk_tier: str
    notes: str


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def series_from_klines(klines: List[List[Any]]) -> CandleSeries:
    ts, o, h, l, c, v, qv = [], [], [], [], [], [], []
    for row in klines:
        if len(row) < 8:
            continue
        ts.append(int(safe_float(row[0])))
        o.append(safe_float(row[1]))
        h.append(safe_float(row[2]))
        l.append(safe_float(row[3]))
        c.append(safe_float(row[4]))
        v.append(safe_float(row[5]))
        qv.append(safe_float(row[7]))
    return CandleSeries(ts=ts, open=o, high=h, low=l, close=c, volume=v, quote_volume=qv)


def returns(closes: List[float]) -> List[float]:
    out: List[float] = []
    for a, b in zip(closes, closes[1:]):
        if a > 0:
            out.append((b - a) / a)
    return out


def std(values: Iterable[float]) -> float:
    vals = list(values)
    if len(vals) < 2:
        return 0.0
    mu = sum(vals) / len(vals)
    var = sum((x - mu) ** 2 for x in vals) / max(1, len(vals) - 1)
    return math.sqrt(max(0.0, var))


def rolling_mean(values: List[float], end: int, window: int) -> float:
    start = max(0, end - window)
    sub = values[start:end]
    return (sum(sub) / len(sub)) if sub else 0.0


def atr_pct(high: List[float], low: List[float], close: List[float], window: int = 14) -> float:
    trs: List[float] = []
    prev_close: Optional[float] = None
    for h, l, c in zip(high, low, close):
        tr = h - l
        if prev_close is not None:
            tr = max(tr, abs(h - prev_close), abs(l - prev_close))
        prev_close = c
        trs.append(tr)
    if not trs or close[-1] <= 0:
        return 0.0
    use = trs[-window:] if len(trs) >= window else trs
    return (sum(use) / max(1, len(use))) / close[-1]


def efficiency_ratio(closes: List[float], window: int = 40) -> float:
    if len(closes) < window + 1:
        return 0.0
    sub = closes[-(window + 1):]
    net = abs(sub[-1] - sub[0])
    gross = sum(abs(b - a) for a, b in zip(sub, sub[1:]))
    if gross <= 1e-12:
        return 0.0
    return max(0.0, min(1.0, net / gross))


def trend_strength(closes: List[float], window: int = 80) -> float:
    if len(closes) < window:
        return 0.0
    sub = closes[-window:]
    ret = returns(sub)
    if not ret:
        return 0.0
    net = abs(sub[-1] / sub[0] - 1.0)
    gross = sum(abs(x) for x in ret)
    if gross <= 1e-12:
        return 0.0
    return max(0.0, min(1.0, net / gross))


def mean_reversion_strength(closes: List[float], window: int = 80) -> float:
    if len(closes) < window:
        return 0.0
    sub = closes[-window:]
    diffs = [b - a for a, b in zip(sub, sub[1:])]
    if len(diffs) < 3:
        return 0.0
    x = diffs[:-1]
    y = diffs[1:]
    mx = sum(x) / len(x)
    my = sum(y) / len(y)
    num = sum((a - mx) * (b - my) for a, b in zip(x, y))
    den_x = math.sqrt(sum((a - mx) ** 2 for a in x))
    den_y = math.sqrt(sum((b - my) ** 2 for b in y))
    if den_x <= 1e-12 or den_y <= 1e-12:
        return 0.0
    corr = num / (den_x * den_y)
    return max(0.0, min(1.0, -corr))


def liquidity_tier(quote_volume: float, spread_bps: float) -> str:
    if quote_volume >= 100_000_000 and spread_bps <= 1.5:
        return "A+"
    if quote_volume >= 25_000_000 and spread_bps <= 3.5:
        return "A"
    if quote_volume >= 8_000_000 and spread_bps <= 8.0:
        return "B"
    if quote_volume >= 2_000_000 and spread_bps <= 20.0:
        return "C"
    return "D"


def risk_tier(vol_bps: float, funding_rate: float, spread_bps: float) -> str:
    risk_score = vol_bps * 0.7 + abs(funding_rate) * 10000.0 * 0.6 + spread_bps * 0.4
    if risk_score < 20:
        return "LOW"
    if risk_score < 45:
        return "MEDIUM"
    return "HIGH"


def detect_regime(vol_bps: float, trend: float, mean_rev: float, eff: float, spread_bps: float, quote_volume: float) -> RegimeInfo:
    if vol_bps < 10:
        vol_bucket = "low_vol"
    elif vol_bps < 25:
        vol_bucket = "medium_vol"
    else:
        vol_bucket = "high_vol"

    if trend >= 0.22 or eff >= 0.30:
        trend_bucket = "trend"
    elif mean_rev >= 0.10 and trend < 0.14:
        trend_bucket = "range"
    else:
        trend_bucket = "mixed"

    if quote_volume >= 50_000_000:
        liquidity_bucket = "deep"
    elif quote_volume >= 10_000_000:
        liquidity_bucket = "good"
    else:
        liquidity_bucket = "thin"

    if spread_bps < 1.0:
        spread_bucket = "tight"
    elif spread_bps < 4.0:
        spread_bucket = "normal"
    else:
        spread_bucket = "wide"

    regime = f"{trend_bucket}_{vol_bucket}"
    return RegimeInfo(
        regime=regime,
        vol_bucket=vol_bucket,
        trend_bucket=trend_bucket,
        liquidity_bucket=liquidity_bucket,
        spread_bucket=spread_bucket,
        trend_strength=trend,
        mean_reversion_strength=mean_rev,
        efficiency_ratio=eff,
        realized_vol_bps=vol_bps,
        spread_bps=spread_bps,
    )


def build_snapshot(symbol: str, ticker24: Dict[str, Any], book_ticker: Dict[str, Any], premium: Dict[str, Any], funding_cfg: Dict[str, Any], candles: CandleSeries) -> Optional[SymbolSnapshot]:
    closes = candles.close
    highs = candles.high
    lows = candles.low
    if len(closes) < 60 or min(closes) <= 0:
        return None
    rets = returns(closes)
    vol_bps = std(rets[-96:]) * 10000.0
    trend = trend_strength(closes)
    mean_rev = mean_reversion_strength(closes)
    eff = efficiency_ratio(closes)
    bid = safe_float(book_ticker.get("bidPrice"))
    ask = safe_float(book_ticker.get("askPrice"))
    mid = (bid + ask) / 2.0 if bid > 0 and ask > 0 else safe_float(ticker24.get("lastPrice"))
    spread_bps = ((ask - bid) / mid * 10000.0) if bid > 0 and ask > 0 and mid > 0 else 9999.0
    quote_vol = safe_float(ticker24.get("quoteVolume"))
    regime = detect_regime(vol_bps, trend, mean_rev, eff, spread_bps, quote_vol)
    liq_tier = liquidity_tier(quote_vol, spread_bps)
    r_tier = risk_tier(vol_bps, safe_float(premium.get("lastFundingRate")), spread_bps)
    notes = (
        f"trend={trend:.3f}; mean_rev={mean_rev:.3f}; er={eff:.3f}; "
        f"spread_bps={spread_bps:.3f}; vol_bps={vol_bps:.3f}; regime={regime.regime}"
    )
    return SymbolSnapshot(
        symbol=symbol,
        last_price=safe_float(ticker24.get("lastPrice")),
        spread_bps=spread_bps,
        quote_volume_24h=quote_vol,
        volume_24h=safe_float(ticker24.get("volume")),
        funding_rate=safe_float(premium.get("lastFundingRate")),
        funding_interval_hours=safe_float(funding_cfg.get("fundingIntervalHours"), 8.0),
        atr_pct=atr_pct(highs, lows, closes),
        vol_bps=vol_bps,
        trend_strength=trend,
        mean_reversion_strength=mean_rev,
        efficiency_ratio=eff,
        regime=regime.regime,
        vol_bucket=regime.vol_bucket,
        trend_bucket=regime.trend_bucket,
        liquidity_tier=liq_tier,
        risk_tier=r_tier,
        notes=notes,
    )


def choose_wall_band(vol_bps: float) -> float:
    return max(8.0, min(90.0, 10.0 + vol_bps * 0.60))


def choose_min_wall_total(quote_volume: float) -> float:
    return max(1_000.0, min(2_000_000.0, quote_volume / 150.0))


def choose_max_spread(spread_bps: float, vol_bps: float) -> float:
    return max(0.8, min(30.0, max(spread_bps * 2.2, median([spread_bps, vol_bps / 8.0, 1.75]))))


def choose_min_vol(vol_bps: float) -> float:
    return max(0.15, min(300.0, max(vol_bps * 0.35, 0.4)))
