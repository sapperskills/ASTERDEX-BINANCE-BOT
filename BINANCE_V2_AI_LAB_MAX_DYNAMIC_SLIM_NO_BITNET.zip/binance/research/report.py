from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from .optimizer import SymbolRecommendation


def build_report(out_dir: str, scanned: int, successes: int, interval: str, kline_limit: int, recs: List[SymbolRecommendation], failures: List[str]) -> str:
    lines = [
        "# Multi-strategy market research report (Aster / Binance)",
        "",
        f"Scanned symbols: **{scanned}**",
        f"Successful analyses: **{successes}**",
        f"Interval: **{interval}** | Kline limit: **{kline_limit}**",
        "",
        "## Top symbols",
        "",
        "| Rank | Symbol | Best | Backup | Score | Robust | Regime | Win rate | Trades | Risk | Liquidity |",
        "|---:|---|---|---|---:|---:|---|---:|---:|---|---|",
    ]
    for idx, rec in enumerate(recs, start=1):
        lines.append(
            f"| {idx} | {rec.symbol} | {rec.best_strategy} | {rec.second_strategy} | {rec.score:.3f} | {rec.robustness:.2f} | {rec.regime_bias} | {rec.win_rate*100:.1f}% | {rec.trades} | {rec.risk_tier} | {rec.liquidity_tier} |"
        )
    lines.extend([
        "",
        "## Files",
        "",
        "- `all_symbols_research.csv`: per-symbol analytics and best strategy selection",
        "- `top_symbol_profiles.json`: symbol profiles compatible with the live engine's profile format",
        "- `strategy_update_pack.json`: ranked recommendations, patches, reasons, and metrics",
        "- `per_symbol/config_patch_<SYMBOL>.json`: patch file you can merge into any strategy config",
        "- `per_symbol/<SYMBOL>_symbol_profile.json`: ready-to-copy symbol profile for the live engine",
        "",
        "## Notes",
        "",
        "- The research engine uses only public REST data (Aster DEX or Binance Futures).",
        "- Strategy ranking is based on multiple simple simulations: mean reversion, breakout, momentum pullback, and maker fade.",
        "- The live trading engine in `run.py` is preserved; this research layer produces data to tune it, not replace it.",
        "",
        "## Failed symbols",
        "",
        ", ".join(failures) if failures else "None",
    ])
    report = "\n".join(lines)
    Path(out_dir, "report.md").write_text(report, encoding="utf-8")
    return report
