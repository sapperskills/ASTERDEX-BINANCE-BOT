from __future__ import annotations

import time
from dataclasses import asdict
from typing import Any, Dict, List, Optional

from .client import PublicFuturesClient
from .features import build_snapshot, series_from_klines
from .optimizer import build_recommendation, write_outputs
from .report import build_report
from .strategies import run_all_strategies


def run_research_engine(
    out_dir: str = "research_output",
    interval: str = "5m",
    kline_limit: int = 288,
    top_n: int = 25,
    symbols: Optional[List[str]] = None,
    base_url: str = "https://fapi.asterdex.com",
) -> Dict[str, Any]:
    client = PublicFuturesClient(base_url=base_url)
    exchange = client.exchange_info()
    symbol_rows = exchange.get("symbols", []) if isinstance(exchange, dict) else []
    tradable = [
        s for s in symbol_rows
        if s.get("status") == "TRADING" and s.get("contractType") == "PERPETUAL" and s.get("quoteAsset") == "USDT"
    ]
    if symbols:
        wanted = {s.strip().upper() for s in symbols if s.strip()}
        tradable = [s for s in tradable if s.get("symbol", "").upper() in wanted]

    tickers24 = {x.get("symbol"): x for x in client.tickers_24h() if isinstance(x, dict) and x.get("symbol")}
    books = {x.get("symbol"): x for x in client.book_tickers() if isinstance(x, dict) and x.get("symbol")}
    premium = {x.get("symbol"): x for x in client.premium_index() if isinstance(x, dict) and x.get("symbol")}
    funding_cfg = {x.get("symbol"): x for x in client.funding_info() if isinstance(x, dict) and x.get("symbol")}

    rows: List[Dict[str, Any]] = []
    recs = []
    failures: List[str] = []

    for idx, sym in enumerate(tradable, start=1):
        symbol = sym.get("symbol")
        if not symbol:
            continue
        kl = client.klines(symbol, interval=interval, limit=kline_limit)
        candles = series_from_klines(kl)
        snapshot = build_snapshot(
            symbol=symbol,
            ticker24=tickers24.get(symbol, {}),
            book_ticker=books.get(symbol, {}),
            premium=premium.get(symbol, {}),
            funding_cfg=funding_cfg.get(symbol, {}),
            candles=candles,
        )
        if snapshot is None:
            failures.append(symbol)
            continue
        results = run_all_strategies(candles)
        rec = build_recommendation(snapshot, results)
        rows.append({
            **asdict(snapshot),
            "best_strategy": rec.best_strategy,
            "second_strategy": rec.second_strategy,
            "score": rec.score,
            "robustness": rec.robustness,
            "trades": rec.trades,
            "win_rate": rec.win_rate,
            "avg_ret": rec.avg_ret,
            "total_ret": rec.total_ret,
            "sharpe_like": rec.sharpe_like,
            "max_drawdown": rec.max_drawdown,
        })
        recs.append(rec)
        time.sleep(0.03)

    recs.sort(key=lambda x: (x.score, x.robustness, x.trades), reverse=True)
    rows.sort(key=lambda x: (x["score"], x["robustness"], x["quote_volume_24h"]), reverse=True)
    leaders = recs[:top_n]
    outputs = write_outputs(
        out_dir=out_dir,
        rows=rows,
        recs=leaders,
        metadata={
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "base_url": base_url,
            "interval": interval,
            "kline_limit": kline_limit,
            "symbols_scanned": len(tradable),
            "successful_analyses": len(rows),
            "failed_symbols": failures,
        },
    )
    build_report(out_dir, len(tradable), len(rows), interval, kline_limit, leaders, failures)
    return {
        "out_dir": out_dir,
        "symbols_scanned": len(tradable),
        "successful_analyses": len(rows),
        "leaders": [rec.symbol for rec in leaders],
        "failed_symbols": failures,
        **outputs,
    }
