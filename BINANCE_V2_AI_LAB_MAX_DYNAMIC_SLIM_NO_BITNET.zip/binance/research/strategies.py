from __future__ import annotations

import itertools
import math
from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

from .features import CandleSeries, rolling_mean, std, returns


@dataclass
class StrategyResult:
    strategy: str
    params: Dict[str, float]
    trades: int
    win_rate: float
    avg_ret: float
    total_ret: float
    sharpe_like: float
    max_drawdown: float
    robustness: float
    score: float


class StrategySim:
    name = "base"

    def parameter_grid(self) -> Iterable[Dict[str, float]]:
        raise NotImplementedError

    def run(self, candles: CandleSeries, params: Dict[str, float]) -> StrategyResult:
        raise NotImplementedError

    @staticmethod
    def finalize(name: str, params: Dict[str, float], trade_returns: List[float]) -> StrategyResult:
        if not trade_returns:
            return StrategyResult(name, params, 0, 0.0, -999.0, -999.0, -999.0, 1.0, 0.0, -999.0)
        trades = len(trade_returns)
        wins = sum(1 for r in trade_returns if r > 0)
        avg_ret = sum(trade_returns) / trades
        vol = std(trade_returns)
        sharpe_like = (avg_ret / vol * math.sqrt(trades)) if vol > 1e-12 else (3.0 if avg_ret > 0 else -3.0)
        total = sum(trade_returns)
        eq = 0.0
        peak = 0.0
        mdd = 0.0
        for r in trade_returns:
            eq += r
            peak = max(peak, eq)
            mdd = min(mdd, eq - peak)
        mdd = abs(mdd)
        score = (
            avg_ret * 6.0 +
            sharpe_like * 0.20 +
            (wins / trades) * 0.35 +
            min(trades, 80) / 80.0 * 0.15 -
            mdd * 1.2
        )
        return StrategyResult(name, params, trades, wins / trades, avg_ret, total, sharpe_like, mdd, 0.0, score)


def _future_return(closes: List[float], i: int, hold_bars: int, side: int) -> float:
    if i + hold_bars >= len(closes) or closes[i] <= 0:
        return 0.0
    fwd = closes[i + hold_bars] / closes[i] - 1.0
    return fwd if side > 0 else -fwd


class MeanReversionSim(StrategySim):
    name = "mean_reversion"

    def parameter_grid(self) -> Iterable[Dict[str, float]]:
        for lookback, z_thr, hold in itertools.product((18, 24, 32), (0.9, 1.15, 1.45), (4, 8, 12)):
            yield {"lookback": lookback, "z_thr": z_thr, "hold_bars": hold}

    def run(self, candles: CandleSeries, params: Dict[str, float]) -> StrategyResult:
        c = candles.close
        rets = returns(c)
        trade_returns: List[float] = []
        lb = int(params["lookback"])
        hold = int(params["hold_bars"])
        z_thr = float(params["z_thr"])
        for i in range(lb + 2, len(c) - hold):
            mean = rolling_mean(c, i, lb)
            sub = c[i - lb:i]
            sigma = std(sub)
            if sigma <= 1e-12 or mean <= 0:
                continue
            z = (c[i] - mean) / sigma
            if z >= z_thr:
                trade_returns.append(_future_return(c, i, hold, -1))
            elif z <= -z_thr:
                trade_returns.append(_future_return(c, i, hold, 1))
        return self.finalize(self.name, params, trade_returns)


class BreakoutSim(StrategySim):
    name = "breakout"

    def parameter_grid(self) -> Iterable[Dict[str, float]]:
        for lookback, breakout_pct, hold in itertools.product((16, 24, 36), (0.0010, 0.0018, 0.0028), (4, 8, 12)):
            yield {"lookback": lookback, "breakout_pct": breakout_pct, "hold_bars": hold}

    def run(self, candles: CandleSeries, params: Dict[str, float]) -> StrategyResult:
        c, h, l = candles.close, candles.high, candles.low
        trade_returns: List[float] = []
        lb = int(params["lookback"])
        hold = int(params["hold_bars"])
        thr = float(params["breakout_pct"])
        for i in range(lb + 1, len(c) - hold):
            hi = max(h[i - lb:i])
            lo = min(l[i - lb:i])
            if hi <= 0 or lo <= 0:
                continue
            if c[i] > hi * (1.0 + thr):
                trade_returns.append(_future_return(c, i, hold, 1))
            elif c[i] < lo * (1.0 - thr):
                trade_returns.append(_future_return(c, i, hold, -1))
        return self.finalize(self.name, params, trade_returns)


class MomentumPullbackSim(StrategySim):
    name = "momentum_pullback"

    def parameter_grid(self) -> Iterable[Dict[str, float]]:
        for fast, slow, pb, hold in itertools.product((6, 9), (20, 28, 36), (0.0012, 0.0020), (4, 8, 12)):
            yield {"fast": fast, "slow": slow, "pullback_pct": pb, "hold_bars": hold}

    def run(self, candles: CandleSeries, params: Dict[str, float]) -> StrategyResult:
        c = candles.close
        trade_returns: List[float] = []
        fast = int(params["fast"])
        slow = int(params["slow"])
        hold = int(params["hold_bars"])
        pb = float(params["pullback_pct"])
        for i in range(slow + 2, len(c) - hold):
            ma_fast = rolling_mean(c, i, fast)
            ma_slow = rolling_mean(c, i, slow)
            prev = c[i - 1]
            if ma_slow <= 0 or prev <= 0:
                continue
            if ma_fast > ma_slow and c[i] < prev * (1.0 - pb):
                trade_returns.append(_future_return(c, i, hold, 1))
            elif ma_fast < ma_slow and c[i] > prev * (1.0 + pb):
                trade_returns.append(_future_return(c, i, hold, -1))
        return self.finalize(self.name, params, trade_returns)


class MakerFadeSim(StrategySim):
    name = "maker_fade"

    def parameter_grid(self) -> Iterable[Dict[str, float]]:
        for wick, body, hold in itertools.product((1.5, 2.0, 2.5), (0.0008, 0.0012), (2, 4, 6)):
            yield {"wick_ratio": wick, "body_pct": body, "hold_bars": hold}

    def run(self, candles: CandleSeries, params: Dict[str, float]) -> StrategyResult:
        o, h, l, c = candles.open, candles.high, candles.low, candles.close
        trade_returns: List[float] = []
        wick = float(params["wick_ratio"])
        body_pct = float(params["body_pct"])
        hold = int(params["hold_bars"])
        for i in range(2, len(c) - hold):
            body = abs(c[i] - o[i])
            rng = max(1e-12, h[i] - l[i])
            upper = h[i] - max(c[i], o[i])
            lower = min(c[i], o[i]) - l[i]
            if c[i] <= 0:
                continue
            body_rel = body / c[i]
            if upper > body * wick and body_rel >= body_pct and c[i] < o[i]:
                trade_returns.append(_future_return(c, i, hold, -1))
            elif lower > body * wick and body_rel >= body_pct and c[i] > o[i]:
                trade_returns.append(_future_return(c, i, hold, 1))
        return self.finalize(self.name, params, trade_returns)


def evaluate_with_robustness(sim: StrategySim, candles: CandleSeries) -> StrategyResult:
    results = [sim.run(candles, params) for params in sim.parameter_grid()]
    viable = [r for r in results if r.trades >= 4 and r.score > -900]
    if not viable:
        return max(results, key=lambda r: r.score)
    viable.sort(key=lambda r: r.score, reverse=True)
    best = viable[0]
    neighbors = viable[: min(5, len(viable))]
    avg_neighbor = sum(r.score for r in neighbors) / len(neighbors)
    robustness = max(0.0, min(1.0, (avg_neighbor - (-0.5)) / (best.score - (-0.5) + 1e-9)))
    if len(neighbors) > 1:
        score_dispersion = std([r.score for r in neighbors])
        robustness = max(0.0, min(1.0, robustness * (1.0 / (1.0 + score_dispersion))))
    best.robustness = robustness
    best.score = best.score * (0.80 + 0.20 * robustness)
    return best


def run_all_strategies(candles: CandleSeries) -> List[StrategyResult]:
    sims: List[StrategySim] = [MeanReversionSim(), BreakoutSim(), MomentumPullbackSim(), MakerFadeSim()]
    results = [evaluate_with_robustness(sim, candles) for sim in sims]
    results.sort(key=lambda r: r.score, reverse=True)
    return results
