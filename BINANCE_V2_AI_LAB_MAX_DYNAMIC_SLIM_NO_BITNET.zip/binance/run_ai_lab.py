#!/usr/bin/env python3
from pathlib import Path
from agent.service import AgentService

if __name__ == "__main__":
    base_dir = Path(__file__).resolve().parent
    svc = AgentService(base_dir=base_dir, interval_sec=5)
    report = svc.run_once()
    print(f"AI lab refreshed: samples={report.get('sample_count', 0)} promoted={len(report.get('promoted_overrides', {}))}")
