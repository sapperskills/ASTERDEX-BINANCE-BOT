"""Online learner: label generation and model training loop.

UPGRADE GUIDE: Change labeling logic (what counts as up/down),
horizon, or training cadence. The model itself lives in model.py.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from decimal import Decimal
from typing import Deque, Dict, List, Optional

from core.helpers import D0, clamp, utc_ts, append_jsonl, bps_move
from core.config import Config
from learning.model import OnlineLogReg


@dataclass
class PendingExample:
    mid0: Decimal
    raw: Dict[str, float]
    horizon_left: int


class Learner:
    def __init__(self, cfg: Config, model: OnlineLogReg):
        self.cfg = cfg
        self.model = model
        self.pending: Deque[PendingExample] = deque(maxlen=5000)

    def _thr_bps(self, vol_bps: Decimal, spread_bps: Decimal) -> Decimal:
        thr = max(self.cfg.LEARN_LABEL_BPS_MIN, spread_bps * Decimal("1.7"), vol_bps * Decimal("0.06"))
        return clamp(thr, Decimal("1.8"), Decimal("18.0"))

    def push(self, mid: Decimal, raw: Dict[str, float]) -> None:
        self.pending.append(PendingExample(mid0=mid, raw=raw, horizon_left=int(self.cfg.LEARN_HORIZON_TICKS)))

    def step(self, mid_now: Decimal, vol_bps: Decimal, spread_bps: Decimal, cfg: Config) -> None:
        if not self.pending:
            return
        for ex in self.pending:
            ex.horizon_left -= 1
        matured: List[PendingExample] = []
        while self.pending and self.pending[0].horizon_left <= 0:
            matured.append(self.pending.popleft())
        if not matured:
            return
        thr = self._thr_bps(vol_bps, spread_bps)
        for ex in matured:
            mv = bps_move(ex.mid0, mid_now)
            y: Optional[int] = None
            if mv >= thr:
                y = 1
            elif mv <= -thr:
                y = 0
            else:
                append_jsonl(cfg.LEARNING_LOG_JSONL, {"ts": utc_ts(), "label": None, "move_bps": str(mv), "thr_bps": str(thr)})
                continue
            self.model.update_one(ex.raw, int(y))
            append_jsonl(cfg.LEARNING_LOG_JSONL, {"ts": utc_ts(), "label": int(y), "move_bps": str(mv), "thr_bps": str(thr)})
        if self.model.pending_updates >= cfg.LEARN_TRAIN_EVERY:
            self.model.pending_updates = 0
            self.model.maybe_save(force=True)
