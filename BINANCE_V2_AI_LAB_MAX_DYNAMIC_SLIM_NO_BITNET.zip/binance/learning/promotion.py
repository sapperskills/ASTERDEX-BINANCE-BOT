"""Sim-to-live promotion engine.

Runs simulated trades in the background for every breakout signal.
When a symbol proves itself in sim (meets win-rate, profit-factor,
and trade-count thresholds), it is promoted to live trading.

Two operating modes controlled by SIMULATION_MODE in config.json:

  SIMULATION_MODE = true:
      Pure sim. Scans all markets, sim-trades breakouts, logs results.
      No real orders. Use this to let the system learn before going live.

  SIMULATION_MODE = false:
      Hybrid sim→live. Scanner detects breakouts, sim engine paper-trades
      them first. Once a symbol passes the promotion gates, the system
      switches it from sim to live with real orders. If live performance
      degrades, the symbol is demoted back to sim-only.

The promotion criteria are:
  - Min N sim trades completed (default: 5)
  - Sim win rate >= threshold (default: 55%)
  - Sim profit factor >= threshold (default: 1.2)
  - Sim max drawdown within limit
  - No active adaptive-learner pause on the symbol
"""

from __future__ import annotations

import json
import logging
import os
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Tuple

from core.helpers import atomic_write_json

LOG = logging.getLogger("aster.promotion")


# ── Promotion config ─────────────────────────────────────────────────────────

@dataclass
class PromotionConfig:
    """Gates a symbol must pass to go from sim to live."""
    min_sim_trades: int = 5
    min_sim_win_rate: float = 0.55
    min_sim_profit_factor: float = 1.20
    max_sim_drawdown_pct: float = 0.30      # max DD as fraction of peak
    min_sim_avg_pnl: float = 0.0            # must be net positive
    promotion_cooldown_sec: float = 300.0   # min time between re-promotions
    demotion_live_loss_streak: int = 3      # demote after N live losses in a row
    demotion_live_win_rate_floor: float = 0.30
    max_live_symbols: int = 3
    persist_file: str = "promotion_state.json"

    # Pretrain-assisted promotion prior
    use_pretrain_prior: bool = True
    promotion_score_threshold: float = 0.56
    sim_score_weight: float = 0.55
    pretrain_score_weight: float = 0.25
    breakout_conf_weight: float = 0.20
    min_sim_trades_floor: int = 3
    max_min_trades_reduction: int = 2
    pretrain_bonus_threshold: float = 0.55
    breakout_bonus_threshold: float = 0.45




@dataclass
class PromotionPrior:
    """Historical prior from pretraining and breakout-profile confidence."""
    symbol: str
    pretrain_score: float = 0.0
    breakout_confidence: float = 0.0
    val_accuracy: float = 0.0
    labeled_examples: int = 0
    updated_at: float = 0.0

    def __post_init__(self):
        if self.updated_at <= 0:
            self.updated_at = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "symbol": self.symbol,
            "pretrain_score": float(self.pretrain_score),
            "breakout_confidence": float(self.breakout_confidence),
            "val_accuracy": float(self.val_accuracy),
            "labeled_examples": int(self.labeled_examples),
            "updated_at": float(self.updated_at),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PromotionPrior":
        return cls(
            symbol=str(data.get("symbol", "")),
            pretrain_score=float(data.get("pretrain_score", 0.0)),
            breakout_confidence=float(data.get("breakout_confidence", 0.0)),
            val_accuracy=float(data.get("val_accuracy", 0.0)),
            labeled_examples=int(data.get("labeled_examples", 0)),
            updated_at=float(data.get("updated_at", 0.0)),
        )


# ── Sim trade record ─────────────────────────────────────────────────────────

@dataclass
class SimTradeResult:
    """Result of one simulated trade."""
    symbol: str
    direction: str        # LONG / SHORT
    pnl: float
    entry_price: float
    exit_price: float
    held_sec: float
    exit_reason: str
    breakout_score: float
    timestamp: float = 0.0

    def __post_init__(self):
        if self.timestamp <= 0:
            self.timestamp = time.time()


# ── Per-symbol sim tracker ───────────────────────────────────────────────────

@dataclass
class SymbolSimTracker:
    """Tracks sim performance for one symbol."""
    symbol: str
    trades: Deque[SimTradeResult] = field(default_factory=lambda: deque(maxlen=200))
    total_pnl: float = 0.0
    peak_pnl: float = 0.0
    max_drawdown: float = 0.0
    promoted: bool = False
    promoted_at: float = 0.0
    demoted_at: float = 0.0
    promotion_count: int = 0

    # Live-side tracking (only populated when promoted)
    live_trades: int = 0
    live_wins: int = 0
    live_pnl: float = 0.0
    live_loss_streak: int = 0

    @property
    def sim_trade_count(self) -> int:
        return len(self.trades)

    @property
    def sim_win_rate(self) -> float:
        if not self.trades:
            return 0.0
        return sum(1 for t in self.trades if t.pnl > 0) / len(self.trades)

    @property
    def sim_profit_factor(self) -> float:
        gross_win = sum(t.pnl for t in self.trades if t.pnl > 0)
        gross_loss = abs(sum(t.pnl for t in self.trades if t.pnl < 0))
        if gross_loss <= 0:
            return 10.0 if gross_win > 0 else 0.0
        return gross_win / gross_loss

    @property
    def sim_avg_pnl(self) -> float:
        if not self.trades:
            return 0.0
        return self.total_pnl / len(self.trades)

    @property
    def sim_drawdown_pct(self) -> float:
        if self.peak_pnl <= 0:
            return 0.0
        return self.max_drawdown / self.peak_pnl

    @property
    def live_win_rate(self) -> float:
        if self.live_trades <= 0:
            return 0.0
        return self.live_wins / self.live_trades

    def to_dict(self) -> Dict[str, Any]:
        return {
            "symbol": self.symbol,
            "sim_trades": self.sim_trade_count,
            "sim_win_rate": round(self.sim_win_rate, 4),
            "sim_pf": round(self.sim_profit_factor, 4),
            "sim_pnl": round(self.total_pnl, 4),
            "sim_peak_pnl": round(self.peak_pnl, 4),
            "sim_max_drawdown": round(self.max_drawdown, 4),
            "sim_dd_pct": round(self.sim_drawdown_pct, 4),
            "promoted": self.promoted,
            "promoted_at": self.promoted_at,
            "demoted_at": self.demoted_at,
            "promotion_count": self.promotion_count,
            "live_trades": self.live_trades,
            "live_wins": self.live_wins,
            "live_pnl": round(self.live_pnl, 4),
            "live_loss_streak": self.live_loss_streak,
            "trades": [
                {
                    "symbol": tr.symbol,
                    "direction": tr.direction,
                    "pnl": tr.pnl,
                    "entry_price": tr.entry_price,
                    "exit_price": tr.exit_price,
                    "held_sec": tr.held_sec,
                    "exit_reason": tr.exit_reason,
                    "breakout_score": tr.breakout_score,
                    "timestamp": tr.timestamp,
                }
                for tr in self.trades
            ],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SymbolSimTracker":
        t = cls(symbol=data.get("symbol", ""))
        t.total_pnl = float(data.get("sim_pnl", 0.0))
        t.peak_pnl = float(data.get("sim_peak_pnl", data.get("sim_pnl", 0.0)))
        t.max_drawdown = float(data.get("sim_max_drawdown", 0.0))
        t.promoted = bool(data.get("promoted", False))
        t.promoted_at = float(data.get("promoted_at", 0.0))
        t.demoted_at = float(data.get("demoted_at", 0.0))
        t.promotion_count = int(data.get("promotion_count", 0))
        t.live_trades = int(data.get("live_trades", 0))
        t.live_wins = int(data.get("live_wins", 0))
        t.live_pnl = float(data.get("live_pnl", 0.0))
        t.live_loss_streak = int(data.get("live_loss_streak", 0))
        for td in data.get("trades", []):
            try:
                t.trades.append(SimTradeResult(
                    symbol=td.get("symbol", t.symbol),
                    direction=td.get("direction", "UNKNOWN"),
                    pnl=float(td.get("pnl", 0.0)),
                    entry_price=float(td.get("entry_price", 0.0)),
                    exit_price=float(td.get("exit_price", 0.0)),
                    held_sec=float(td.get("held_sec", 0.0)),
                    exit_reason=td.get("exit_reason", "UNKNOWN"),
                    breakout_score=float(td.get("breakout_score", 0.0)),
                    timestamp=float(td.get("timestamp", 0.0)),
                ))
            except Exception:
                continue
        return t


# ── Promotion engine ─────────────────────────────────────────────────────────

class PromotionEngine:
    """Manages the sim→live promotion lifecycle for all symbols.

    Usage by the orchestrator:

        engine = PromotionEngine(config)

        # When sim trade completes:
        engine.record_sim_trade(sim_result)

        # Check if any symbol should be promoted:
        newly_promoted = engine.check_promotions()
        for symbol in newly_promoted:
            # spawn live runner for this symbol

        # When live trade completes:
        engine.record_live_trade(symbol, pnl, is_win)

        # Check if any live symbol should be demoted:
        demoted = engine.check_demotions()
        for symbol in demoted:
            # stop live runner, keep sim running

        # Query state:
        if engine.is_promoted(symbol):
            # symbol has live approval
    """

    def __init__(self, config: Optional[PromotionConfig] = None):
        self.config = config or PromotionConfig()
        self._trackers: Dict[str, SymbolSimTracker] = {}
        self._priors: Dict[str, PromotionPrior] = {}
        self._dynamic_score_threshold_offset: float = 0.0
        self._dynamic_min_trades_offset: int = 0
        self._dynamic_max_live_symbols_override: Optional[int] = None
        self._load_state()

    def record_sim_trade(self, result: SimTradeResult) -> None:
        """Record a completed simulated trade."""
        sym = result.symbol
        if sym not in self._trackers:
            self._trackers[sym] = SymbolSimTracker(symbol=sym)
        t = self._trackers[sym]

        t.trades.append(result)
        t.total_pnl += result.pnl
        t.peak_pnl = max(t.peak_pnl, t.total_pnl)
        t.max_drawdown = max(t.max_drawdown, t.peak_pnl - t.total_pnl)

        LOG.info("SIM TRADE %s: %s pnl=%+.4f | total=%d WR=%.0f%% PF=%.2f cumPnL=%+.4f",
                 sym, result.direction, result.pnl,
                 t.sim_trade_count, t.sim_win_rate * 100,
                 t.sim_profit_factor, t.total_pnl)

        # Persist after every trade so dashboard stays current
        self._persist_state()

    def record_live_trade(self, symbol: str, pnl: float, is_win: bool) -> None:
        """Record a completed live trade outcome."""
        t = self._trackers.get(symbol)
        if not t:
            return
        t.live_trades += 1
        t.live_pnl += pnl
        if is_win:
            t.live_wins += 1
            t.live_loss_streak = 0
        else:
            t.live_loss_streak += 1

        LOG.info("LIVE TRADE %s: pnl=%+.4f | live=%d/%d WR=%.0f%% streak=%d cumLivePnL=%+.4f",
                 symbol, pnl, t.live_wins, t.live_trades,
                 t.live_win_rate * 100, -t.live_loss_streak if not is_win else 0,
                 t.live_pnl)

        # Persist after every trade so dashboard stays current
        self._persist_state()

    def check_promotions(self) -> List[str]:
        """Check all sim-tracked symbols and return newly promoted ones."""
        now = time.time()
        promoted: List[str] = []
        currently_live = sum(1 for t in self._trackers.values() if t.promoted)
        candidates: List[Tuple[float, str, SymbolSimTracker, int, Optional[PromotionPrior]]] = []

        for sym, t in self._trackers.items():
            if t.promoted:
                continue  # already live

            # Cooldown check
            if t.demoted_at > 0 and (now - t.demoted_at) < self.config.promotion_cooldown_sec:
                continue

            prior = self._priors.get(sym)
            required_trades = self._required_sim_trades(sym)

            # Hard safety gates remain in force.
            if t.sim_trade_count < required_trades:
                continue
            if t.sim_win_rate < self.config.min_sim_win_rate:
                continue
            if t.sim_profit_factor < self.config.min_sim_profit_factor:
                continue
            if t.sim_drawdown_pct > self.config.max_sim_drawdown_pct and t.peak_pnl > 0:
                continue
            if t.sim_avg_pnl < self.config.min_sim_avg_pnl:
                continue
            if t.total_pnl < 0:
                continue

            promo_score = self._promotion_score(sym, t)
            dynamic_threshold = max(0.35, min(0.90, self.config.promotion_score_threshold + self._dynamic_score_threshold_offset))
            if promo_score < dynamic_threshold:
                continue
            candidates.append((promo_score, sym, t, required_trades, prior))

        candidates.sort(key=lambda row: (row[0], row[2].sim_trade_count, row[2].total_pnl), reverse=True)
        live_cap = self._dynamic_max_live_symbols_override if self._dynamic_max_live_symbols_override is not None else self.config.max_live_symbols
        open_slots = max(0, live_cap - currently_live)
        for promo_score, sym, t, required_trades, prior in candidates[:open_slots]:
            t.promoted = True
            t.promoted_at = now
            t.promotion_count += 1
            t.live_trades = 0
            t.live_wins = 0
            t.live_pnl = 0.0
            t.live_loss_streak = 0
            promoted.append(sym)

            pretrain_score = prior.pretrain_score if prior else 0.0
            breakout_conf = prior.breakout_confidence if prior else 0.0
            LOG.info(
                "PROMOTED TO LIVE: %s | score=%.3f reqTrades=%d sim: %d trades, WR=%.0f%%, PF=%.2f, PnL=%+.4f | pretrain=%.3f profile=%.3f",
                sym, promo_score, required_trades, t.sim_trade_count, t.sim_win_rate * 100,
                t.sim_profit_factor, t.total_pnl, pretrain_score, breakout_conf,
            )

        if promoted:
            self._persist_state()
        return promoted

    def set_symbol_prior(
        self,
        symbol: str,
        pretrain_score: float = 0.0,
        breakout_confidence: float = 0.0,
        val_accuracy: float = 0.0,
        labeled_examples: int = 0,
    ) -> None:
        """Store pretrain / breakout priors for later promotion decisions."""
        sym = str(symbol or "").upper().strip()
        if not sym:
            return
        self._priors[sym] = PromotionPrior(
            symbol=sym,
            pretrain_score=max(0.0, min(1.0, float(pretrain_score))),
            breakout_confidence=max(0.0, min(1.0, float(breakout_confidence))),
            val_accuracy=max(0.0, min(1.0, float(val_accuracy))),
            labeled_examples=max(0, int(labeled_examples)),
            updated_at=time.time(),
        )
        self._persist_state()

    def get_symbol_prior(self, symbol: str) -> Optional[PromotionPrior]:
        return self._priors.get(str(symbol or "").upper().strip())

    def set_dynamic_policy(
        self,
        score_threshold_offset: float = 0.0,
        min_trades_offset: int = 0,
        max_live_symbols_override: Optional[int] = None,
    ) -> None:
        self._dynamic_score_threshold_offset = float(score_threshold_offset)
        self._dynamic_min_trades_offset = int(min_trades_offset)
        self._dynamic_max_live_symbols_override = int(max_live_symbols_override) if max_live_symbols_override is not None else None

    def _required_sim_trades(self, symbol: str) -> int:
        required = int(self.config.min_sim_trades)
        if not self.config.use_pretrain_prior:
            return required
        prior = self._priors.get(symbol)
        if prior is None:
            return required
        reduction = 0
        if prior.pretrain_score >= self.config.pretrain_bonus_threshold:
            reduction += 1
        if prior.breakout_confidence >= self.config.breakout_bonus_threshold:
            reduction += 1
        reduction = min(reduction, int(self.config.max_min_trades_reduction))
        dyn = int(self._dynamic_min_trades_offset)
        return max(int(self.config.min_sim_trades_floor), required - reduction + dyn)

    def _sim_score(self, t: SymbolSimTracker) -> float:
        wr_score = max(0.0, min(1.0, t.sim_win_rate))
        pf_raw = t.sim_profit_factor
        pf_score = 0.0
        if pf_raw > 0:
            pf_score = max(0.0, min(1.0, (pf_raw - 1.0) / max(self.config.min_sim_profit_factor - 1.0, 1e-9)))
        avg_pnl_score = 1.0 if t.sim_avg_pnl >= self.config.min_sim_avg_pnl else 0.0
        dd_score = 1.0
        if self.config.max_sim_drawdown_pct > 0:
            dd_score = max(0.0, min(1.0, 1.0 - (t.sim_drawdown_pct / self.config.max_sim_drawdown_pct)))
        trade_score = max(0.0, min(1.0, t.sim_trade_count / max(float(self.config.min_sim_trades), 1.0)))
        return (
            0.35 * wr_score +
            0.25 * pf_score +
            0.15 * avg_pnl_score +
            0.15 * dd_score +
            0.10 * trade_score
        )

    def _promotion_score(self, symbol: str, t: SymbolSimTracker) -> float:
        sim_score = self._sim_score(t)
        if not self.config.use_pretrain_prior:
            return sim_score
        prior = self._priors.get(symbol)
        if prior is None:
            return sim_score
        total_w = max(1e-9, self.config.sim_score_weight + self.config.pretrain_score_weight + self.config.breakout_conf_weight)
        combo = (
            self.config.sim_score_weight * sim_score +
            self.config.pretrain_score_weight * prior.pretrain_score +
            self.config.breakout_conf_weight * prior.breakout_confidence
        ) / total_w
        return max(0.0, min(1.0, combo))

    def check_demotions(self) -> List[str]:
        """Check all live symbols and return any that should be demoted."""
        demoted = []
        for sym, t in self._trackers.items():
            if not t.promoted:
                continue

            should_demote = False
            reason = ""

            if t.live_loss_streak >= self.config.demotion_live_loss_streak:
                should_demote = True
                reason = f"loss_streak={t.live_loss_streak}"

            if (t.live_trades >= 8 and
                    t.live_win_rate < self.config.demotion_live_win_rate_floor):
                should_demote = True
                reason = f"live_WR={t.live_win_rate:.0%}"

            if should_demote:
                t.promoted = False
                t.demoted_at = time.time()
                demoted.append(sym)
                LOG.warning("DEMOTED FROM LIVE: %s | reason=%s | live: %d trades, WR=%.0f%%, PnL=%+.4f",
                            sym, reason, t.live_trades,
                            t.live_win_rate * 100, t.live_pnl)

        if demoted:
            self._persist_state()
        return demoted

    def is_promoted(self, symbol: str) -> bool:
        """Check if a symbol currently has live trading approval."""
        t = self._trackers.get(symbol)
        return t.promoted if t else False

    def get_tracker(self, symbol: str) -> Optional[SymbolSimTracker]:
        return self._trackers.get(symbol)

    def get_all_trackers(self) -> Dict[str, SymbolSimTracker]:
        return dict(self._trackers)

    def get_promoted_symbols(self) -> List[str]:
        return [sym for sym, t in self._trackers.items() if t.promoted]

    def get_promotion_candidates(self) -> List[str]:
        """Symbols close to promotion (have trades but not yet promoted)."""
        candidates = []
        for sym, t in self._trackers.items():
            if t.promoted:
                continue
            if t.sim_trade_count >= max(1, self.config.min_sim_trades // 2):
                candidates.append(sym)
        return candidates

    def summary(self) -> Dict[str, Any]:
        """Return a summary of all tracked symbols."""
        return {
            "total_tracked": len(self._trackers),
            "promoted_count": sum(1 for t in self._trackers.values() if t.promoted),
            "policy": {
                "score_threshold_offset": round(self._dynamic_score_threshold_offset, 4),
                "min_trades_offset": int(self._dynamic_min_trades_offset),
                "max_live_symbols_override": self._dynamic_max_live_symbols_override,
            },
            "symbols": {sym: {**t.to_dict(), "promotion_score": round(self._promotion_score(sym, t), 4), "required_sim_trades": self._required_sim_trades(sym)} for sym, t in sorted(
                self._trackers.items(),
                key=lambda x: x[1].total_pnl,
                reverse=True,
            )},
            "priors": {sym: p.to_dict() for sym, p in self._priors.items()},
        }

    # ── Persistence ──────────────────────────────────────────────────────

    def _persist_state(self) -> None:
        try:
            data = {
                "ts": time.time(),
                "config": {
                    "min_sim_trades": self.config.min_sim_trades,
                    "min_sim_win_rate": self.config.min_sim_win_rate,
                    "min_sim_profit_factor": self.config.min_sim_profit_factor,
                    "promotion_score_threshold": self.config.promotion_score_threshold,
                    "use_pretrain_prior": self.config.use_pretrain_prior,
                },
                "trackers": {sym: t.to_dict() for sym, t in self._trackers.items()},
                "priors": {sym: p.to_dict() for sym, p in self._priors.items()},
            }
            atomic_write_json(self.config.persist_file, data)
        except Exception as e:
            LOG.warning("Failed to persist promotion state: %s", e)

    def _load_state(self) -> None:
        if not os.path.exists(self.config.persist_file):
            return
        try:
            with open(self.config.persist_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            for sym, td in data.get("trackers", {}).items():
                td = dict(td)
                td.setdefault("symbol", sym)
                self._trackers[sym] = SymbolSimTracker.from_dict(td)
            for sym, pd in data.get("priors", {}).items():
                pd = dict(pd)
                pd.setdefault("symbol", sym)
                self._priors[sym] = PromotionPrior.from_dict(pd)
            LOG.info("Loaded promotion state: %d symbols (%d promoted, %d priors)",
                     len(self._trackers),
                     sum(1 for t in self._trackers.values() if t.promoted),
                     len(self._priors))
        except Exception as e:
            LOG.warning("Failed to load promotion state: %s", e)
