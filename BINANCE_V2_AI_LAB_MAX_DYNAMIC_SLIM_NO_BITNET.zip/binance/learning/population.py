"""Homeostatic population manager for multi-symbol orchestration.

Keeps the overall symbol population in a healthy operating range by
adjusting scanner aggressiveness and promotion strictness from system
feedback rather than fixed constants alone.
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional

from core.helpers import atomic_write_json

LOG = logging.getLogger("aster.population")


@dataclass
class PopulationConfig:
    persist_file: str = "population_state.json"
    target_live_min: int = 1
    target_live_max: int = 3
    target_sim_min: int = 3
    target_sim_max: int = 8
    healthy_live_wr: float = 0.52
    healthy_live_pnl_floor: float = 0.0
    stress_live_loss_streak: int = 2
    stress_live_dd_pnl: float = -10.0
    update_interval_sec: float = 15.0
    scanner_expand_threshold_offset: float = -0.03
    scanner_defensive_threshold_offset: float = 0.05
    scanner_expand_cooldown_mult: float = 0.85
    scanner_defensive_cooldown_mult: float = 1.20
    promotion_expand_threshold_offset: float = -0.03
    promotion_defensive_threshold_offset: float = 0.05
    promotion_expand_min_trades_offset: int = -1
    promotion_defensive_min_trades_offset: int = 1
    expand_quality_floor: float = 0.58
    defensive_quality_ceiling: float = 0.42
    min_quality_to_keep_population_open: float = 0.30


class PopulationManager:
    def __init__(self, config: Optional[PopulationConfig] = None):
        self.config = config or PopulationConfig()
        self.mode = "NORMAL"
        self.last_update = 0.0
        self.last_snapshot: Dict[str, Any] = {}
        self._load_state()

    def _clamp01(self, x: float) -> float:
        return max(0.0, min(1.0, float(x)))

    def _safe_avg(self, vals):
        vals = list(vals)
        return (sum(vals) / len(vals)) if vals else 0.0

    def evaluate(self, promotion_engine, sim_count: int, live_count: int, max_live_symbols: int, max_sim_symbols: int) -> Dict[str, Any]:
        trackers = promotion_engine.get_all_trackers() if promotion_engine else {}
        live_trackers = [t for t in trackers.values() if getattr(t, 'promoted', False)]
        sim_trackers = [t for t in trackers.values() if getattr(t, 'sim_trade_count', 0) > 0 and not getattr(t, 'promoted', False)]

        avg_live_wr = self._safe_avg(getattr(t, 'live_win_rate', 0.0) for t in live_trackers if getattr(t, 'live_trades', 0) > 0)
        avg_live_pnl = self._safe_avg(getattr(t, 'live_pnl', 0.0) for t in live_trackers)
        avg_sim_wr = self._safe_avg(getattr(t, 'sim_win_rate', 0.0) for t in sim_trackers if getattr(t, 'sim_trade_count', 0) > 0)
        avg_sim_pf = self._safe_avg(getattr(t, 'sim_profit_factor', 0.0) for t in sim_trackers if getattr(t, 'sim_trade_count', 0) > 0)
        max_live_loss_streak = max([getattr(t, 'live_loss_streak', 0) for t in live_trackers] + [0])
        live_negative = sum(1 for t in live_trackers if getattr(t, 'live_pnl', 0.0) < 0)

        capacity_util = (live_count / max(1, max_live_symbols)) if max_live_symbols > 0 else 0.0
        sim_util = (sim_count / max(1, max_sim_symbols)) if max_sim_symbols > 0 else 0.0

        wr_score = self._clamp01(avg_live_wr / max(self.config.healthy_live_wr, 1e-9)) if live_trackers else 0.55
        pnl_score = 0.5
        if live_trackers:
            if avg_live_pnl >= self.config.healthy_live_pnl_floor:
                pnl_score = self._clamp01(0.5 + min(0.5, avg_live_pnl / 25.0))
            else:
                pnl_score = self._clamp01(0.5 + max(-0.5, avg_live_pnl / 25.0))
        sim_score = self._clamp01(0.5 * avg_sim_wr + 0.5 * min(1.0, avg_sim_pf / 2.0)) if sim_trackers else 0.45
        diversity_score = self._clamp01(1.0 - max(0.0, (live_negative - 1) * 0.2))
        stress_penalty = 0.0
        if max_live_loss_streak >= self.config.stress_live_loss_streak:
            stress_penalty += 0.18
        if avg_live_pnl <= self.config.stress_live_dd_pnl:
            stress_penalty += 0.18
        if capacity_util > 1.0:
            stress_penalty += 0.15

        quality = self._clamp01(0.30 * wr_score + 0.20 * pnl_score + 0.20 * sim_score + 0.10 * diversity_score + 0.10 * (1.0 - min(1.0, capacity_util)) + 0.10 * (1.0 - min(1.0, sim_util)) - stress_penalty)

        desired_mode = "NORMAL"
        if quality >= self.config.expand_quality_floor and live_count < self.config.target_live_max and max_live_loss_streak <= 1:
            desired_mode = "EXPAND"
        elif quality <= self.config.defensive_quality_ceiling or max_live_loss_streak >= self.config.stress_live_loss_streak or avg_live_pnl <= self.config.stress_live_dd_pnl:
            desired_mode = "DEFENSIVE"

        self.mode = desired_mode
        snapshot = {
            "ts": time.time(),
            "mode": self.mode,
            "quality": round(quality, 4),
            "sim_count": int(sim_count),
            "live_count": int(live_count),
            "tracked_symbols": len(trackers),
            "avg_live_wr": round(avg_live_wr, 4),
            "avg_live_pnl": round(avg_live_pnl, 4),
            "avg_sim_wr": round(avg_sim_wr, 4),
            "avg_sim_pf": round(avg_sim_pf, 4),
            "max_live_loss_streak": int(max_live_loss_streak),
            "capacity_util": round(capacity_util, 4),
            "sim_util": round(sim_util, 4),
        }
        self.last_snapshot = snapshot
        return snapshot

    def controls(self, max_live_symbols: int, max_sim_symbols: int) -> Dict[str, Any]:
        mode = self.mode
        scanner_thr = 0.0
        scanner_cd = 1.0
        promo_thr = 0.0
        promo_trades = 0
        live_cap = max_live_symbols
        sim_cap = max_sim_symbols

        if mode == "EXPAND":
            scanner_thr = self.config.scanner_expand_threshold_offset
            scanner_cd = self.config.scanner_expand_cooldown_mult
            promo_thr = self.config.promotion_expand_threshold_offset
            promo_trades = self.config.promotion_expand_min_trades_offset
            live_cap = max_live_symbols + 1
            sim_cap = max_sim_symbols + 1
        elif mode == "DEFENSIVE":
            scanner_thr = self.config.scanner_defensive_threshold_offset
            scanner_cd = self.config.scanner_defensive_cooldown_mult
            promo_thr = self.config.promotion_defensive_threshold_offset
            promo_trades = self.config.promotion_defensive_min_trades_offset
            live_cap = max(1, max_live_symbols - 1)
            sim_cap = max(2, max_sim_symbols - 1)

        controls = {
            "mode": mode,
            "scanner_threshold_offset": float(scanner_thr),
            "scanner_cooldown_mult": float(scanner_cd),
            "promotion_threshold_offset": float(promo_thr),
            "promotion_min_trades_offset": int(promo_trades),
            "live_cap": int(live_cap),
            "sim_cap": int(sim_cap),
        }
        return controls

    def maybe_update(self, promotion_engine, scanner, sim_count: int, live_count: int, max_live_symbols: int, max_sim_symbols: int) -> Dict[str, Any]:
        now = time.time()
        if self.last_update > 0 and (now - self.last_update) < max(3.0, self.config.update_interval_sec):
            return {**self.last_snapshot, **self.controls(max_live_symbols, max_sim_symbols)} if self.last_snapshot else self.controls(max_live_symbols, max_sim_symbols)

        snapshot = self.evaluate(promotion_engine, sim_count=sim_count, live_count=live_count, max_live_symbols=max_live_symbols, max_sim_symbols=max_sim_symbols)
        controls = self.controls(max_live_symbols=max_live_symbols, max_sim_symbols=max_sim_symbols)
        self.last_update = now
        self._persist_state({**snapshot, "controls": controls})

        if scanner is not None and hasattr(scanner, 'set_homeostatic_controls'):
            scanner.set_homeostatic_controls(
                threshold_offset=controls["scanner_threshold_offset"],
                cooldown_mult=controls["scanner_cooldown_mult"],
                max_concurrent_symbols=controls["sim_cap"],
            )
        if promotion_engine is not None and hasattr(promotion_engine, 'set_dynamic_policy'):
            promotion_engine.set_dynamic_policy(
                score_threshold_offset=controls["promotion_threshold_offset"],
                min_trades_offset=controls["promotion_min_trades_offset"],
                max_live_symbols_override=controls["live_cap"],
            )
        return {**snapshot, **controls}

    def _persist_state(self, payload: Dict[str, Any]) -> None:
        try:
            atomic_write_json(self.config.persist_file, payload)
        except Exception as e:
            LOG.warning("Failed to persist population state: %s", e)

    def _load_state(self) -> None:
        path = self.config.persist_file
        if not path or not os.path.exists(path):
            return
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.mode = str(data.get('mode', self.mode) or 'NORMAL').upper()
            self.last_snapshot = dict(data)
            self.last_update = float(data.get('ts', 0.0))
        except Exception as e:
            LOG.warning("Failed to load population state: %s", e)
