"""Online logistic regression with running normalization.

Upgraded with richer derived features while keeping the same public
predict_proba(raw) interface used by the rest of the bot.
"""

from __future__ import annotations

import json
import logging
import math
import os
import time
from typing import Dict

from core.helpers import utc_ts, atomic_write_json, sigmoidf
from core.config import Config

LOG = logging.getLogger("aster")


class RunningNorm:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0

    def update(self, x: float) -> None:
        self.n += 1
        delta = x - self.mean
        self.mean += delta / self.n
        delta2 = x - self.mean
        self.m2 += delta * delta2

    def std(self) -> float:
        if self.n < 2:
            return 1.0
        return math.sqrt(max(self.m2 / (self.n - 1), 1e-9))

    def z(self, x: float) -> float:
        return (x - self.mean) / self.std()


class OnlineLogReg:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.features = [
            "ofi", "abs_ofi", "ofi_delta", "slope",
            "vol_bps", "vol_ratio", "spread_bps", "spread_vol_ratio",
            "wall_log", "wall_pressure", "ma_gap_bps",
        ]
        self.w: Dict[str, float] = {k: 0.0 for k in self.features}
        self.b: float = 0.0
        self.norm: Dict[str, RunningNorm] = {k: RunningNorm() for k in self.features}
        self.trained_examples: int = 0
        self.pending_updates: int = 0
        self.last_save_ts: float = 0.0

    def _clip(self, x: float) -> float:
        return max(-self.cfg.LEARN_CLIP, min(self.cfg.LEARN_CLIP, x))

    def _raw_to_features(self, raw: Dict[str, float]) -> Dict[str, float]:
        ofi = float(raw.get("ofi", 0.0))
        slope = float(raw.get("slope", 0.0))
        vol_bps = max(0.0, float(raw.get("vol_bps", 0.0)))
        spread_bps = max(0.0, float(raw.get("spread_bps", 0.0)))
        wall_log = float(raw.get("wall_log", 0.0))
        ofi_prev = float(raw.get("ofi_prev", 0.0))
        vol_med = max(1e-9, float(raw.get("vol_med", raw.get("vol_bps", 1.0) or 1.0)))
        ma_gap_bps = float(raw.get("ma_gap_bps", 0.0))
        return {
            "ofi": ofi,
            "abs_ofi": abs(ofi),
            "ofi_delta": ofi - ofi_prev,
            "slope": slope,
            "vol_bps": vol_bps,
            "vol_ratio": vol_bps / vol_med,
            "spread_bps": spread_bps,
            "spread_vol_ratio": spread_bps / max(0.5, vol_bps),
            "wall_log": wall_log,
            "wall_pressure": wall_log / max(0.25, spread_bps),
            "ma_gap_bps": ma_gap_bps,
        }

    def featurize(self, raw: Dict[str, float], do_update_norm: bool) -> Dict[str, float]:
        packed = self._raw_to_features(raw)
        x: Dict[str, float] = {}
        for k in self.features:
            v = float(packed.get(k, 0.0))
            if do_update_norm:
                self.norm[k].update(v)
            x[k] = self.norm[k].z(v)
        return x

    def predict_proba(self, raw: Dict[str, float]) -> float:
        x = self.featurize(raw, do_update_norm=False)
        s = self.b + sum(self.w.get(k, 0.0) * x[k] for k in self.features)
        return sigmoidf(s)

    def update_one(self, raw: Dict[str, float], y: int) -> None:
        x = self.featurize(raw, do_update_norm=True)
        p = sigmoidf(self.b + sum(self.w.get(k, 0.0) * x[k] for k in self.features))
        g = self._clip(p - float(y))
        lr = self.cfg.LEARN_LR
        l2 = self.cfg.LEARN_L2
        for k in self.features:
            self.w[k] = float(self.w.get(k, 0.0)) - lr * (g * x[k] + l2 * float(self.w.get(k, 0.0)))
        self.b -= lr * g
        self.trained_examples += 1
        self.pending_updates += 1

    def maybe_save(self, force: bool = False) -> None:
        now = time.time()
        if (not force) and (now - self.last_save_ts) < 6.0:
            return
        self.last_save_ts = now
        payload = {
            "ts": utc_ts(),
            "features": self.features,
            "w": self.w,
            "b": self.b,
            "trained_examples": self.trained_examples,
            "norm": {k: {"n": n.n, "mean": n.mean, "m2": n.m2} for k, n in self.norm.items()},
        }
        try:
            atomic_write_json(self.cfg.MODEL_FILE, payload)
        except Exception:
            pass

    def load(self) -> bool:
        if not os.path.exists(self.cfg.MODEL_FILE):
            return False
        try:
            with open(self.cfg.MODEL_FILE, "r", encoding="utf-8") as f:
                p = json.load(f)
            feats = p.get("features") or []
            if feats:
                self.features = list(feats)
            current = [
                "ofi", "abs_ofi", "ofi_delta", "slope",
                "vol_bps", "vol_ratio", "spread_bps", "spread_vol_ratio",
                "wall_log", "wall_pressure", "ma_gap_bps",
            ]
            for k in current:
                if k not in self.features:
                    self.features.append(k)
            self.w = {k: float(p.get("w", {}).get(k, 0.0)) for k in self.features}
            self.b = float(p.get("b", 0.0))
            self.trained_examples = int(p.get("trained_examples", 0))
            nrm = p.get("norm", {}) or {}
            self.norm = {}
            for k in self.features:
                rn = RunningNorm()
                kk = nrm.get(k) or {}
                rn.n = int(kk.get("n", 0))
                rn.mean = float(kk.get("mean", 0.0))
                rn.m2 = float(kk.get("m2", 0.0))
                self.norm[k] = rn
            return True
        except Exception:
            return False
