"""Kline-based model pre-trainer.

Synthesizes training data from historical klines and pre-trains the
OnlineLogReg model BEFORE the live engine starts. This replaces hours
of real-time learning with seconds of historical backtesting.

How it works:
  1. Takes kline data (already fetched by research scanner)
  2. Computes the same 5 features the live model uses:
     - ofi (approximated from volume imbalance between candles)
     - slope (MA direction)
     - vol_bps (rolling volatility)
     - spread_bps (approximated from high-low range)
     - wall_log (approximated from volume)
  3. Labels each bar: did price go UP or DOWN by threshold in next N bars?
  4. Trains the model on all labeled examples
  5. Saves the pre-trained model so live engine loads it warm

The live model features are designed for tick-level order book data,
so kline-derived features are approximations. But they capture the
same underlying patterns (momentum, volatility, directional flow)
and give the model a massive head start vs cold start.
"""

from __future__ import annotations

import logging
import math
import time
from collections import deque
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional, Tuple
import json

from core.config import Config
from core.helpers import D0, d
from learning.model import OnlineLogReg, RunningNorm
from research.features import CandleSeries, safe_float, std, rolling_mean

LOG = logging.getLogger("aster.pretrain")


# ── Feature synthesis from klines ────────────────────────────────────────────

def _rolling_vol_bps(closes: List[float], i: int, window: int) -> float:
    """Compute rolling volatility in bps from close prices."""
    if i < window + 1:
        return 0.0
    sub = closes[i - window:i + 1]
    if len(sub) < 3 or min(sub) <= 0:
        return 0.0
    rets = [(b - a) / a for a, b in zip(sub, sub[1:]) if a > 0]
    if not rets:
        return 0.0
    return std(rets) * 10000.0


def _rolling_ma(closes: List[float], i: int, window: int) -> Optional[float]:
    """Simple moving average."""
    if i < window:
        return None
    sub = closes[i - window + 1:i + 1]
    return sum(sub) / len(sub) if sub else None


def _slope_dir(closes: List[float], i: int, ma_len: int, slope_len: int) -> int:
    """MA slope direction: 1=up, -1=down, 0=flat."""
    if i < ma_len + slope_len:
        return 0
    ma_now = _rolling_ma(closes, i, ma_len)
    ma_prev = _rolling_ma(closes, i - slope_len, ma_len)
    if ma_now is None or ma_prev is None:
        return 0
    if ma_now > ma_prev:
        return 1
    if ma_now < ma_prev:
        return -1
    return 0


def _approx_spread_bps(high: float, low: float, close: float) -> float:
    """Approximate spread from candle range (high-low captures spread + vol)."""
    if close <= 0:
        return 0.0
    # The minimum intra-candle range is a rough proxy for spread
    # Use a fraction of the range as spread estimate
    rng = high - low
    return min(rng / close * 10000.0 * 0.15, 50.0)  # cap at 50 bps


def _approx_ofi(volumes: List[float], closes: List[float], i: int, window: int = 10) -> float:
    """Approximate order flow imbalance from volume and price direction.

    When price goes up on volume, that's buying pressure (positive OFI).
    When price goes down on volume, that's selling pressure (negative OFI).
    """
    if i < window + 1:
        return 0.0
    buy_vol = 0.0
    sell_vol = 0.0
    for j in range(i - window + 1, i + 1):
        if j < 1 or j >= len(closes):
            continue
        vol = volumes[j] if j < len(volumes) else 0.0
        if closes[j] > closes[j - 1]:
            buy_vol += vol
        elif closes[j] < closes[j - 1]:
            sell_vol += vol
        else:
            buy_vol += vol * 0.5
            sell_vol += vol * 0.5
    total = buy_vol + sell_vol
    if total <= 0:
        return 0.0
    return (buy_vol - sell_vol) / total


def _wall_log_approx(volume: float) -> float:
    """Approximate wall_log from volume (log1p of volume as liquidity proxy)."""
    return math.log1p(max(0.0, volume))


def synthesize_features(candles: CandleSeries, ma_len: int = 21,
                        slope_len: int = 10, vol_window: int = 20) -> List[Dict[str, float]]:
    """Convert kline candles into the 5-feature vectors the model expects.

    Returns one feature dict per bar (starting after warmup period).
    """
    closes = candles.close
    highs = candles.high
    lows = candles.low
    volumes = candles.quote_volume if candles.quote_volume else candles.volume
    n = len(closes)
    warmup = max(ma_len + slope_len + 5, vol_window + 5)

    features: List[Dict[str, float]] = []
    for i in range(warmup, n):
        ofi = _approx_ofi(volumes, closes, i)
        slope = float(_slope_dir(closes, i, ma_len, slope_len))
        vol_bps = _rolling_vol_bps(closes, i, vol_window)
        spread_bps = _approx_spread_bps(highs[i], lows[i], closes[i])
        wall_log = _wall_log_approx(volumes[i] if i < len(volumes) else 0.0)

        features.append({
            "ofi": ofi,
            "slope": slope,
            "vol_bps": vol_bps,
            "spread_bps": spread_bps,
            "wall_log": wall_log,
        })
    return features


def label_features(closes: List[float], features: List[Dict[str, float]],
                   start_idx: int, horizon: int = 12,
                   threshold_bps: float = 3.0) -> List[Tuple[Dict[str, float], int]]:
    """Label each feature vector: 1 if price goes up by threshold, 0 if down.

    Skips bars where the move is below threshold (ambiguous).

    Args:
        closes: full close price series
        features: feature dicts (one per bar starting at start_idx)
        start_idx: index in closes where features[0] corresponds
        horizon: how many bars forward to check
        threshold_bps: minimum move in bps to count as up/down
    """
    labeled = []
    for fi, feat in enumerate(features):
        bar_idx = start_idx + fi
        if bar_idx + horizon >= len(closes):
            break
        price_now = closes[bar_idx]
        price_future = closes[bar_idx + horizon]
        if price_now <= 0:
            continue
        move_bps = (price_future - price_now) / price_now * 10000.0
        if move_bps >= threshold_bps:
            labeled.append((feat, 1))  # UP
        elif move_bps <= -threshold_bps:
            labeled.append((feat, 0))  # DOWN
        # else: skip ambiguous
    return labeled




@dataclass
class BreakoutProfile:
    symbol: str
    range_breakout_pct: float
    volume_surge_mult: float
    vol_expand_mult: float
    ofi_z_threshold: float
    score_bias: float
    cooldown_mult: float
    confidence: float
    labeled_examples: int
    val_accuracy: float


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(v)))


def _percentile(vals: List[float], pct: float) -> float:
    if not vals:
        return 0.0
    ordered = sorted(float(v) for v in vals)
    if len(ordered) == 1:
        return ordered[0]
    pct = _clamp(pct, 0.0, 100.0)
    idx = (len(ordered) - 1) * pct / 100.0
    lo = int(math.floor(idx))
    hi = int(math.ceil(idx))
    if lo == hi:
        return ordered[lo]
    frac = idx - lo
    return ordered[lo] * (1.0 - frac) + ordered[hi] * frac


def build_breakout_profile_from_klines(
    candles: CandleSeries,
    symbol: str,
    result: Optional[PretrainResult] = None,
    ma_len: int = 21,
    slope_len: int = 10,
    vol_window: int = 20,
    horizon: int = 12,
    threshold_bps: float = 3.0,
) -> Optional[BreakoutProfile]:
    """Derive symbol-specific breakout thresholds from pretrain data.

    The goal is not to predict breakouts directly here, but to use historical
    distributions to make the live scanner less static and more symbol-aware.
    """
    closes = candles.close
    highs = candles.high
    lows = candles.low
    volumes = candles.quote_volume if candles.quote_volume else candles.volume
    n = len(closes)
    warmup = max(ma_len + slope_len + 5, vol_window + 5)
    if n < warmup + horizon + 25:
        return None

    abs_rets_bps: List[float] = []
    vol_ratios: List[float] = []
    vol_expand_ratios: List[float] = []
    ofi_z_abs: List[float] = []
    spreads_bps: List[float] = []

    ofi_hist: List[float] = []
    for i in range(warmup, n - horizon):
        px = closes[i]
        prev = closes[i - 1] if i >= 1 else px
        if px > 0 and prev > 0:
            abs_rets_bps.append(abs((px - prev) / prev) * 10000.0)

        base_vol = volumes[max(0, i - 20):i]
        avg_vol = sum(base_vol) / len(base_vol) if base_vol else 0.0
        cur_vol = volumes[i] if i < len(volumes) else 0.0
        if avg_vol > 0:
            vol_ratios.append(cur_vol / avg_vol)

        recent_vol = _rolling_vol_bps(closes, i, min(10, vol_window))
        base_hist = []
        for j in range(max(warmup, i - vol_window), i):
            rv = _rolling_vol_bps(closes, j, min(10, vol_window))
            if rv > 0:
                base_hist.append(rv)
        base_vol_bps = sum(base_hist) / len(base_hist) if base_hist else 0.0
        if base_vol_bps > 0 and recent_vol > 0:
            vol_expand_ratios.append(recent_vol / base_vol_bps)

        spreads_bps.append(_approx_spread_bps(highs[i], lows[i], px))

        ofi_val = _approx_ofi(volumes, closes, i)
        ofi_hist.append(ofi_val)
        if len(ofi_hist) >= 20:
            base = ofi_hist[-20:]
            mu = sum(base) / len(base)
            sd = std(base)
            if sd > 1e-9:
                ofi_z_abs.append(abs((ofi_val - mu) / sd))

    val_acc = result.val_accuracy if result else 0.5
    labeled = result.labeled_examples if result else 0

    move_p = _percentile(abs_rets_bps, 92.0)
    vol_ratio_p = _percentile(vol_ratios, 88.0)
    vol_expand_p = _percentile(vol_expand_ratios, 85.0)
    ofi_z_p = _percentile(ofi_z_abs, 85.0)
    spread_p50 = _percentile(spreads_bps, 50.0)

    conf = _clamp((val_acc - 0.50) / 0.12, 0.0, 1.0)
    sample_boost = _clamp(labeled / 250.0, 0.0, 1.0)
    confidence = _clamp(0.65 * conf + 0.35 * sample_boost, 0.0, 1.0)

    # Good historical breakout models get slightly earlier triggers; weaker ones
    # require more confirmation.
    score_bias = _clamp((0.56 - val_acc) * 0.35, -0.08, 0.10)
    cooldown_mult = _clamp(1.10 - confidence * 0.25, 0.80, 1.10)

    profile = BreakoutProfile(
        symbol=symbol,
        range_breakout_pct=_clamp((move_p / 10000.0) * 1.10, 0.0008, 0.0075),
        volume_surge_mult=_clamp(max(1.15, vol_ratio_p * 0.95), 1.15, 3.25),
        vol_expand_mult=_clamp(max(1.05, vol_expand_p * 0.96), 1.05, 2.75),
        ofi_z_threshold=_clamp(max(1.05, ofi_z_p * 0.95), 1.05, 3.00),
        score_bias=score_bias,
        cooldown_mult=cooldown_mult,
        confidence=confidence,
        labeled_examples=labeled,
        val_accuracy=val_acc,
    )

    LOG.info(
        "BREAKOUT PROFILE %s: move=%.4f%% volx=%.2f vol_expand=%.2f ofi_z=%.2f bias=%+.3f conf=%.2f spread50=%.2f",
        symbol,
        profile.range_breakout_pct * 100.0,
        profile.volume_surge_mult,
        profile.vol_expand_mult,
        profile.ofi_z_threshold,
        profile.score_bias,
        profile.confidence,
        spread_p50,
    )
    return profile


def _breakout_profile_path(symbol: str) -> str:
    return f"SIM_{symbol}_breakout_profile.json"


def save_breakout_profile(profile: BreakoutProfile) -> None:
    try:
        with open(_breakout_profile_path(profile.symbol), "w", encoding="utf-8") as f:
            json.dump(asdict(profile), f, indent=2, sort_keys=True)
    except Exception as e:
        LOG.warning("Failed saving breakout profile for %s: %s", profile.symbol, e)


def load_breakout_profile(symbol: str) -> Optional[BreakoutProfile]:
    path = _breakout_profile_path(symbol)
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        return BreakoutProfile(
            symbol=str(raw.get("symbol") or symbol),
            range_breakout_pct=float(raw.get("range_breakout_pct", 0.0015)),
            volume_surge_mult=float(raw.get("volume_surge_mult", 2.0)),
            vol_expand_mult=float(raw.get("vol_expand_mult", 1.6)),
            ofi_z_threshold=float(raw.get("ofi_z_threshold", 1.5)),
            score_bias=float(raw.get("score_bias", 0.0)),
            cooldown_mult=float(raw.get("cooldown_mult", 1.0)),
            confidence=float(raw.get("confidence", 0.0)),
            labeled_examples=int(raw.get("labeled_examples", 0)),
            val_accuracy=float(raw.get("val_accuracy", 0.0)),
        )
    except FileNotFoundError:
        return None
    except Exception as e:
        LOG.warning("Failed loading breakout profile for %s: %s", symbol, e)
        return None

# ── Pre-trainer ──────────────────────────────────────────────────────────────

@dataclass
class PretrainResult:
    symbol: str
    total_bars: int
    labeled_examples: int
    up_labels: int
    down_labels: int
    skipped_ambiguous: int
    train_examples: int
    val_examples: int
    train_accuracy: float
    val_accuracy: float
    model_trained_total: int
    time_sec: float


def pretrain_model_from_klines(
    model: OnlineLogReg,
    candles: CandleSeries,
    symbol: str = "",
    ma_len: int = 21,
    slope_len: int = 10,
    vol_window: int = 20,
    horizon: int = 12,
    threshold_bps: float = 3.0,
    train_split: float = 0.8,
    epochs: int = 3,
) -> PretrainResult:
    """Pre-train a model from kline data.

    This is the main function the orchestrator calls. It:
      1. Synthesizes features from klines
      2. Labels them (up/down based on future price)
      3. Splits into train/val
      4. Trains the model for multiple epochs
      5. Reports accuracy

    The model is modified in-place (weights, normalizer stats, trained_examples).
    """
    t0 = time.time()

    # Synthesize features
    warmup = max(ma_len + slope_len + 5, vol_window + 5)
    features = synthesize_features(candles, ma_len, slope_len, vol_window)

    if not features:
        return PretrainResult(symbol=symbol, total_bars=len(candles.close),
                              labeled_examples=0, up_labels=0, down_labels=0,
                              skipped_ambiguous=0, train_examples=0, val_examples=0,
                              train_accuracy=0.0, val_accuracy=0.0,
                              model_trained_total=model.trained_examples,
                              time_sec=time.time() - t0)

    # Label
    labeled = label_features(candles.close, features, warmup, horizon, threshold_bps)
    up_count = sum(1 for _, y in labeled if y == 1)
    down_count = sum(1 for _, y in labeled if y == 0)
    total_features = len(features)
    skipped = total_features - len(labeled) - max(0, total_features - (len(candles.close) - warmup - horizon))

    if len(labeled) < 10:
        return PretrainResult(symbol=symbol, total_bars=len(candles.close),
                              labeled_examples=len(labeled), up_labels=up_count,
                              down_labels=down_count, skipped_ambiguous=skipped,
                              train_examples=0, val_examples=0,
                              train_accuracy=0.0, val_accuracy=0.0,
                              model_trained_total=model.trained_examples,
                              time_sec=time.time() - t0)

    # Split: earlier data for training, later for validation
    split_idx = int(len(labeled) * train_split)
    train_set = labeled[:split_idx]
    val_set = labeled[split_idx:]

    # Train for multiple epochs (shuffle within each epoch for better convergence)
    import random
    for epoch in range(epochs):
        shuffled = list(train_set)
        random.shuffle(shuffled)
        for feat, y in shuffled:
            model.update_one(feat, y)

    # Evaluate on validation set
    val_correct = 0
    for feat, y in val_set:
        p = model.predict_proba(feat)
        pred = 1 if p >= 0.5 else 0
        if pred == y:
            val_correct += 1
    val_acc = val_correct / len(val_set) if val_set else 0.0

    # Evaluate on training set
    train_correct = 0
    for feat, y in train_set:
        p = model.predict_proba(feat)
        pred = 1 if p >= 0.5 else 0
        if pred == y:
            train_correct += 1
    train_acc = train_correct / len(train_set) if train_set else 0.0

    elapsed = time.time() - t0

    LOG.info("PRETRAIN %s: %d bars → %d labeled (↑%d ↓%d skip=%d) | "
             "train=%d val=%d | acc=%.1f%%/%.1f%% | %.2fs | model=%d examples",
             symbol, len(candles.close), len(labeled), up_count, down_count, skipped,
             len(train_set), len(val_set), train_acc * 100, val_acc * 100,
             elapsed, model.trained_examples)

    return PretrainResult(
        symbol=symbol,
        total_bars=len(candles.close),
        labeled_examples=len(labeled),
        up_labels=up_count,
        down_labels=down_count,
        skipped_ambiguous=skipped,
        train_examples=len(train_set),
        val_examples=len(val_set),
        train_accuracy=train_acc,
        val_accuracy=val_acc,
        model_trained_total=model.trained_examples,
        time_sec=elapsed,
    )


def pretrain_all_symbols(
    client,  # PublicFuturesClient
    symbols: List[str],
    cfg: Config,
    kline_interval: str = "5m",
    kline_limit: int = 500,
    horizon: int = 12,
    threshold_bps: float = 3.0,
    epochs: int = 3,
) -> Dict[str, PretrainResult]:
    """Pre-train models for multiple symbols. Returns results per symbol.

    Called by the orchestrator at startup to warm-start all models.
    Each symbol gets its own model file saved to SIM_{SYMBOL}_lr_model.json.
    """
    from core.config import per_symbol_paths
    from research.features import series_from_klines

    results: Dict[str, PretrainResult] = {}
    t0 = time.time()

    LOG.info("PRE-TRAINING models for %d symbols (klines=%s, limit=%d, horizon=%d, thr=%.1f bps, epochs=%d)",
             len(symbols), kline_interval, kline_limit, horizon, threshold_bps, epochs)

    for sym in symbols:
        try:
            # Fetch klines
            kl = client.klines(sym, interval=kline_interval, limit=kline_limit)
            candles = series_from_klines(kl)
            if len(candles.close) < 80:
                LOG.debug("PRETRAIN skip %s: only %d candles", sym, len(candles.close))
                continue

            # Create model for this symbol
            sym_cfg = Config()
            # Copy learning params from base config
            sym_cfg.LEARN_LR = cfg.LEARN_LR
            sym_cfg.LEARN_L2 = cfg.LEARN_L2
            sym_cfg.LEARN_CLIP = cfg.LEARN_CLIP
            sym_cfg.SYMBOL = sym
            sym_cfg.MODEL_FILE = f"SIM_{sym}_lr_model.json"

            model = OnlineLogReg(sym_cfg)
            # Try loading existing model to continue training
            model.load()

            result = pretrain_model_from_klines(
                model=model,
                candles=candles,
                symbol=sym,
                ma_len=cfg.MA_LENGTH,
                slope_len=cfg.MA_SLOPE_LEN,
                vol_window=min(20, cfg.VOL_ROLL_LEN),
                horizon=horizon,
                threshold_bps=threshold_bps,
                epochs=epochs,
            )

            if result.labeled_examples >= 10:
                model.maybe_save(force=True)
                profile = build_breakout_profile_from_klines(
                    candles=candles,
                    symbol=sym,
                    result=result,
                    ma_len=cfg.MA_LENGTH,
                    slope_len=cfg.MA_SLOPE_LEN,
                    vol_window=min(20, cfg.VOL_ROLL_LEN),
                    horizon=horizon,
                    threshold_bps=threshold_bps,
                )
                if profile is not None:
                    save_breakout_profile(profile)
                results[sym] = result

            time.sleep(0.02)  # rate limit

        except Exception as e:
            LOG.warning("PRETRAIN error for %s: %s", sym, e)

    total_time = time.time() - t0
    total_examples = sum(r.train_examples * epochs for r in results.values())
    avg_val_acc = sum(r.val_accuracy for r in results.values()) / len(results) if results else 0

    LOG.info("PRE-TRAINING COMPLETE: %d symbols, %d total examples, avg val acc=%.1f%%, %.1fs",
             len(results), total_examples, avg_val_acc * 100, total_time)

    return results
