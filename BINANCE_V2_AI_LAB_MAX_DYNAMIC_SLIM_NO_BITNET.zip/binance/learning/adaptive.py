"""Adaptive learner: online parameter tuning based on live trade outcomes.

Tracks per-symbol performance and adjusts config parameters on the fly.
Works in both sim and live mode. Learns which parameter settings work
best for each market regime and adapts accordingly.

Key features:
  - Per-symbol performance tracking (win rate, PnL, drawdown)
  - Bayesian-inspired parameter adjustment (shrink toward priors)
  - Regime-aware: different settings for trending vs ranging markets
  - Continuous recalibration of quality gates and TP/SL
  - Warm-start from research recommendations, refine online
"""

from __future__ import annotations

import json
import logging
import math
import os
import time
from collections import deque
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Deque, Dict, List, Optional, Tuple

from core.helpers import D0, d, clamp, atomic_write_json

LOG = logging.getLogger("aster.adaptive")


@dataclass
class TradeRecord:
    """Single trade outcome."""
    symbol: str
    direction: str        # LONG / SHORT
    pnl: float
    entry_price: float
    exit_price: float
    held_sec: float
    exit_reason: str      # TP, SL, TRAIL, etc.
    regime: str           # from research snapshot
    timestamp: float = 0.0

    def __post_init__(self):
        if self.timestamp <= 0:
            self.timestamp = time.time()


@dataclass
class SymbolPerformance:
    """Rolling performance statistics for one symbol."""
    symbol: str
    trades: Deque[TradeRecord] = field(default_factory=lambda: deque(maxlen=500))
    total_pnl: float = 0.0
    peak_pnl: float = 0.0
    max_drawdown: float = 0.0
    current_streak: int = 0  # positive = wins, negative = losses
    last_adjustment_ts: float = 0.0
    adjustment_count: int = 0

    @property
    def win_rate(self) -> float:
        if not self.trades:
            return 0.5
        wins = sum(1 for t in self.trades if t.pnl > 0)
        return wins / len(self.trades)

    @property
    def avg_pnl(self) -> float:
        if not self.trades:
            return 0.0
        return sum(t.pnl for t in self.trades) / len(self.trades)

    @property
    def avg_win(self) -> float:
        wins = [t.pnl for t in self.trades if t.pnl > 0]
        return sum(wins) / len(wins) if wins else 0.0

    @property
    def avg_loss(self) -> float:
        losses = [t.pnl for t in self.trades if t.pnl <= 0]
        return sum(losses) / len(losses) if losses else 0.0

    @property
    def profit_factor(self) -> float:
        gross_win = sum(t.pnl for t in self.trades if t.pnl > 0)
        gross_loss = abs(sum(t.pnl for t in self.trades if t.pnl < 0))
        if gross_loss <= 0:
            return 10.0 if gross_win > 0 else 1.0
        return gross_win / gross_loss

    @property
    def recent_win_rate(self) -> float:
        """Win rate over last 20 trades."""
        recent = list(self.trades)[-20:]
        if not recent:
            return 0.5
        return sum(1 for t in recent if t.pnl > 0) / len(recent)

    def sl_exit_rate(self) -> float:
        """Fraction of exits that were stop-loss."""
        if not self.trades:
            return 0.0
        sl = sum(1 for t in self.trades if t.exit_reason in ("SL", "SL_CATA"))
        return sl / len(self.trades)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "symbol": self.symbol,
            "total_pnl": self.total_pnl,
            "peak_pnl": self.peak_pnl,
            "max_drawdown": self.max_drawdown,
            "current_streak": self.current_streak,
            "last_adjustment_ts": self.last_adjustment_ts,
            "adjustment_count": self.adjustment_count,
            "trades": [
                {
                    "symbol": t.symbol,
                    "direction": t.direction,
                    "pnl": t.pnl,
                    "entry_price": t.entry_price,
                    "exit_price": t.exit_price,
                    "held_sec": t.held_sec,
                    "exit_reason": t.exit_reason,
                    "regime": t.regime,
                    "timestamp": t.timestamp,
                }
                for t in self.trades
            ],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SymbolPerformance":
        perf = cls(symbol=data.get("symbol", ""))
        perf.total_pnl = float(data.get("total_pnl", 0.0))
        perf.peak_pnl = float(data.get("peak_pnl", 0.0))
        perf.max_drawdown = float(data.get("max_drawdown", 0.0))
        perf.current_streak = int(data.get("current_streak", 0))
        perf.last_adjustment_ts = float(data.get("last_adjustment_ts", 0.0))
        perf.adjustment_count = int(data.get("adjustment_count", 0))
        for td in data.get("trades", []):
            try:
                perf.trades.append(TradeRecord(
                    symbol=td.get("symbol", perf.symbol),
                    direction=td.get("direction", "UNKNOWN"),
                    pnl=float(td.get("pnl", 0.0)),
                    entry_price=float(td.get("entry_price", 0.0)),
                    exit_price=float(td.get("exit_price", 0.0)),
                    held_sec=float(td.get("held_sec", 0.0)),
                    exit_reason=td.get("exit_reason", "UNKNOWN"),
                    regime=td.get("regime", ""),
                    timestamp=float(td.get("timestamp", 0.0)),
                ))
            except Exception:
                continue
        if perf.peak_pnl <= 0 and perf.total_pnl > 0:
            perf.peak_pnl = perf.total_pnl
        return perf


class AdaptiveLearner:
    """Learns from trade outcomes and adjusts parameters on the fly.

    Adjustment philosophy:
      - Start from research recommendation (prior)
      - After each trade, nudge parameters toward what's working
      - Use exponential decay weighting (recent trades matter more)
      - Apply Bayesian shrinkage toward priors (don't overfit)
      - Cap max deviation from priors to prevent runaway drift
    """

    MIN_TRADES_FOR_ADJUSTMENT = 8
    ADJUSTMENT_INTERVAL_SEC = 60.0
    MAX_DEVIATION_MULT = 1.5       # max 50% deviation from prior
    LEARNING_RATE = 0.08           # how fast to adjust per cycle
    RECENT_WEIGHT = 0.7            # weight of recent trades vs all trades
    PERSIST_INTERVAL_SEC = 10.0  # persist frequently so dashboard stays current

    def __init__(self, persist_dir: str = "adaptive_state"):
        self._perf: Dict[str, SymbolPerformance] = {}
        self._priors: Dict[str, Dict[str, Any]] = {}  # original recommendation patches
        self._current_patches: Dict[str, Dict[str, Any]] = {}
        self._persist_dir = persist_dir
        self._last_persist_ts: float = 0.0
        os.makedirs(persist_dir, exist_ok=True)
        self._load_state()

    def set_prior(self, symbol: str, patch: Dict[str, Any]) -> None:
        """Set the baseline (research recommendation) for a symbol."""
        self._priors[symbol] = dict(patch)
        if symbol not in self._current_patches:
            self._current_patches[symbol] = dict(patch)
        # Persist immediately so dashboard sees new symbols
        self.persist(force=True)

    def record_trade(self, record: TradeRecord) -> Optional[Dict[str, Any]]:
        """Record a trade outcome and potentially return updated parameters.

        Returns None if no adjustment needed, or a dict of parameter updates.
        """
        sym = record.symbol
        if sym not in self._perf:
            self._perf[sym] = SymbolPerformance(symbol=sym)
        perf = self._perf[sym]

        # Update stats
        perf.trades.append(record)
        perf.total_pnl += record.pnl
        perf.peak_pnl = max(perf.peak_pnl, perf.total_pnl)
        perf.max_drawdown = max(perf.max_drawdown, perf.peak_pnl - perf.total_pnl)

        if record.pnl > 0:
            perf.current_streak = max(1, perf.current_streak + 1)
        else:
            perf.current_streak = min(-1, perf.current_streak - 1)

        # Persist after every trade so dashboard picks it up
        self.persist(force=True)

        # Check if adjustment is warranted
        now = time.time()
        if (len(perf.trades) >= self.MIN_TRADES_FOR_ADJUSTMENT and
                now - perf.last_adjustment_ts >= self.ADJUSTMENT_INTERVAL_SEC):
            return self._compute_adjustment(sym, perf)

        return None

    def get_current_patch(self, symbol: str) -> Dict[str, Any]:
        """Get the current (possibly adjusted) parameters for a symbol."""
        return dict(self._current_patches.get(symbol, self._priors.get(symbol, {})))

    def get_performance(self, symbol: str) -> Optional[SymbolPerformance]:
        return self._perf.get(symbol)

    def get_all_performance(self) -> Dict[str, SymbolPerformance]:
        return dict(self._perf)

    def should_pause_symbol(self, symbol: str) -> bool:
        """Check if a symbol should be paused due to poor performance."""
        perf = self._perf.get(symbol)
        if not perf or len(perf.trades) < 10:
            return False
        # Pause if: recent win rate < 30%, or 5+ consecutive losses, or drawdown > 40% of peak
        if perf.recent_win_rate < 0.30:
            return True
        if perf.current_streak <= -5:
            return True
        if perf.peak_pnl > 0 and perf.max_drawdown / perf.peak_pnl > 0.40:
            return True
        return False

    def persist(self, force: bool = False) -> None:
        now = time.time()
        if not force and now - self._last_persist_ts < self.PERSIST_INTERVAL_SEC:
            return
        self._last_persist_ts = now
        state = {
            "ts": time.time(),
            "priors": self._priors,
            "current_patches": self._current_patches,
            "performance": {sym: p.to_dict() for sym, p in self._perf.items()},
        }
        try:
            atomic_write_json(os.path.join(self._persist_dir, "adaptive_state.json"), state)
        except Exception as e:
            LOG.warning("Failed to persist adaptive state: %s", e)

    # ── Internal ─────────────────────────────────────────────────────────

    def _compute_adjustment(self, symbol: str, perf: SymbolPerformance) -> Optional[Dict[str, Any]]:
        """Compute parameter adjustments based on performance."""
        prior = self._priors.get(symbol, {})
        current = self._current_patches.get(symbol, dict(prior))
        if not prior:
            return None

        perf.last_adjustment_ts = time.time()
        perf.adjustment_count += 1

        adjustments: Dict[str, Any] = {}

        # ── TP/SL tuning ─────────────────────────────────────────────
        wr = perf.recent_win_rate
        sl_rate = perf.sl_exit_rate()
        pf = perf.profit_factor

        tp_mult = prior.get("TP_ATR_MULT", 2.0)
        sl_mult = prior.get("SL_ATR_MULT", 1.2)

        # If win rate is high but avg win is small -> widen TP
        if wr > 0.60 and perf.avg_win < abs(perf.avg_loss) * 0.8:
            tp_mult *= (1.0 + self.LEARNING_RATE)
        # If win rate is low -> tighten TP to capture more wins
        elif wr < 0.42:
            tp_mult *= (1.0 - self.LEARNING_RATE * 0.5)

        # If SL hit rate is very high -> widen SL
        if sl_rate > 0.5:
            sl_mult *= (1.0 + self.LEARNING_RATE * 0.7)
        # If barely hitting SL and PF is good -> tighten for risk
        elif sl_rate < 0.15 and pf > 1.5:
            sl_mult *= (1.0 - self.LEARNING_RATE * 0.3)

        adjustments["TP_ATR_MULT"] = self._clamp_to_prior(tp_mult, prior.get("TP_ATR_MULT", 2.0))
        adjustments["SL_ATR_MULT"] = self._clamp_to_prior(sl_mult, prior.get("SL_ATR_MULT", 1.2))

        # ── Trailing tuning ──────────────────────────────────────────
        trail_frac = prior.get("TRAIL_START_FRAC_TP", 0.45)
        # If TP hits are common but we're leaving profit on table
        tp_exits = sum(1 for t in perf.trades if t.exit_reason == "TP")
        trail_exits = sum(1 for t in perf.trades if t.exit_reason == "TRAIL")
        if tp_exits > trail_exits * 2 and wr > 0.55:
            trail_frac *= (1.0 - self.LEARNING_RATE * 0.5)  # start trailing earlier
        elif trail_exits > tp_exits and perf.avg_win > 0:
            trail_frac *= (1.0 + self.LEARNING_RATE * 0.3)  # let profits run more

        adjustments["TRAIL_START_FRAC_TP"] = max(0.20, min(0.85,
            self._clamp_to_prior(trail_frac, prior.get("TRAIL_START_FRAC_TP", 0.45))))

        # ── Confirmation ticks ───────────────────────────────────────
        confirm = prior.get("ENTRY_CONFIRM_TICKS", 4)
        # Too many false entries (low WR) -> increase confirmation
        if wr < 0.40 and len(perf.trades) >= 15:
            confirm = min(8, confirm + 1)
        # Very high WR but might be missing opportunities -> reduce
        elif wr > 0.65 and len(perf.trades) >= 20:
            confirm = max(2, confirm - 1)
        adjustments["ENTRY_CONFIRM_TICKS"] = int(confirm)

        # ── OFI threshold ────────────────────────────────────────────
        ofi_min = prior.get("HEUR_OFI_MIN", 0.05)
        if wr < 0.40:
            ofi_min *= (1.0 + self.LEARNING_RATE)  # stricter
        elif wr > 0.60:
            ofi_min *= (1.0 - self.LEARNING_RATE * 0.5)  # looser
        adjustments["HEUR_OFI_MIN"] = round(max(0.02, min(0.15, ofi_min)), 6)

        # Apply adjustments
        current.update(adjustments)
        self._current_patches[symbol] = current

        LOG.info("ADAPTIVE %s [%d trades, WR=%.1f%%, PF=%.2f, streak=%d]: %s",
                 symbol, len(perf.trades), wr * 100, pf, perf.current_streak,
                 {k: f"{v:.4f}" if isinstance(v, float) else v for k, v in adjustments.items()})

        self.persist()
        return adjustments

    def _clamp_to_prior(self, value: float, prior: float) -> float:
        """Clamp value to within MAX_DEVIATION_MULT of the prior."""
        if prior <= 0:
            return value
        lo = prior / self.MAX_DEVIATION_MULT
        hi = prior * self.MAX_DEVIATION_MULT
        return max(lo, min(hi, value))

    def _load_state(self) -> None:
        path = os.path.join(self._persist_dir, "adaptive_state.json")
        if not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self._priors = state.get("priors", {})
            self._current_patches = state.get("current_patches", {})
            raw_perf = state.get("performance", {})
            for sym, pd in raw_perf.items():
                if isinstance(pd, dict) and "trades" in pd:
                    perf = SymbolPerformance.from_dict({**pd, "symbol": sym})
                else:
                    perf = SymbolPerformance(symbol=sym)
                    perf.total_pnl = float(pd.get("total_pnl", 0.0)) if isinstance(pd, dict) else 0.0
                    perf.peak_pnl = float(pd.get("peak_pnl", 0.0)) if isinstance(pd, dict) else 0.0
                    perf.max_drawdown = float(pd.get("max_drawdown", 0.0)) if isinstance(pd, dict) else 0.0
                    perf.current_streak = int(pd.get("current_streak", 0)) if isinstance(pd, dict) else 0
                self._perf[sym] = perf
            LOG.info("Loaded adaptive state: %d priors, %d patches, %d perf records",
                     len(self._priors), len(self._current_patches), len(self._perf))
        except Exception as e:
            LOG.warning("Failed to load adaptive state: %s", e)
