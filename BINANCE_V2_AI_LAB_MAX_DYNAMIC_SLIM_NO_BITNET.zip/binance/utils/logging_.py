"""Logging utilities: trade CSV, central JSONL."""

from __future__ import annotations

import csv
import os
from core.config import Config

TRADE_FIELDS = [
    "ts", "symbol", "side", "reason", "qty", "entry", "exit", "pnl",
    "mid", "ofi", "slope", "vol_bps", "vol_med", "spread_bps", "wall_total",
    "p_up", "src", "tp_usd", "sl_usd", "trail_usd", "est_cost",
    "maker_entry", "maker_exit", "wr", "loss_streak"
]


def append_trade_csv(cfg: Config, row: dict) -> None:
    need_header = not os.path.exists(cfg.TRADE_LOG)
    try:
        with open(cfg.TRADE_LOG, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=TRADE_FIELDS, extrasaction="ignore")
            if need_header:
                w.writeheader()
            out = {k: "" for k in TRADE_FIELDS}
            out.update({k: row.get(k, "") for k in TRADE_FIELDS})
            w.writerow(out)
    except Exception:
        pass
