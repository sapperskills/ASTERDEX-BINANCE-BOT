"""Reconcile exchange position with local state."""

from __future__ import annotations

import logging
import time
from collections import deque
from decimal import Decimal
from typing import Deque, Optional

from core.helpers import D0, d, clamp, round_step, utc_ts, append_jsonl
from core.config import Config
from core.state import BotState
from core.types import Snapshot, SymbolFilters
from exchange.client import ExchangeClient
from exchange.market import (
    get_price, get_walls, spread_bps, order_flow_imbalance, RollingMinMax,
)
from strategy.signals import compute_ma, ma_slope_dir, atr_update, atr_value, micro_vol_bps
from strategy.risk import decide_tp_sl
from exchange.market import estimate_costs

LOG = logging.getLogger("aster")


def _norm_pos(side: Optional[str]) -> Optional[str]:
    if side is None:
        return None
    s = str(side).upper()
    if s in ("LONG", "BUY"):
        return "LONG"
    if s in ("SHORT", "SELL"):
        return "SHORT"
    return None


def seed_tpsl_for_state(cfg: Config, st: BotState, snap: Snapshot) -> None:
    if st.is_flat() or st.qty <= 0 or st.entry_price <= 0:
        return
    notional = st.qty * st.entry_price
    est_cost = estimate_costs(cfg, notional, snap.spread, st.qty)
    st.entry_est_cost = max(st.entry_est_cost, est_cost)

    tp, sl = decide_tp_sl(cfg, snap.atr_price, st.qty, st.entry_est_cost)
    st.tp_usd = tp
    st.sl_usd = sl
    st.tp_init = tp
    st.sl_init = sl
    st.trail_usd = D0
    st.peak_unreal = D0
    st.last_tpsl_refresh = time.time()
    st.tp_touched = False
    st.tp_touch_ts = 0.0

    append_jsonl(cfg.CENTRAL_LOG_JSONL, {
        "ts": utc_ts(), "event": "TPSL_SEED_ON_ADOPT",
        "qty": str(st.qty), "entry": str(st.entry_price),
        "tp": str(st.tp_usd), "sl": str(st.sl_usd),
    })
    LOG.info("TPSL SEEDED: qty=%s entry=%s TP=%s SL=%s", st.qty, st.entry_price, st.tp_usd, st.sl_usd)


def reconcile_with_exchange(
    cfg: Config, client: ExchangeClient, filt: SymbolFilters,
    st: BotState, snap: Snapshot, auth_ok: bool, force: bool = False,
) -> None:
    if cfg.SIMULATION_MODE or (not cfg.RECONCILE_ENABLE) or (not auth_ok):
        return
    now = time.time()
    if (not force) and st.last_reconcile_ts and (now - st.last_reconcile_ts) < float(cfg.RECONCILE_EVERY_SEC):
        return
    st.last_reconcile_ts = now
    ex = client.get_position(auth_ok)
    if not ex:
        return
    ex_side = _norm_pos(ex.get("side"))
    ex_qty = d(ex.get("amt", "0"))
    ex_entry = d(ex.get("entry", "0"))

    if ex_side is None or ex_qty <= cfg.RECONCILE_MIN_QTY_EPS:
        if not st.is_flat():
            LOG.warning("RECONCILE: exchange FLAT but local had %s qty=%s -> clearing", st.position, st.qty)
            append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "RECONCILE_CLEAR_LOCAL"})
            if cfg.RECONCILE_CANCEL_OPEN_ORDERS_ON_MISMATCH:
                _ = client.cancel_all_open_orders(auth_ok)
            st.clear()
        return

    if st.is_flat():
        st.position = ex_side
        st.qty = round_step(ex_qty, filt.qty_step)
        st.entry_price = ex_entry if ex_entry > 0 else snap.mid
        st.entry_time = now
        st.adopted_from_exchange = True
        st.confirm_streak_long = 0
        st.confirm_streak_short = 0
        st.bad_order_attempts = 0
        if cfg.RECONCILE_CANCEL_OPEN_ORDERS_ON_ADOPT:
            _ = client.cancel_all_open_orders(auth_ok)
        seed_tpsl_for_state(cfg, st, snap)
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "RECONCILE_ADOPT",
                                            "side": st.position, "qty": str(st.qty), "entry": str(st.entry_price)})
        LOG.warning("RECONCILE: adopted %s qty=%s entry=%s", st.position, st.qty, st.entry_price)
        return

    mismatch = False
    if _norm_pos(st.position) != ex_side:
        mismatch = True
    if abs(st.qty - ex_qty) > max(filt.min_qty, cfg.RECONCILE_MIN_QTY_EPS):
        mismatch = True
    if st.entry_price > 0 and ex_entry > 0:
        if abs(st.entry_price - ex_entry) / max(ex_entry, Decimal("0.00000001")) > Decimal("0.0035"):
            mismatch = True

    if mismatch:
        LOG.warning("RECONCILE: mismatch -> repairing")
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "RECONCILE_REPAIR"})
        if cfg.RECONCILE_CANCEL_OPEN_ORDERS_ON_MISMATCH:
            _ = client.cancel_all_open_orders(auth_ok)
        st.position = ex_side
        st.qty = round_step(ex_qty, filt.qty_step)
        st.entry_price = ex_entry if ex_entry > 0 else st.entry_price
        seed_tpsl_for_state(cfg, st, snap)
        st.bad_order_attempts = 0


def boot_adopt_exchange_position(
    cfg: Config, client: ExchangeClient, filt: SymbolFilters,
    st: BotState, auth_ok: bool,
    price_mm: RollingMinMax, price_buf: Deque[Decimal],
    ma_hist: Deque[Decimal], tr_buf: Deque[Decimal],
    vol_hist: Deque[Decimal],
) -> None:
    if cfg.SIMULATION_MODE or (not auth_ok) or (not cfg.RECONCILE_ENABLE):
        return

    for _ in range(10):
        mid = get_price(cfg, client)
        depth = client.get_depth_cached()
        if mid > 0 and depth and depth.get("bids") and depth.get("asks"):
            price_mm.push(mid)
            price_buf.append(mid)
            atr_update(tr_buf, st.prev_mid, mid)
            st.prev_mid = mid

            ma = compute_ma(price_buf, cfg.MA_LENGTH)
            if ma is not None:
                ma_hist.append(ma)
            slope = ma_slope_dir(ma_hist, cfg.MA_SLOPE_LEN)
            vol_bps_ = micro_vol_bps(price_mm, mid, cfg.MA_LENGTH)
            if vol_bps_ > 0:
                vol_hist.append(vol_bps_)

            atr_p = atr_value(cfg, tr_buf, price_mm)

            wall_band = cfg.WALL_BAND_BPS_DEFAULT
            if vol_bps_ > 0:
                wall_band = clamp(
                    (wall_band * Decimal("0.90")) + (vol_bps_ * Decimal("1.1") * Decimal("0.10")),
                    cfg.WALL_BAND_BPS_MIN, cfg.WALL_BAND_BPS_MAX,
                )

            best_bid, best_ask, spread, wall_total = get_walls(cfg, depth, mid, wall_band)
            sbps = spread_bps(mid, best_bid, best_ask)
            st.ofi_ema = order_flow_imbalance(depth, mid, st.ofi_ema, wall_band)

            snap = Snapshot(
                mid=mid, best_bid=best_bid, best_ask=best_ask,
                spread=spread, spread_bps=sbps, wall_total=wall_total,
                ofi=st.ofi_ema, ma=ma, slope=slope,
                vol_bps=vol_bps_, atr_price=atr_p, wall_band_bps=wall_band
            )

            reconcile_with_exchange(cfg, client, filt, st, snap, auth_ok, force=True)
            append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "BOOT_ADOPT_DONE",
                                                "pos": st.position or "FLAT", "qty": str(st.qty)})
            return

        time.sleep(0.20)

    append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "BOOT_ADOPT_SKIPPED"})
