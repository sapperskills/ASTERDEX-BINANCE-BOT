"""Warmup calibration: build a symbol profile from live data."""

from __future__ import annotations

import logging
import time
from collections import deque
from decimal import Decimal
from typing import Deque, List, Optional

from core.helpers import D0, d, clamp, percentile_dec, utc_ts, append_jsonl
from core.config import Config
from core.types import SymbolFilters, SymbolProfile, apply_profile_to_cfg, save_symbol_profile
from exchange.client import ExchangeClient
from exchange.market import get_price, get_walls, spread_bps, RollingMinMax
from strategy.signals import atr_update, micro_vol_bps

LOG = logging.getLogger("aster")


def _calibration_sample_target(cfg: Config, profile_exists: bool = False) -> int:
    base = int(cfg.CALIB_WARMUP_SAMPLES)
    if profile_exists:
        return max(40, min(base, int(cfg.CALIB_WARMUP_SAMPLES_PROFILE_REFRESH)))
    if int(getattr(cfg, "PRETRAINED_MODEL_EXAMPLES", 0)) > 0:
        model_file = getattr(cfg, "MODEL_FILE", "") or ""
        if str(model_file).startswith("SIM_") or "pretrain" in str(model_file).lower():
            return max(60, min(base, int(cfg.CALIB_WARMUP_SAMPLES_PRETRAINED)))
    return base


def calibrate_symbol_profile(cfg: Config, client: ExchangeClient, filt: SymbolFilters, profile_exists: bool = False) -> Optional[SymbolProfile]:
    if not cfg.CALIB_ENABLE:
        return None

    sample_target = _calibration_sample_target(cfg, profile_exists=profile_exists)
    LOG.info("CALIB: collecting %s samples for %s", sample_target, cfg.SYMBOL)

    wall_band = cfg.WALL_BAND_BPS_DEFAULT
    spreads: List[Decimal] = []
    walls: List[Decimal] = []
    vols: List[Decimal] = []

    price_mm = RollingMinMax(maxlen=cfg.MA_LENGTH)
    tr_buf: Deque[Decimal] = deque(maxlen=cfg.ATR_LEN)
    prev_mid: Optional[Decimal] = None

    for i in range(sample_target):
        mid = get_price(cfg, client)
        if mid <= 0:
            time.sleep(0.15)
            continue

        depth = client.get_depth_cached()
        if not depth or not depth.get("bids") or not depth.get("asks"):
            time.sleep(0.15)
            continue

        price_mm.push(mid)
        atr_update(tr_buf, prev_mid, mid)
        prev_mid = mid

        vol_b = micro_vol_bps(price_mm, mid, cfg.MA_LENGTH)
        vols.append(vol_b)

        if cfg.CALIB_WALL_BAND_FROM_VOL and vol_b > 0:
            scaled = clamp(vol_b * Decimal("2.0"), cfg.WALL_BAND_BPS_MIN, cfg.WALL_BAND_BPS_MAX)
            wall_band = (wall_band * Decimal("0.85")) + (scaled * Decimal("0.15"))

        best_bid, best_ask, spread, wall_total = get_walls(cfg, depth, mid, wall_band)
        sbps = spread_bps(mid, best_bid, best_ask)

        spreads.append(sbps)
        walls.append(wall_total)

        if (i + 1) % 50 == 0:
            LOG.info("CALIB: %s/%s band=%s sbps=%s wall=%s vol=%s",
                     i + 1, sample_target, wall_band, sbps, wall_total, vol_b)

        time.sleep(0.12 if cfg.LIVE_PROFILE else 0.18)

    if not spreads or not walls or not vols:
        LOG.warning("CALIB: insufficient samples")
        return None

    sbps_cap = max(Decimal("2.0"), percentile_dec(spreads, cfg.CALIB_SPREAD_PCT))
    wall_floor = max(Decimal("1.0"), percentile_dec(walls, cfg.CALIB_WALL_PCT))
    vmin = max(Decimal("0.1"), percentile_dec(vols, cfg.CALIB_VOL_MIN_PCT))
    vmed = max(Decimal("0.1"), percentile_dec(vols, cfg.CALIB_VOL_MED_PCT))

    prof = SymbolProfile(
        symbol=cfg.SYMBOL.upper(), ts=utc_ts(),
        wall_band_bps=clamp(wall_band, cfg.WALL_BAND_BPS_MIN, cfg.WALL_BAND_BPS_MAX),
        min_wall_total=wall_floor, max_spread_bps=sbps_cap,
        min_vol_bps=vmin, vol_med_bps=vmed,
        vol_expand_mult=cfg.CALIB_VOL_EXPAND_MULT,
    )

    save_symbol_profile(cfg, prof)
    apply_profile_to_cfg(cfg, prof)

    append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "CALIB_PROFILE", **prof.to_payload()})
    LOG.info("CALIB DONE: band=%s wall=%s spread=%s vol_min=%s vol_med=%s",
             prof.wall_band_bps, prof.min_wall_total, prof.max_spread_bps, prof.min_vol_bps, prof.vol_med_bps)

    return prof
