#!/usr/bin/env python3
"""Unified Trading Engine — Real-time monitoring dashboard (Aster / Binance)."""

from __future__ import annotations

import json
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

BASE_DIR = Path(__file__).resolve().parent
DASHBOARD_VERSION = "v4.6"


def _abs_path(*parts: str) -> Path:
    return BASE_DIR.joinpath(*parts)


def load_json_safe(path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def load_jsonl_tail(path: Path, max_lines: int = 500) -> List[dict]:
    """Read the last N lines of a JSONL file without reading the whole file."""
    if not path.exists():
        return []
    out: List[dict] = []
    try:
        with path.open("rb") as f:
            f.seek(0, os.SEEK_END)
            pos = f.tell()
            blocks: List[bytes] = []
            newline_count = 0
            block_size = 4096
            while pos > 0 and newline_count <= max_lines + 1:
                read_size = min(block_size, pos)
                pos -= read_size
                f.seek(pos)
                chunk = f.read(read_size)
                blocks.append(chunk)
                newline_count += chunk.count(b"\n")
            data = b"".join(reversed(blocks)).decode("utf-8", errors="ignore")
        for line in data.splitlines()[-max_lines:]:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    except Exception:
        return []
    return out


def extract_trades_from_jsonl(path: Path) -> List[dict]:
    entries = load_jsonl_tail(path, max_lines=2000)
    trades = []
    last_entry = None
    for e in entries:
        event = e.get("event", "")
        if event == "ENTRY_FILLED":
            last_entry = e
        elif event == "EXIT_FILLED" and last_entry:
            trades.append(
                {
                    "entry_ts": last_entry.get("ts", ""),
                    "exit_ts": e.get("ts", ""),
                    "side": last_entry.get("side", "?"),
                    "entry_px": last_entry.get("fill", "?"),
                    "exit_px": e.get("fill", "?"),
                    "qty": e.get("qty", "?"),
                    "pnl": float(e.get("pnl", 0)),
                    "reason": e.get("reason", "?"),
                    "tp_touched": e.get("tp_touched", False),
                }
            )
            last_entry = None
    return trades


def extract_last_snap(path: Path) -> Optional[dict]:
    entries = load_jsonl_tail(path, max_lines=50)
    for e in reversed(entries):
        if e.get("event") == "SNAP":
            return e
    return None


def clear_screen() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def main() -> None:
    while True:
        clear_screen()
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        print(f"{'=' * 78}")
        print(f"  Unified Engine {DASHBOARD_VERSION} — Live Dashboard           {now}")
        print(f"{'=' * 78}")

        adaptive = load_json_safe(_abs_path("adaptive_state", "adaptive_state.json"))
        perf = adaptive.get("performance", {})
        patches = adaptive.get("current_patches", {})
        priors = adaptive.get("priors", {})

        promo = load_json_safe(_abs_path("promotion_state.json"))
        trackers = promo.get("trackers", {})

        sim_state_files = sorted(BASE_DIR.glob("SIM_*_state.json"))
        sim_log_files = sorted(BASE_DIR.glob("SIM_*_central_log.jsonl"))
        live_state_files = [
            p
            for p in sorted(BASE_DIR.glob("*_state.json"))
            if not p.name.startswith("SIM_")
            and not p.name.startswith("adaptive")
            and not p.name.startswith("promotion")
            and not p.name.startswith("population")
        ]
        live_log_files = [
            p
            for p in sorted(BASE_DIR.glob("*_central_log.jsonl"))
            if not p.name.startswith("SIM_")
        ]

        sim_symbols = [p.name.replace("SIM_", "").replace("_state.json", "") for p in sim_state_files]
        live_symbols = [p.name.replace("_state.json", "") for p in live_state_files]

        symbol_stats: Dict[str, Dict[str, Any]] = {}

        # Process both SIM and LIVE log files
        all_log_files = []
        for log_file in sim_log_files:
            sym = log_file.name.replace("SIM_", "").replace("_central_log.jsonl", "")
            all_log_files.append((sym, log_file, "SIM"))
        for log_file in live_log_files:
            sym = log_file.name.replace("_central_log.jsonl", "")
            all_log_files.append((sym, log_file, "LIVE"))

        for sym, log_file, mode in all_log_files:
            trades = extract_trades_from_jsonl(log_file)
            snap = extract_last_snap(log_file)

            wins = sum(1 for t in trades if t["pnl"] > 0)
            losses = sum(1 for t in trades if t["pnl"] <= 0)
            total_pnl = sum(t["pnl"] for t in trades)
            gross_win = sum(t["pnl"] for t in trades if t["pnl"] > 0)
            gross_loss = abs(sum(t["pnl"] for t in trades if t["pnl"] < 0))
            pf = (gross_win / gross_loss) if gross_loss > 0 else (10.0 if gross_win > 0 else 0.0)
            wr = (wins / len(trades)) if trades else 0.0

            equity = 0.0
            peak = 0.0
            max_dd = 0.0
            for t in trades:
                equity += t["pnl"]
                peak = max(peak, equity)
                max_dd = max(max_dd, peak - equity)

            # If we already have a SIM entry for this symbol but now found a LIVE log,
            # prefer LIVE data if it has trades, or merge snap data
            existing = symbol_stats.get(sym)
            if existing and existing.get("source_mode") == "SIM" and mode == "LIVE":
                # LIVE data takes priority: overlay live stats
                if trades:
                    symbol_stats[sym] = {
                        "trades": len(trades),
                        "wins": wins,
                        "losses": losses,
                        "wr": wr,
                        "pf": pf,
                        "total_pnl": total_pnl,
                        "max_dd": max_dd,
                        "last_trade": trades[-1] if trades else None,
                        "snap": snap or existing.get("snap"),
                        "source": "jsonl",
                        "source_mode": mode,
                    }
                elif snap:
                    existing["snap"] = snap  # update snap from live log
            else:
                symbol_stats[sym] = {
                    "trades": len(trades),
                    "wins": wins,
                    "losses": losses,
                    "wr": wr,
                    "pf": pf,
                    "total_pnl": total_pnl,
                    "max_dd": max_dd,
                    "last_trade": trades[-1] if trades else None,
                    "snap": snap,
                    "source": "jsonl",
                    "source_mode": mode,
                }

        for sym, p in perf.items():
            if sym in symbol_stats and symbol_stats[sym]["trades"] > 0:
                continue

            if isinstance(p, dict) and "trades" in p:
                trade_list = p.get("trades", [])
                wins = sum(1 for t in trade_list if float(t.get("pnl", 0.0)) > 0)
                losses = len(trade_list) - wins
                trade_count = len(trade_list)
                win_rate = (wins / trade_count) if trade_count else 0.0
                gross_win = sum(float(t.get("pnl", 0.0)) for t in trade_list if float(t.get("pnl", 0.0)) > 0)
                gross_loss = abs(sum(float(t.get("pnl", 0.0)) for t in trade_list if float(t.get("pnl", 0.0)) < 0))
                profit_factor = (gross_win / gross_loss) if gross_loss > 0 else (10.0 if gross_win > 0 else 0.0)
                total_pnl = float(p.get("total_pnl", 0.0))
                max_dd = float(p.get("max_drawdown", 0.0))
            else:
                trade_count = int(p.get("trade_count", 0)) if isinstance(p, dict) else 0
                win_rate = float(p.get("win_rate", 0.0)) if isinstance(p, dict) else 0.0
                wins = int(round(trade_count * win_rate))
                losses = max(0, trade_count - wins)
                profit_factor = float(p.get("profit_factor", 0.0)) if isinstance(p, dict) else 0.0
                total_pnl = float(p.get("total_pnl", 0.0)) if isinstance(p, dict) else 0.0
                max_dd = float(p.get("max_drawdown", 0.0)) if isinstance(p, dict) else 0.0

            symbol_stats[sym] = {
                "trades": trade_count,
                "wins": wins,
                "losses": losses,
                "wr": win_rate,
                "pf": profit_factor,
                "total_pnl": total_pnl,
                "max_dd": max_dd,
                "last_trade": None,
                "snap": None,
                "source": "adaptive",
                "source_mode": "SIM",
            }

        active_positions = []
        # Include SIM positions
        for sf in sim_state_files:
            st = load_json_safe(sf)
            sym = sf.name.replace("SIM_", "").replace("_state.json", "")
            pos = st.get("position")
            status = pos if pos else "FLAT"
            detail = ""
            if pos:
                detail = f"qty={st.get('qty', '0')} entry={st.get('entry_price', '0')}"
            active_positions.append(
                {
                    "sym": sym,
                    "status": status,
                    "detail": detail,
                    "mid": st.get("prev_mid", "0"),
                    "ofi": st.get("ofi_ema", "0"),
                    "day_pnl": st.get("realized_day_pnl", "0"),
                    "mode": "SIM",
                }
            )
        # Include LIVE positions
        for sf in live_state_files:
            st = load_json_safe(sf)
            sym = sf.name.replace("_state.json", "")
            pos = st.get("position")
            status = pos if pos else "FLAT"
            detail = ""
            if pos:
                detail = f"qty={st.get('qty', '0')} entry={st.get('entry_price', '0')}"
            active_positions.append(
                {
                    "sym": sym,
                    "status": status,
                    "detail": detail,
                    "mid": st.get("prev_mid", "0"),
                    "ofi": st.get("ofi_ema", "0"),
                    "day_pnl": st.get("realized_day_pnl", "0"),
                    "mode": "LIVE",
                }
            )

        total_tracked = len(sim_symbols) + len(live_symbols)
        total_with_trades = sum(1 for s in symbol_stats.values() if s["trades"] > 0)
        promoted = [s for s, t in trackers.items() if t.get("promoted")]

        print(
            f"\n  Scanner: {total_tracked} symbols tracked | "
            f"{total_with_trades} with trades | {len(promoted)} promoted to LIVE"
            f" | {len(live_symbols)} live runners active"
        )

        if symbol_stats and any(s["trades"] > 0 for s in symbol_stats.values()):
            print(
                f"\n  {'Symbol':<12} {'Mode':<5} {'Trades':>6} {'Win':>5} {'Loss':>5} "
                f"{'WR':>6} {'PF':>6} {'PnL':>10} {'DD':>8} {'Last':>8}"
            )
            print(
                f"  {'-'*12} {'-'*5} {'-'*6} {'-'*5} {'-'*5} "
                f"{'-'*6} {'-'*6} {'-'*10} {'-'*8} {'-'*8}"
            )
            promoted_set = {x for x, t in trackers.items() if t.get("promoted")}
            live_sym_set = set(live_symbols)
            for sym, s in sorted(symbol_stats.items(), key=lambda x: x[1]["total_pnl"], reverse=True):
                if s["trades"] == 0:
                    continue
                if s.get("source_mode") == "LIVE" or sym in promoted_set or sym in live_sym_set:
                    mode = "LIVE"
                else:
                    mode = "SIM"
                wr_str = f"{s['wr']*100:.0f}%"
                pf_str = f"{s['pf']:.2f}"
                last_str = s.get("last_trade", {}).get("reason", "") if s.get("last_trade") else ""
                print(
                    f"  {sym:<12} {mode:<5} {s['trades']:>6} {s['wins']:>5} {s['losses']:>5} "
                    f"{wr_str:>6} {pf_str:>6} {s['total_pnl']:>+10.4f} {s['max_dd']:>8.4f} {last_str:>8}"
                )

            total_trades = sum(s["trades"] for s in symbol_stats.values())
            total_pnl = sum(s["total_pnl"] for s in symbol_stats.values())
            total_wins = sum(s["wins"] for s in symbol_stats.values())
            total_losses = sum(s["losses"] for s in symbol_stats.values())
            total_wr = total_wins / total_trades if total_trades > 0 else 0.0
            print(
                f"\n  {'TOTAL':<12} {'':5} {total_trades:>6} {total_wins:>5} {total_losses:>5} "
                f"{total_wr*100:>5.0f}% {'':>6} {total_pnl:>+10.4f}"
            )
        else:
            print("\n  No completed trades yet. Symbols are warming up and learning...")
            if active_positions:
                print(f"  {len(active_positions)} symbol runners active — waiting for entry signals.")

        if any(p["status"] != "FLAT" for p in active_positions):
            print("\n  Open positions:")
            for p in active_positions:
                if p["status"] != "FLAT":
                    mode_tag = p.get("mode", "SIM")
                    print(
                        f"    [{mode_tag}] {p['sym']}: {p['status']} {p['detail']} | "
                        f"mid={p['mid']} ofi={float(p['ofi']):+.4f}"
                    )

        if active_positions:
            print("\n  Live market data:")
            for p in active_positions:
                status_icon = "●" if p["status"] != "FLAT" else "○"
                mode_tag = p.get("mode", "SIM")
                mode_marker = f"[{mode_tag}]"
                print(
                    f"    {status_icon} {mode_marker} {p['sym']:<12} mid={p['mid']:<14} "
                    f"ofi={float(p.get('ofi', 0)):>+.4f}  "
                    f"dayPnL={float(p.get('day_pnl', 0)):>+.4f}  [{p['status']}]"
                )

        sim_trackers = {
            s: t for s, t in trackers.items() if not t.get("promoted") and t.get("sim_trades", 0) > 0
        }
        promoted_trackers = {s: t for s, t in trackers.items() if t.get("promoted")}

        if promoted_trackers:
            print("\n  LIVE (promoted):")
            for sym, t in promoted_trackers.items():
                print(
                    f"    {sym}: live={t.get('live_trades', 0)} trades "
                    f"WR={t.get('sim_win_rate', 0) * 100:.0f}% sim "
                    f"PnL={t.get('live_pnl', 0):+.4f} live "
                    f"(promotion #{t.get('promotion_count', 0)})"
                )

        if sim_trackers:
            promo_cfg = promo.get("config", {})
            min_trades = promo_cfg.get("min_sim_trades", 5)
            min_wr = promo_cfg.get("min_sim_win_rate", 0.55)
            min_pf = promo_cfg.get("min_sim_profit_factor", 1.2)
            print(
                f"\n  Promotion pipeline (gates: {min_trades} trades, "
                f"{min_wr*100:.0f}% WR, {min_pf:.1f}x PF):"
            )
            for sym, t in sorted(sim_trackers.items(), key=lambda x: x[1].get("sim_pnl", 0), reverse=True):
                trades = t.get("sim_trades", 0)
                wr = t.get("sim_win_rate", 0)
                pf = t.get("sim_pf", 0)
                pnl = t.get("sim_pnl", 0)
                progress = [
                    f"trades={trades}/{min_trades}" + (" ✓" if trades >= min_trades else ""),
                    f"WR={wr*100:.0f}/{min_wr*100:.0f}%" + (" ✓" if wr >= min_wr else ""),
                    f"PF={pf:.1f}/{min_pf:.1f}" + (" ✓" if pf >= min_pf else ""),
                ]
                print(f"    {sym}: {' | '.join(progress)} | PnL={pnl:+.4f}")

        all_patched = set(patches.keys()) | set(priors.keys())
        if all_patched:
            print(f"\n  Adaptive config ({len(all_patched)} symbols):")
            for sym in sorted(all_patched)[:6]:
                p = patches.get(sym, priors.get(sym, {}))
                parts = []
                if "TP_ATR_MULT" in p:
                    parts.append(f"TP={float(p['TP_ATR_MULT']):.2f}")
                if "SL_ATR_MULT" in p:
                    parts.append(f"SL={float(p['SL_ATR_MULT']):.2f}")
                if "ENTRY_CONFIRM_TICKS" in p:
                    parts.append(f"confirm={p['ENTRY_CONFIRM_TICKS']}")
                if "HEUR_OFI_MIN" in p:
                    parts.append(f"OFI={float(p['HEUR_OFI_MIN']):.3f}")
                if "MA_LENGTH" in p:
                    parts.append(f"MA={p['MA_LENGTH']}")
                print(f"    {sym}: {' | '.join(parts)}")

        print("\n  Refreshing in 5s... (Ctrl+C to exit)")
        time.sleep(5)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nDashboard stopped.")
