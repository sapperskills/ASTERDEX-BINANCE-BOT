#!/usr/bin/env python3
from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict

BASE_DIR = Path(__file__).resolve().parent
_server = None
_thread = None


def _load_json(path: Path) -> Dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}


def build_snapshot() -> Dict[str, Any]:
    agent = _load_json(BASE_DIR / 'agent_state_v2.json')
    promo = _load_json(BASE_DIR / 'promotion_state.json')
    adaptive = _load_json(BASE_DIR / 'adaptive_state' / 'adaptive_state.json')
    sim_states = []
    live_states = []
    for p in sorted(BASE_DIR.glob('*_state.json')):
        if p.name.startswith('population') or p.name.startswith('promotion') or p.name.startswith('adaptive'):
            continue
        row = _load_json(p)
        row['symbol'] = p.name.replace('SIM_', '').replace('_state.json', '')
        row['mode'] = 'SIM' if p.name.startswith('SIM_') else 'LIVE'
        daily_map = row.get('daily_pnl') or {}
        recent_days = sorted(daily_map.items(), key=lambda kv: kv[0], reverse=True)[:7]
        row['recent_daily_pnl'] = [{"day": k, "pnl": v} for k, v in recent_days]
        if row['mode'] == 'SIM':
            sim_states.append(row)
        else:
            live_states.append(row)
    return {'agent': agent, 'promotion': promo, 'adaptive': adaptive, 'sim_states': sim_states, 'live_states': live_states}


HTML = """<!doctype html>
<html><head><meta charset='utf-8'><title>AI Lab Dashboard</title>
<style>
body{margin:0;background:#08111b;color:#d7e7ff;font-family:Segoe UI,Arial,sans-serif}
.header{padding:18px 22px;background:linear-gradient(90deg,#0d2036,#0e3d63);border-bottom:1px solid #1d4d77}
.title{font-size:28px;font-weight:700;letter-spacing:1px}.sub{opacity:.8;margin-top:6px}
.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:14px;padding:14px}
.card{background:#0d1725;border:1px solid #163149;border-radius:14px;padding:14px;box-shadow:0 0 0 1px rgba(0,170,255,.04),0 10px 30px rgba(0,0,0,.22)}
.span4{grid-column:span 4}.span6{grid-column:span 6}.span8{grid-column:span 8}.span12{grid-column:span 12}
h3{margin:0 0 8px 0;color:#9ed2ff;font-size:16px} table{width:100%;border-collapse:collapse;font-size:13px}
th,td{padding:7px 8px;border-bottom:1px solid #17324a;text-align:left} .good{color:#6ee7a8}.bad{color:#ff8b8b}.mono{font-family:Consolas,monospace}
</style></head>
<body><div class='header'><div class='title'>ASTER / BINANCE AI LAB v2 MAX</div><div class='sub'>stream-friendly local dashboard · http://127.0.0.1:8765</div></div>
<div id='app' class='grid'></div>
<script>
function fmt(x){return (typeof x==='number')?x.toFixed(3):x}
function cls(x){return Number(x)>=0?'good':'bad'}
function buildDailyRows(states){
 const rows=[];
 for(const x of states||[]){
  for(const dp of (x.recent_daily_pnl||[])){
   rows.push(`<tr><td>${x.symbol}</td><td>${x.mode||''}</td><td>${dp.day}</td><td class='${cls(dp.pnl||0)}'>${dp.pnl}</td></tr>`)
  }
 }
 return rows.join('');
}
async function load(){
 const r=await fetch('/api/state'); const s=await r.json();
 const a=s.agent||{}; const port=(a.portfolio||{}); const syms=a.symbols||{};
 const ranked=Object.entries(syms).sort((a,b)=>(((b[1].best||{}).score||-99))-(((a[1].best||{}).score||-99)));
 const topRows=ranked.slice(0,12).map(([sym,v])=>{
   const best=v.best||{}; const m=(best.metrics||{}); return `<tr><td>${sym}</td><td>${v.promotion_ready?'YES':'NO'}</td><td>${(best.ALLOW_REGIMES||[]).join(', ')}</td><td>${fmt(best.MAX_SPREAD_BPS||0)}</td><td>${fmt(best.MIN_WALL_TOTAL||0)}</td><td>${fmt(best.TP_USD_FIXED||0)}</td><td>${fmt(best.SL_USD_FIXED||0)}</td><td>${fmt(m.win_rate||0)}</td><td>${fmt(m.profit_factor||0)}</td><td class='${cls(m.avg_pnl||0)}'>${fmt(m.avg_pnl||0)}</td></tr>`;
 }).join('');
 let simRows=(s.sim_states||[]).slice(0,20).map(x=>`<tr><td>${x.symbol}</td><td>${x.mode}</td><td>${x.position||'FLAT'}</td><td>${x.qty||0}</td><td>${x.entry_price||0}</td><td class='${cls(x.realized_day_pnl||0)}'>${x.realized_day_pnl||0}</td></tr>`).join('');
 let liveRows=(s.live_states||[]).slice(0,20).map(x=>`<tr><td>${x.symbol}</td><td>${x.position||'FLAT'}</td><td>${x.qty||0}</td><td>${x.entry_price||0}</td><td class='${cls(x.realized_day_pnl||0)}'>${x.realized_day_pnl||0}</td></tr>`).join('');
 let dailyRows=buildDailyRows([...(s.sim_states||[]), ...(s.live_states||[])]);
 document.getElementById('app').innerHTML=`
  <div class='card span4'><h3>Portfolio Lab</h3><div>Samples: <span class='mono'>${a.sample_count||0}</span></div><div>Trades: <span class='mono'>${port.trades||0}</span></div><div>Win rate: <span class='mono'>${fmt(port.win_rate||0)}</span></div><div>PF: <span class='mono'>${fmt(port.profit_factor||0)}</span></div><div>Avg PnL: <span class='mono ${cls(port.avg_pnl||0)}'>${fmt(port.avg_pnl||0)}</span></div><div>Avg Win: <span class='mono good'>${fmt(port.avg_win||0)}</span></div><div>Avg Loss: <span class='mono bad'>${fmt(port.avg_loss||0)}</span></div><div>Catastrophic rate: <span class='mono bad'>${fmt(port.catastrophic_rate||0)}</span></div><div>Updated: <span class='mono'>${a.updated_at||''}</span></div></div>
  <div class='card span8'><h3>Promoted Overrides</h3><table><tr><th>Symbol</th><th>Ready</th><th>Regimes</th><th>Max Spread</th><th>Min Wall</th><th>TP</th><th>SL</th><th>WR</th><th>PF</th><th>Avg PnL</th></tr>${topRows}</table></div>
  <div class='card span6'><h3>SIM Runners</h3><table><tr><th>Symbol</th><th>Mode</th><th>Pos</th><th>Qty</th><th>Entry</th><th>Day PnL</th></tr>${simRows}</table></div>
  <div class='card span6'><h3>LIVE Runners</h3><table><tr><th>Symbol</th><th>Pos</th><th>Qty</th><th>Entry</th><th>Day PnL</th></tr>${liveRows}</table></div>
  <div class='card span12'><h3>Daily PnL History</h3><table><tr><th>Symbol</th><th>Mode</th><th>Day</th><th>PnL</th></tr>${dailyRows}</table></div>`
}
load(); setInterval(load, 3000)
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/api/state'):
            body = json.dumps(build_snapshot()).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        body = HTML.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        return


def start_dashboard_server(host: str = '127.0.0.1', port: int = 8765) -> bool:
    global _server, _thread
    if _thread and _thread.is_alive():
        return True
    try:
        _server = ThreadingHTTPServer((host, int(port)), Handler)
    except OSError:
        return False
    _thread = threading.Thread(target=_server.serve_forever, name='DashboardWeb', daemon=True)
    _thread.start()
    return True
