from __future__ import annotations

import json
import logging
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

from .log_parser import load_trade_samples
from .v2_lab import build_lab_report

LOG = logging.getLogger('aster.agent')


class AgentService:
    def __init__(self, base_dir: str | Path, interval_sec: float = 120.0):
        self.base_dir = Path(base_dir)
        self.interval_sec = max(15.0, float(interval_sec))
        self.state_path = self.base_dir / 'agent_state_v2.json'
        self.overrides_path = self.base_dir / 'agent_overrides_v2.json'
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._cache: Dict[str, Any] = {}

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run_loop, name='AgentService', daemon=True)
        self._thread.start()
        LOG.info('AI lab agent started (interval=%ss)', self.interval_sec)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=10)

    def _run_loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.run_once()
            except Exception as e:
                LOG.error('Agent run failed: %s', e)
            self._stop.wait(self.interval_sec)

    def run_once(self) -> Dict[str, Any]:
        samples = load_trade_samples(self.base_dir)
        report = build_lab_report(samples)
        report['updated_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        tmp = self.state_path.with_suffix('.tmp')
        tmp.write_text(json.dumps(report, indent=2), encoding='utf-8')
        tmp.replace(self.state_path)
        overrides = report.get('promoted_overrides', {})
        tmp2 = self.overrides_path.with_suffix('.tmp')
        tmp2.write_text(json.dumps(overrides, indent=2), encoding='utf-8')
        tmp2.replace(self.overrides_path)
        self._cache = report
        LOG.info('AI lab refresh: %d samples | %d promoted symbols', report.get('sample_count', 0), len(overrides))
        return report

    def get_state(self) -> Dict[str, Any]:
        if self._cache:
            return dict(self._cache)
        if self.state_path.exists():
            try:
                return json.loads(self.state_path.read_text(encoding='utf-8'))
            except Exception:
                return {}
        return {}

    def get_symbol_override(self, symbol: str) -> Dict[str, Any]:
        symbol = symbol.strip().upper()
        path = self.overrides_path
        if not path.exists():
            return {}
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            return {}
        return data.get(symbol, {}) if isinstance(data, dict) else {}
