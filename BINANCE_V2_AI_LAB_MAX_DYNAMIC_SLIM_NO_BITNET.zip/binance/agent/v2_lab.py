from __future__ import annotations

from collections import defaultdict
from statistics import median
from typing import Any, Dict, List

from .log_parser import TradeSample


def _round(x: float, n: int = 4) -> float:
    return round(float(x), n)


def metrics_for(trades: List[TradeSample]) -> Dict[str, float]:
    if not trades:
        return {
            'trades': 0, 'win_rate': 0.0, 'avg_pnl': 0.0, 'profit_factor': 0.0,
            'gross_win': 0.0, 'gross_loss': 0.0, 'drawdown': 0.0, 'false_positive_rate': 0.0,
            'avg_win': 0.0, 'avg_loss': 0.0, 'median_hold_sec': 0.0, 'catastrophic_rate': 0.0,
        }
    wins = [t.pnl for t in trades if t.pnl > 0]
    losses = [t.pnl for t in trades if t.pnl <= 0]
    gross_win = sum(wins)
    gross_loss = abs(sum(losses))
    equity = 0.0
    peak = 0.0
    max_dd = 0.0
    for t in trades:
        equity += t.pnl
        peak = max(peak, equity)
        max_dd = max(max_dd, peak - equity)
    return {
        'trades': len(trades),
        'win_rate': _round(sum(1 for t in trades if t.pnl > 0) / len(trades)),
        'avg_pnl': _round(sum(t.pnl for t in trades) / len(trades)),
        'profit_factor': _round((gross_win / gross_loss) if gross_loss > 0 else (9.99 if gross_win > 0 else 0.0)),
        'gross_win': _round(gross_win), 'gross_loss': _round(gross_loss), 'drawdown': _round(max_dd),
        'false_positive_rate': _round(sum(1 for t in trades if t.pnl <= 0) / len(trades)),
        'avg_win': _round(sum(wins) / len(wins)) if wins else 0.0,
        'avg_loss': _round(abs(sum(losses) / len(losses))) if losses else 0.0,
        'median_hold_sec': _round(median([t.held_sec for t in trades]) if trades else 0.0),
        'catastrophic_rate': _round(sum(t.catastrophic for t in trades) / len(trades)),
    }


def passes_candidate(t: TradeSample, candidate: Dict[str, Any]) -> bool:
    if t.spread_bps > candidate['MAX_SPREAD_BPS']:
        return False
    if t.wall_total < candidate['MIN_WALL_TOTAL']:
        return False
    if -candidate['MIN_OFI_ABS'] < t.ofi < candidate['MIN_OFI_ABS']:
        return False
    if candidate.get('ALLOW_REGIMES') and t.regime not in candidate['ALLOW_REGIMES']:
        return False
    return True


def _derive_exit_pack(selected: List[TradeSample], fallback: List[TradeSample]) -> Dict[str, float]:
    src = selected or fallback
    wins = [t.pnl for t in src if t.pnl > 0]
    losses = [abs(t.pnl) for t in src if t.pnl <= 0]
    avg_win = (sum(wins) / len(wins)) if wins else 6.0
    avg_loss = (sum(losses) / len(losses)) if losses else 5.0
    holds = sorted([max(5.0, t.held_sec) for t in src]) or [45.0]
    med_hold = median(holds)
    p75_hold = holds[min(len(holds) - 1, int(len(holds) * 0.75))]
    catastrophic_rate = (sum(t.catastrophic for t in src) / len(src)) if src else 0.0
    trail_frac = 0.36 if catastrophic_rate < 0.10 else 0.28
    be_frac = 0.30 if catastrophic_rate < 0.10 else 0.22
    stagnation_unreal = max(0.20, avg_win * 0.08)
    return {
        'TP_USD_FIXED': _round(max(2.0, avg_win * 0.82), 3),
        'SL_USD_FIXED': _round(max(1.5, min(avg_loss * 0.96, max(2.0, avg_win * 0.92))), 3),
        'TRAIL_START_FRAC_TP': _round(trail_frac, 3),
        'TRAIL_ATR_GAP_MULT': _round(0.72 if catastrophic_rate < 0.12 else 0.62, 3),
        'BREAK_EVEN_AFTER_FRAC_TP': _round(be_frac, 3),
        'MAX_HOLD_SEC': _round(max(25.0, min(480.0, p75_hold * 1.20)), 3),
        'STAGNATION_HOLD_SEC': _round(max(12.0, min(240.0, med_hold * 0.80)), 3),
        'STAGNATION_MIN_UNREAL_USD': _round(stagnation_unreal, 3),
    }


def score_candidate(trades: List[TradeSample], candidate: Dict[str, Any]) -> Dict[str, Any]:
    selected = [t for t in trades if passes_candidate(t, candidate)]
    m = metrics_for(selected)
    coverage = (len(selected) / len(trades)) if trades else 0.0
    score = (
        m['win_rate'] * 0.34 + min(m['profit_factor'], 3.0) / 3.0 * 0.24 +
        max(0.0, m['avg_pnl']) / max(1.0, abs(m['avg_pnl']) + 1.0) * 0.16 +
        coverage * 0.12 + max(0.0, 1.0 - m['catastrophic_rate']) * 0.14
    ) - min(1.0, m['drawdown'] / 100.0) * 0.10
    out = dict(candidate)
    out.update(_derive_exit_pack(selected, trades))
    out['metrics'] = m
    out['coverage'] = _round(coverage)
    out['score'] = _round(score)
    return out


def optimize_symbol(trades: List[TradeSample]) -> Dict[str, Any]:
    baseline = metrics_for(trades)
    if len(trades) < 6:
        return {'baseline': baseline, 'best': None, 'promotion_ready': False, 'reason': 'not_enough_trades'}
    regimes = defaultdict(list)
    for t in trades:
        regimes[t.regime].append(t)
    good_regimes = [r for r, xs in regimes.items() if len(xs) >= 2 and metrics_for(xs)['win_rate'] >= 0.5] or sorted(regimes.keys())
    spread_values = sorted([max(0.8, t.spread_bps * 1.05) for t in trades])
    wall_values = sorted([max(1000.0, t.wall_total * 0.85) for t in trades])
    ofi_values = [0.03, 0.05, 0.07, 0.10, 0.12]
    def q(xs: List[float], frac: float, fallback: float) -> float:
        if not xs: return fallback
        idx = min(len(xs) - 1, max(0, int(len(xs) * frac)))
        return float(xs[idx])
    spread_grid = [q(spread_values, 0.35, 5.0), q(spread_values, 0.55, 8.0), q(spread_values, 0.75, 12.0)]
    wall_grid = [q(wall_values, 0.25, 50000.0), q(wall_values, 0.40, 150000.0), q(wall_values, 0.55, 300000.0)]
    candidates = []
    for s in spread_grid:
        for w in wall_grid:
            for ofi in ofi_values:
                candidates.append({'MAX_SPREAD_BPS': round(float(s), 4), 'MIN_WALL_TOTAL': round(float(w), 4), 'MIN_OFI_ABS': float(ofi), 'ALLOW_REGIMES': good_regimes[:]})
    ranked = sorted((score_candidate(trades, c) for c in candidates), key=lambda x: x['score'], reverse=True)
    best = ranked[0] if ranked else None
    promotion_ready = False
    if best:
        bm = best['metrics']
        promotion_ready = (bm['trades'] >= max(4, int(len(trades) * 0.35)) and bm['win_rate'] >= max(0.55, baseline['win_rate'] + 0.03) and bm['profit_factor'] >= max(1.10, baseline['profit_factor']) and bm['avg_pnl'] >= baseline['avg_pnl'] and bm['catastrophic_rate'] <= max(0.25, baseline['catastrophic_rate']))
    by_day = defaultdict(float)
    for t in trades:
        if t.day:
            by_day[t.day] += t.pnl
    return {
        'baseline': baseline, 'best': best, 'promotion_ready': promotion_ready, 'reason': 'ok' if best else 'no_candidate',
        'regime_breakdown': {r: metrics_for(xs) for r, xs in regimes.items()},
        'source_breakdown': {src: metrics_for([t for t in trades if t.source == src]) for src in sorted({t.source for t in trades})},
        'daily_pnl': {k: _round(v) for k, v in sorted(by_day.items())[-14:]},
    }


def build_lab_report(samples: List[TradeSample]) -> Dict[str, Any]:
    by_symbol: Dict[str, List[TradeSample]] = defaultdict(list)
    for s in samples:
        by_symbol[s.symbol].append(s)
    symbol_reports = {sym: optimize_symbol(ts) for sym, ts in sorted(by_symbol.items())}
    promoted = {sym: rep['best'] for sym, rep in symbol_reports.items() if rep.get('promotion_ready') and rep.get('best')}
    return {'symbols': symbol_reports, 'portfolio': metrics_for(samples), 'promoted_overrides': promoted, 'sample_count': len(samples)}
