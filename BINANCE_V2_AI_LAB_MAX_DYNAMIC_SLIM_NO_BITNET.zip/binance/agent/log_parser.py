from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


@dataclass
class TradeSample:
    symbol: str
    side: str
    entry_ts: str
    exit_ts: str
    entry_price: float
    exit_price: float
    qty: float
    pnl: float
    held_sec: float
    exit_reason: str
    source: str
    p_up: float
    ofi: float
    slope: float
    vol_bps: float
    vol_med: float
    spread_bps: float
    wall_total: float
    regime: str
    won: int
    day: str = ""
    vol_ratio: float = 1.0
    catastrophic: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def classify_trade_regime(ofi: float, slope: float, vol_bps: float, vol_med: float, spread_bps: float) -> str:
    vol_ratio = (vol_bps / vol_med) if vol_med > 1e-9 else (2.0 if vol_bps > 0 else 1.0)
    if spread_bps >= 10.0:
        return 'EXHAUSTION'
    if vol_ratio >= 1.35 and abs(ofi) >= 0.10:
        return 'EXPANSION'
    if abs(slope) >= 1 and abs(ofi) >= 0.07:
        return 'TREND'
    if abs(slope) == 0 and abs(ofi) < 0.08:
        return 'CHOP'
    return 'NEUTRAL'


def parse_central_log(path: Path) -> List[TradeSample]:
    samples: List[TradeSample] = []
    if not path.exists():
        return samples

    last_decision: Optional[Dict[str, Any]] = None
    current_trade: Optional[Dict[str, Any]] = None

    with path.open('r', encoding='utf-8', errors='ignore') as f:
        for raw in f:
            raw = raw.strip()
            if not raw:
                continue
            try:
                evt = json.loads(raw)
            except Exception:
                continue
            event = evt.get('event')
            if event == 'DECISION':
                last_decision = evt
            elif event == 'ENTRY_FILLED':
                current_trade = {
                    'entry': evt,
                    'decision': dict(last_decision or {}),
                }
            elif event == 'EXIT_FILLED' and current_trade is not None:
                entry = current_trade.get('entry', {})
                decision = current_trade.get('decision', {})
                symbol = path.name.replace('SIM_', '').replace('_central_log.jsonl', '')
                entry_ts = str(entry.get('ts', ''))
                exit_ts = str(evt.get('ts', ''))
                ofi = _f(decision.get('ofi'))
                slope = _f(decision.get('slope'))
                vol_bps = _f(decision.get('vol_bps'))
                vol_med = _f(decision.get('vol_med'))
                spread_bps = _f(decision.get('spread_bps'))
                wall_total = _f(decision.get('wall_total'))
                regime = classify_trade_regime(ofi, slope, vol_bps, vol_med, spread_bps)
                held_sec = 0.0
                day = ''
                try:
                    from datetime import datetime
                    t0 = datetime.fromisoformat(entry_ts.replace('Z', '+00:00'))
                    t1 = datetime.fromisoformat(exit_ts.replace('Z', '+00:00'))
                    held_sec = max(0.0, (t1 - t0).total_seconds())
                    day = t1.date().isoformat()
                except Exception:
                    held_sec = 0.0
                pnl = _f(evt.get('pnl'))
                samples.append(TradeSample(
                    symbol=symbol,
                    side=str(entry.get('side', '')),
                    entry_ts=entry_ts,
                    exit_ts=exit_ts,
                    entry_price=_f(entry.get('fill')),
                    exit_price=_f(evt.get('fill')),
                    qty=_f(evt.get('qty') or entry.get('qty')),
                    pnl=pnl,
                    held_sec=held_sec,
                    exit_reason=str(evt.get('reason', '')),
                    source=str(entry.get('src') or decision.get('src') or ''),
                    p_up=_f(entry.get('p_up') or decision.get('p_up'), 0.5),
                    ofi=ofi,
                    slope=slope,
                    vol_bps=vol_bps,
                    vol_med=vol_med,
                    spread_bps=spread_bps,
                    wall_total=wall_total,
                    regime=regime,
                    won=1 if pnl > 0 else 0,
                    day=day,
                    vol_ratio=(vol_bps / vol_med) if vol_med > 1e-9 else 1.0,
                    catastrophic=1 if str(evt.get('reason', '')).upper() == 'SL_CATA' else 0,
                ))
                current_trade = None
    return samples


def load_trade_samples(base_dir: Path) -> List[TradeSample]:
    all_samples: List[TradeSample] = []
    for path in sorted(base_dir.glob('SIM_*_central_log.jsonl')):
        all_samples.extend(parse_central_log(path))
    return all_samples
