"""Exit execution: TP, SL, trailing, emergency IOC."""

from __future__ import annotations

import logging
import time
from decimal import Decimal
from typing import Optional

from core.helpers import D0, d, round_step, utc_ts, append_jsonl
from core.config import Config
from core.state import BotState, rolling_wr
from core.types import Snapshot, SymbolFilters
from exchange.client import ExchangeClient
from exchange.orders import (
    place_maker_full, place_ioc, maker_exit_px, vwap_add,
)
from strategy.risk import fixed_tp_sl, refresh_dynamic_tp_sl, update_trailing

LOG = logging.getLogger("aster")


def try_exit(
    cfg: Config, client: ExchangeClient, filt: SymbolFilters,
    st: BotState, snap: Snapshot, auth_ok: bool, acct: dict
) -> bool:
    if st.is_flat():
        return False

    # ── Refresh TP/SL ────────────────────────────────────────────────────
    if cfg.ENFORCE_CONFIG_TPSL:
        tp_fix, sl_fix = fixed_tp_sl(cfg)
        st.tp_usd = tp_fix
        st.sl_usd = sl_fix
        st.tp_init = tp_fix
        st.sl_init = sl_fix
    else:
        refresh_dynamic_tp_sl(cfg, st, snap)

    unreal = st.unreal(snap.mid)
    held = time.time() - st.entry_time
    heur_ofi_min = d(cfg.HEUR_OFI_MIN)
    stagnation_min_unreal = d(cfg.STAGNATION_MIN_UNREAL_USD)

    if (not st.tp_touched) and st.tp_usd > 0 and unreal >= st.tp_usd:
        st.tp_touched = True
        st.tp_touch_ts = time.time()
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "TP_TOUCHED",
                                            "unreal": str(unreal), "tp": str(st.tp_usd), "held": held})

    update_trailing(cfg, st, snap, unreal)

    if st.tp_usd > 0 and unreal >= (st.tp_usd * cfg.BREAK_EVEN_AFTER_FRAC_TP):
        st.trail_usd = max(st.trail_usd, st.entry_est_cost * cfg.BE_LOCK_COST_MULT)

    # ── Exit reason ──────────────────────────────────────────────────────
    reason: Optional[str] = None
    hardstop = False

    if st.sl_usd > 0 and unreal <= -(st.sl_usd * cfg.HARD_SL_MULT):
        reason = "SL_CATA"
        hardstop = True
    elif st.tp_usd > 0 and unreal >= st.tp_usd:
        reason = "TP"
    elif st.tp_touched and st.trail_usd > 0 and unreal <= st.trail_usd:
        reason = "TRAIL"
    elif st.sl_usd > 0 and unreal <= -st.sl_usd:
        reason = "SL"
    elif cfg.REVERSAL_EXIT_ON_OFI and unreal > D0 and ((st.position == "LONG" and snap.ofi < -heur_ofi_min) or (st.position == "SHORT" and snap.ofi > heur_ofi_min)):
        reason = "OFI_REVERSAL"
    elif held >= cfg.MAX_HOLD_SEC and unreal > D0:
        reason = "MAX_HOLD"
    elif held >= cfg.STAGNATION_HOLD_SEC and unreal <= stagnation_min_unreal:
        reason = "STAGNANT"

    if not reason:
        return False

    # ── Execute exit ─────────────────────────────────────────────────────
    use_market_first = (reason in ("SL", "SL_CATA"))
    use_maker = (not use_market_first) and cfg.MAKER_ONLY_EXIT

    best_bid, best_ask = snap.best_bid, snap.best_ask
    remaining = st.qty
    total_closed = D0
    sum_px_qty = D0
    sum_qty = D0
    status = ""
    exec_mode = "MARKET_FIRST" if use_market_first else ("MAKER_EXIT" if use_maker else "IOC_EXIT")
    bad_orders = 0
    t0 = time.time()

    # ── Market-first (SL) ────────────────────────────────────────────────
    if use_market_first:
        side = "SELL" if st.position == "LONG" else "BUY"
        while remaining >= filt.min_qty and (time.time() - t0) <= cfg.EXIT_MAX_SECONDS_TOTAL:
            got, vwap, stt = place_ioc(
                cfg, client, filt, auth_ok, side, remaining, best_bid, best_ask,
                reduce_only=True, slippage_ticks=max(2, cfg.IOC_EMERGENCY_SLIPPAGE_TICKS)
            )
            status = f"{status}+{stt}" if status else stt
            if got > 0:
                use_px = vwap if vwap is not None else (best_bid if side == "SELL" else best_ask)
                sum_px_qty, sum_qty = vwap_add(sum_px_qty, sum_qty, use_px, got)
                total_closed += got
                remaining = round_step(max(D0, st.qty - total_closed), filt.qty_step)
                if remaining < filt.min_qty:
                    break
            else:
                time.sleep(0.12)
                client.invalidate_depth_cache()
                depth2 = client.get_depth_cached()
                if depth2 and depth2.get("bids") and depth2.get("asks"):
                    best_bid = d(depth2["bids"][0][0])
                    best_ask = d(depth2["asks"][0][0])

    # ── Maker exit (TP/TRAIL) ────────────────────────────────────────────
    while remaining >= filt.min_qty and (time.time() - t0) <= cfg.EXIT_MAX_SECONDS_TOTAL and (not use_market_first):
        if use_maker:
            side, px = maker_exit_px(filt, st.position, best_bid, best_ask)
            got, vwap, stt = place_maker_full(
                cfg, client, filt, auth_ok, side, remaining, px,
                reduce_only=True,
                life_sec=cfg.MAKER_EXIT_LIFE_SEC,
                total_budget_sec=min(cfg.MAKER_EXIT_LIFE_SEC + 0.75, cfg.EXIT_MAX_SECONDS_TOTAL),
            )
            status = stt

            if (not got) and ("NO_ORDERID" in stt or "AUTH_BLOCK" in stt):
                bad_orders += 1
                if bad_orders >= cfg.MAX_CONSEC_BAD_ORDER_ATTEMPTS:
                    LOG.warning("EXIT GUARD: too many bad attempts -> escalate. reason=%s", reason)
                    break

            if got > 0:
                use_px = vwap if vwap is not None else px
                sum_px_qty, sum_qty = vwap_add(sum_px_qty, sum_qty, use_px, got)
                total_closed += got
                remaining = round_step(max(D0, st.qty - total_closed), filt.qty_step)

            if remaining <= 0:
                break

            time.sleep(cfg.MAKER_REPRICE_SLEEP)
            client.invalidate_depth_cache()
            depth2 = client.get_depth_cached()
            if depth2 and depth2.get("bids") and depth2.get("asks"):
                best_bid = d(depth2["bids"][0][0])
                best_ask = d(depth2["asks"][0][0])

            if hardstop and cfg.EXIT_ALLOW_IOC_ESCALATION:
                break
        else:
            side = "SELL" if st.position == "LONG" else "BUY"
            got, vwap, stt = place_ioc(
                cfg, client, filt, auth_ok, side, remaining, best_bid, best_ask,
                reduce_only=True, slippage_ticks=cfg.IOC_EMERGENCY_SLIPPAGE_TICKS
            )
            status = stt
            if got > 0:
                use_px = vwap if vwap is not None else (best_bid if side == "SELL" else best_ask)
                sum_px_qty, sum_qty = vwap_add(sum_px_qty, sum_qty, use_px, got)
                total_closed += got
                remaining = round_step(max(D0, st.qty - total_closed), filt.qty_step)
            break

    # ── IOC escalation ───────────────────────────────────────────────────
    if remaining >= filt.min_qty and (not use_market_first) and cfg.EXIT_ALLOW_IOC_ESCALATION:
        exec_mode = "TIMEOUT_IOC" if (not hardstop) else "EMERGENCY_IOC"
        side_ioc = "SELL" if st.position == "LONG" else "BUY"
        got2, vwap2, stt2 = place_ioc(
            cfg, client, filt, auth_ok, side_ioc, remaining, best_bid, best_ask,
            reduce_only=True, slippage_ticks=cfg.IOC_EMERGENCY_SLIPPAGE_TICKS
        )
        status = f"{status}+{stt2}" if status else stt2
        if got2 > 0:
            sum_px_qty, sum_qty = vwap_add(sum_px_qty, sum_qty, vwap2, got2)
            total_closed += got2
            remaining = round_step(max(D0, st.qty - total_closed), filt.qty_step)

    if total_closed <= 0 or sum_qty <= 0:
        LOG.info("EXIT NOFILL: reason=%s exec=%s status=%s", reason, exec_mode, status or "NONE")
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "EXIT_NOFILL", "reason": reason})
        return False

    # ── PnL accounting ───────────────────────────────────────────────────
    vwap_exit = sum_px_qty / sum_qty
    pnl_closed = ((vwap_exit - st.entry_price) * total_closed) if st.position == "LONG" else ((st.entry_price - vwap_exit) * total_closed)
    st.realized_day_pnl += pnl_closed
    st.pnl_history.append(pnl_closed)
    day_key = str(st.current_day or utc_ts()[:10])
    prev_day_total = d(st.daily_pnl.get(day_key, "0"))
    st.daily_pnl[day_key] = str(prev_day_total + pnl_closed)

    fully_closed = remaining < filt.min_qty
    if fully_closed or (not cfg.EXIT_FORCE_COMPLETE):
        win = 1 if pnl_closed > 0 else 0
        st.trade_outcomes.append(win)
        st.loss_streak = 0 if win else (st.loss_streak + 1)
        cool = cfg.COOLDOWN_AFTER_LOSS_SEC if pnl_closed <= 0 else cfg.COOLDOWN_AFTER_EXIT_SEC
        st.next_entry_time = time.time() + cool

        LOG.info("EXIT %s reason=%s exec=%s fill=%s qty=%s pnl=%+.6f held=%.1fs WR=%.0f%% tp_touched=%s",
                 st.position, reason, exec_mode, vwap_exit, total_closed, pnl_closed, held,
                 float(rolling_wr(st.trade_outcomes) * 100), st.tp_touched)

        append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "EXIT_FILLED",
                                            "reason": reason, "exec": exec_mode,
                                            "fill": str(vwap_exit), "qty": str(total_closed),
                                            "pnl": str(pnl_closed), "fully_closed": True,
                                            "tp_touched": bool(st.tp_touched),
                                            "enforced_tpsl": bool(cfg.ENFORCE_CONFIG_TPSL)})
        st.clear()
        return True

    st.qty = remaining
    append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "EXIT_PARTIAL",
                                        "reason": reason, "closed_qty": str(total_closed),
                                        "remaining_qty": str(remaining), "pnl_closed": str(pnl_closed)})
    LOG.info("EXIT PARTIAL: reason=%s closed=%s remain=%s pnl=%+.6f", reason, total_closed, remaining, pnl_closed)
    return False
