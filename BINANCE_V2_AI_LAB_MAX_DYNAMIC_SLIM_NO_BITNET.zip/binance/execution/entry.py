"""Entry execution: maker/IOC entry with sizing and confirmation."""

from __future__ import annotations

import logging
import time
from decimal import Decimal
from typing import Optional

from core.helpers import D0, d, clamp, round_step, utc_ts, append_jsonl
from core.config import Config
from core.state import BotState
from core.types import Snapshot, SymbolFilters
from exchange.client import ExchangeClient
from exchange.market import estimate_costs
from exchange.orders import (
    place_maker_full, place_ioc, maker_entry_px, vwap_add,
)
from strategy.decision import pick_action, confirm_action
from strategy.risk import calc_qty, decide_tp_sl
from learning.model import OnlineLogReg

LOG = logging.getLogger("aster")


def try_entry(
    cfg: Config, client: ExchangeClient, filt: SymbolFilters,
    st: BotState, snap: Snapshot, auth_ok: bool, acct: dict,
    model: OnlineLogReg, vol_med: Decimal
) -> bool:
    if not st.is_flat():
        return False
    if time.time() < st.next_entry_time:
        return False
    if st.realized_day_pnl <= -cfg.MAX_DAILY_LOSS_USD:
        return False

    action, p_up, src = pick_action(cfg, model, snap, vol_med)
    ok_confirm = confirm_action(cfg, st, action)

    append_jsonl(cfg.CENTRAL_LOG_JSONL, {
        "ts": utc_ts(), "event": "DECISION",
        "mid": str(snap.mid), "ofi": str(snap.ofi), "slope": snap.slope,
        "vol_bps": str(snap.vol_bps), "vol_med": str(vol_med),
        "spread_bps": str(snap.spread_bps), "wall_total": str(snap.wall_total),
        "wall_band_bps": str(snap.wall_band_bps),
        "p_up": p_up, "action": action, "src": src,
        "confirmL": st.confirm_streak_long, "confirmS": st.confirm_streak_short
    })

    if not ok_confirm or action is None:
        return False

    # ── Funding check ────────────────────────────────────────────────────
    funding = client.get_funding_rate()
    if funding >= Decimal("0.00012") and action == "LONG":
        LOG.info("Skip LONG — high funding: %s", funding)
        return False
    if funding <= Decimal("-0.00008") and action == "SHORT":
        LOG.info("Skip SHORT — negative funding: %s", funding)
        return False

    # ── Account + sizing ─────────────────────────────────────────────────
    acct2 = client.get_account_cached(auth_ok, force=True) if (not cfg.SIMULATION_MODE) else {}
    avail_usdt = d(acct2.get("avail_usdt", "0")) if acct2 else D0
    wallet_usdt = d(acct2.get("wallet_usdt", "0")) if acct2 else D0
    if cfg.SIMULATION_MODE:
        avail_usdt = Decimal("999999")
        wallet_usdt = Decimal("999999")

    if wallet_usdt > 0:
        st.peak_wallet_usdt = max(st.peak_wallet_usdt, wallet_usdt)

    dd = 0.0
    if st.peak_wallet_usdt > 0 and wallet_usdt > 0:
        try:
            dd_dec = (st.peak_wallet_usdt - wallet_usdt) / st.peak_wallet_usdt
            dd = float(max(D0, dd_dec))
        except Exception:
            dd = 0.0

    atr_factor = clamp(snap.atr_price / Decimal("0.001"), Decimal("0.6"), Decimal("1.8"))
    dd_factor = (Decimal("1.0") - (Decimal(str(dd)) / Decimal("0.10"))) if dd > 0 else Decimal("1.0")
    lev_eff = int(clamp(Decimal(str(cfg.LEVERAGE)) * atr_factor * dd_factor, Decimal("15"), Decimal("35")))

    base_funds = avail_usdt if avail_usdt > 0 else wallet_usdt
    qty, notional = calc_qty(cfg, filt, snap.mid, base_funds, lev_eff)
    if qty <= 0:
        return False

    side = "BUY" if action == "LONG" else "SELL"
    filled = D0
    fill_px: Optional[Decimal] = None
    status = ""
    st.bad_order_attempts = 0

    # ── Execute ──────────────────────────────────────────────────────────
    if cfg.MAKER_ONLY_ENTRY:
        t0 = time.time()
        remaining = qty
        sum_px_qty = D0
        sum_qty = D0
        best_bid, best_ask = snap.best_bid, snap.best_ask

        while remaining >= filt.min_qty and (time.time() - t0) <= cfg.ENTRY_MAX_SECONDS_TOTAL:
            px = maker_entry_px(side, best_bid, best_ask)
            got, vwap, stt = place_maker_full(
                cfg, client, filt, auth_ok, side, remaining, px,
                reduce_only=False,
                life_sec=cfg.MAKER_ENTRY_LIFE_SEC,
                total_budget_sec=min(cfg.MAKER_ENTRY_LIFE_SEC + 0.25, cfg.ENTRY_MAX_SECONDS_TOTAL),
            )
            status = stt

            if (not got) and ("NO_ORDERID" in stt or "AUTH_BLOCK" in stt):
                st.bad_order_attempts += 1
                if st.bad_order_attempts >= cfg.MAX_CONSEC_BAD_ORDER_ATTEMPTS:
                    LOG.warning("ENTRY GUARD: too many bad attempts (%s) -> cooldown", st.bad_order_attempts)
                    st.next_entry_time = time.time() + cfg.BAD_ORDER_COOLDOWN_SEC
                    return False

            if got > 0:
                use_px = vwap if vwap is not None else px
                sum_px_qty, sum_qty = vwap_add(sum_px_qty, sum_qty, use_px, got)
                filled += got
                remaining = round_step(max(D0, qty - filled), filt.qty_step)

            if remaining <= 0:
                break

            time.sleep(cfg.MAKER_REPRICE_SLEEP)
            client.invalidate_depth_cache()
            depth2 = client.get_depth_cached()
            if depth2 and depth2.get("bids") and depth2.get("asks"):
                best_bid = d(depth2["bids"][0][0])
                best_ask = d(depth2["asks"][0][0])

        fill_px = (sum_px_qty / sum_qty) if sum_qty > 0 else None
    else:
        got, fp, stt = place_ioc(
            cfg, client, filt, auth_ok, side, qty, snap.best_bid, snap.best_ask,
            reduce_only=False, slippage_ticks=cfg.IOC_EMERGENCY_SLIPPAGE_TICKS
        )
        status = stt
        filled, fill_px = got, fp

    if filled <= 0 or fill_px is None:
        LOG.info("ENTRY NOFILL: side=%s status=%s src=%s", side, status, src)
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "ENTRY_NOFILL", "status": status, "src": src})
        return False

    # ── Fill state ───────────────────────────────────────────────────────
    notional_actual = filled * fill_px
    est_cost_actual = estimate_costs(cfg, notional_actual, snap.spread, filled)
    tp, sl = decide_tp_sl(cfg, snap.atr_price, filled, est_cost_actual)

    st.position = action
    st.qty = filled
    st.entry_price = fill_px
    st.entry_time = time.time()
    st.tp_usd = tp
    st.sl_usd = sl
    st.trail_usd = D0
    st.peak_unreal = D0
    st.entry_est_cost = est_cost_actual
    st.tp_init = tp
    st.sl_init = sl
    st.last_tpsl_refresh = time.time()
    st.tp_touched = False
    st.tp_touch_ts = 0.0
    st.confirm_streak_long = 0
    st.confirm_streak_short = 0
    st.adopted_from_exchange = False

    LOG.info("ENTRY %s qty=%s fill=%s src=%s p_up=%.3f TP=%s SL=%s cost=%s lev_eff=%s",
             st.position, st.qty, st.entry_price, src, p_up, st.tp_usd, st.sl_usd,
             st.entry_est_cost, lev_eff)

    append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "ENTRY_FILLED",
                                        "side": st.position, "qty": str(st.qty), "fill": str(st.entry_price),
                                        "tp": str(st.tp_usd), "sl": str(st.sl_usd), "cost": str(st.entry_est_cost),
                                        "src": src, "p_up": p_up, "lev_eff": lev_eff,
                                        "enforced_tpsl": bool(cfg.ENFORCE_CONFIG_TPSL)})
    return True
