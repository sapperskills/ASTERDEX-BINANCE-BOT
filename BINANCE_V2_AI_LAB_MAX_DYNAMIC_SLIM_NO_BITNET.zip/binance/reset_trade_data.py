#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

BASE = Path(__file__).resolve().parent

SOFT_PATTERNS = [
    '*_state.json', '*_trades.csv', '*_central_log.jsonl', '*_learning_log.jsonl'
]
HARD_EXTRA = [
    '*_lr_model.json', '*_symbol_profile.json', 'agent_state_v2.json', 'promotion_state.json',
    'population_state.json', 'agent_overrides_v2.json', 'adaptive_state/adaptive_state.json'
]


def remove_matches(patterns):
    removed = []
    for pat in patterns:
        for p in BASE.glob(pat):
            try:
                if p.is_file():
                    p.unlink()
                    removed.append(str(p.name))
            except Exception:
                pass
    return removed


def main():
    ap = argparse.ArgumentParser(description='Reset bot trade data, logs, and optionally learned state.')
    ap.add_argument('--hard', action='store_true', help='also wipe models, overrides, promotion state, and profiles')
    args = ap.parse_args()
    removed = remove_matches(SOFT_PATTERNS + (HARD_EXTRA if args.hard else []))
    print('removed_files=', len(removed))
    for name in sorted(removed):
        print(name)


if __name__ == '__main__':
    main()
