"""Market data: price, depth, walls, OFI, spread, volatility."""

from __future__ import annotations

from collections import deque
from decimal import Decimal
from typing import Deque, Optional, Tuple

from core.helpers import D0, D1, d
from core.config import Config
from exchange.client import ExchangeClient


def get_price(cfg: Config, client: ExchangeClient) -> Decimal:
    dct = client.get("/fapi/v1/ticker/price", {"symbol": cfg.SYMBOL})
    if isinstance(dct, dict) and "price" in dct:
        try:
            return d(dct["price"])
        except Exception:
            return D0
    return D0


def spread_bps(mid: Decimal, best_bid: Decimal, best_ask: Decimal) -> Decimal:
    if mid <= 0:
        return D0
    sp = best_ask - best_bid
    if sp <= 0:
        return D0
    return (sp / mid) * Decimal("10000")


def band_prices(mid: Decimal, band_bps: Decimal) -> Tuple[Decimal, Decimal]:
    if mid <= 0 or band_bps <= 0:
        return mid, mid
    frac = band_bps / Decimal("10000")
    lo = mid * (D1 - frac)
    hi = mid * (D1 + frac)
    return lo, hi


def get_walls(cfg: Config, depth: dict, mid: Decimal, band_bps: Decimal) -> Tuple[Decimal, Decimal, Decimal, Decimal]:
    try:
        bids = depth["bids"]
        asks = depth["asks"]
        if not bids or not asks:
            return (D0, D0, D0, D0)
        best_bid = d(bids[0][0])
        best_ask = d(asks[0][0])
        spread = best_ask - best_bid

        lo, hi = band_prices(mid, band_bps)

        total = D0
        for p, q in bids[:220]:
            p_dec = d(p)
            if p_dec >= lo:
                total += p_dec * d(q)
        for p, q in asks[:220]:
            p_dec = d(p)
            if p_dec <= hi:
                total += p_dec * d(q)
        return best_bid, best_ask, spread, total
    except Exception:
        return (D0, D0, D0, D0)


def order_flow_imbalance(depth: dict, mid: Decimal, ofi_ema: Decimal, band_bps: Decimal) -> Decimal:
    try:
        lo, hi = band_prices(mid, band_bps)
        bp = D0
        ap = D0
        for p, q in depth["bids"][:220]:
            p_dec = d(p)
            if p_dec >= lo:
                bp += p_dec * d(q)
        for p, q in depth["asks"][:220]:
            p_dec = d(p)
            if p_dec <= hi:
                ap += p_dec * d(q)
        tot = bp + ap
        if tot <= 0:
            return ofi_ema
        raw = (bp - ap) / tot
    except Exception:
        return ofi_ema
    alpha = Decimal("0.22")
    return alpha * raw + (D1 - alpha) * ofi_ema


def estimate_costs(cfg: Config, notional: Decimal, spread: Decimal, qty: Decimal) -> Decimal:
    fee = cfg.TAKER_FEE_RATE * notional * Decimal("2")
    spr = spread * qty
    return fee + spr


class RollingMinMax:
    """Tracks rolling min/max over a fixed-length window."""

    def __init__(self, maxlen: int):
        self._buf: Deque[Decimal] = deque(maxlen=maxlen)
        self._maxlen = maxlen

    def push(self, val: Decimal) -> None:
        self._buf.append(val)

    @property
    def min(self) -> Decimal:
        return min(self._buf) if self._buf else D0

    @property
    def max(self) -> Decimal:
        return max(self._buf) if self._buf else D0

    def __len__(self) -> int:
        return len(self._buf)
