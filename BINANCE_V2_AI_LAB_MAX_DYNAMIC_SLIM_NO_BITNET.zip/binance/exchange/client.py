"""Exchange HTTP client: signing, time sync, account, positions.

Universal client for Aster DEX and Binance Futures — both use identical
/fapi/v1/ and /fapi/v2/ REST endpoints with HMAC-SHA256 signing.
Only the base_url differs between the two exchanges.

Supported base URLs:
  Aster:           https://fapi.asterdex.com
  Binance:         https://fapi.binance.com
  Binance testnet: https://testnet.binancefuture.com
"""

from __future__ import annotations

import hmac
import hashlib
import logging
import time
import urllib.parse
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple

import requests

from core.helpers import D0, d
from core.config import Config

LOG = logging.getLogger("aster")


class ExchangeClient:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.base_url = cfg.BASE_URL.rstrip("/")
        self.api_key = (cfg.API_KEY or "").strip()
        self.api_secret = (cfg.API_SECRET or "").strip()
        self.sess = requests.Session()
        self._time_skew_ms = 0
        adapter = requests.adapters.HTTPAdapter(pool_connections=10, pool_maxsize=20, max_retries=0)
        self.sess.mount("http://", adapter)
        self.sess.mount("https://", adapter)
        self._depth_cache: Optional[dict] = None
        self._depth_cache_ts: float = 0.0
        self._acct_cache: Optional[dict] = None
        self._acct_cache_ts: float = 0.0

    # ── HTTP primitives ──────────────────────────────────────────────────

    def _timeout(self) -> Tuple[float, float]:
        return (2.0, 2.8) if self.cfg.LIVE_PROFILE else (2.0, 3.8)

    def _sleep_backoff(self, attempt: int) -> None:
        time.sleep(self.cfg.HTTP_BACKOFF_BASE * (2 ** attempt))

    def get(self, path: str, params: Optional[dict] = None) -> Optional[object]:
        url = self.base_url + path
        for attempt in range(self.cfg.HTTP_MAX_RETRIES):
            try:
                r = self.sess.get(url, params=params, timeout=self._timeout())
                if r.status_code == 200:
                    return r.json()
                if r.status_code in (429, 502, 503, 504):
                    self._sleep_backoff(attempt)
                    continue
                return None
            except requests.exceptions.RequestException:
                self._sleep_backoff(attempt)
        return None

    # ── Time sync ────────────────────────────────────────────────────────

    def _server_time_ms(self) -> int:
        dct = self.get("/fapi/v1/time")
        if isinstance(dct, dict) and "serverTime" in dct:
            try:
                return int(dct["serverTime"])
            except Exception:
                pass
        return int(time.time() * 1000)

    def sync_time(self) -> None:
        stt = self._server_time_ms()
        lt = int(time.time() * 1000)
        self._time_skew_ms = stt - lt
        LOG.info("Time sync: skew_ms=%s", self._time_skew_ms)

    def _now_ms(self) -> int:
        return int(time.time() * 1000) + int(self._time_skew_ms)

    # ── Signing ──────────────────────────────────────────────────────────

    def _encode_params(self, params: List[Tuple[str, str]]) -> str:
        return urllib.parse.urlencode(params, doseq=True, quote_via=urllib.parse.quote)

    def _hmac_sig_hex(self, qs: str) -> str:
        return hmac.new(
            self.api_secret.encode("utf-8"),
            msg=qs.encode("utf-8"),
            digestmod=hashlib.sha256
        ).hexdigest()

    def signed(self, method: str, endpoint: str, params: Optional[dict] = None) -> Optional[object]:
        if not self.api_key or not self.api_secret:
            return {"_auth_401": True, "msg": "Missing API_KEY/API_SECRET"}

        raw = params or {}
        p_list: List[Tuple[str, str]] = [(k, str(v)) for k, v in raw.items()]
        p_list.append(("timestamp", str(self._now_ms())))
        p_list.append(("recvWindow", str(int(self.cfg.SIGNED_RECV_WINDOW))))

        qs = self._encode_params(p_list)
        sig = self._hmac_sig_hex(qs)
        url = f"{self.base_url}{endpoint}?{qs}&signature={sig}"
        headers = {"X-MBX-APIKEY": self.api_key}

        for attempt in range(self.cfg.HTTP_MAX_RETRIES):
            try:
                r = self.sess.request(method, url, headers=headers, timeout=(3.0, 6.0))
                if r.status_code == 200:
                    return r.json()
                if r.status_code == 401:
                    return {"_auth_401": True, "msg": r.text[:250]}
                if r.status_code in (429, 502, 503, 504):
                    self._sleep_backoff(attempt)
                    continue
                try:
                    return r.json()
                except Exception:
                    return {"_http_error": r.status_code, "text": r.text[:250]}
            except requests.exceptions.RequestException:
                self._sleep_backoff(attempt)
        return None

    # ── Depth cache ──────────────────────────────────────────────────────

    def get_depth_cached(self) -> dict:
        now = time.time()
        if self._depth_cache and (now - self._depth_cache_ts) < self.cfg.DEPTH_CACHE_SEC:
            return self._depth_cache
        fresh = self.get("/fapi/v1/depth", {"symbol": self.cfg.SYMBOL, "limit": int(self.cfg.DEPTH_LIMIT)})
        if isinstance(fresh, dict):
            self._depth_cache = fresh
            self._depth_cache_ts = now
        return self._depth_cache or {}

    def invalidate_depth_cache(self) -> None:
        self._depth_cache = None
        self._depth_cache_ts = 0.0

    # ── Account ──────────────────────────────────────────────────────────

    def get_account_cached(self, auth_ok: bool, force: bool = False) -> dict:
        if self.cfg.SIMULATION_MODE or (not auth_ok):
            return {}
        now = time.time()
        if (not force) and self._acct_cache and (now - self._acct_cache_ts) < self.cfg.ACCOUNT_CACHE_SEC:
            return self._acct_cache
        fresh = self._fetch_account_raw()
        if fresh:
            self._acct_cache = fresh
            self._acct_cache_ts = now
        return self._acct_cache or {}

    def _fetch_account_raw(self) -> dict:
        # v2 works on both Aster and Binance; try v3 as fallback (Binance-only)
        acct = self.signed("GET", "/fapi/v2/account", {})
        if not isinstance(acct, dict) or acct.get("_auth_401") or acct.get("code"):
            acct = self.signed("GET", "/fapi/v3/account", {})
        if not isinstance(acct, dict) or acct.get("_auth_401"):
            return {}

        def pick(*keys: str) -> Optional[Decimal]:
            for k in keys:
                if k in acct:
                    try:
                        return d(acct[k])
                    except Exception:
                        return None
            return None

        wallet = pick("totalWalletBalance", "walletBalance")
        avail = pick("availableBalance", "availableBalanceUSDT", "totalAvailableBalance")
        margin = pick("totalMarginBalance", "marginBalance")
        unreal = pick("totalUnrealizedProfit", "unrealizedProfit")

        out: Dict[str, Decimal] = {}
        if wallet is not None: out["wallet_usdt"] = wallet
        if avail is not None: out["avail_usdt"] = avail
        if margin is not None: out["margin_balance"] = margin
        if unreal is not None: out["unrealized"] = unreal

        if "margin_balance" in out and "avail_usdt" in out:
            used = out["margin_balance"] - out["avail_usdt"]
            out["margin_used"] = max(D0, used)

        return out

    # ── Positions ────────────────────────────────────────────────────────

    def get_position(self, auth_ok: bool) -> Optional[dict]:
        if self.cfg.SIMULATION_MODE or (not auth_ok):
            return None
        # v2 works on both Aster and Binance; v3 is Binance-only, v1 is legacy fallback
        pos = self.signed("GET", "/fapi/v2/positionRisk", {})
        if isinstance(pos, dict) and pos.get("_auth_401"):
            return None
        items: List[dict] = []
        if isinstance(pos, list):
            items = pos
        else:
            pos2 = self.signed("GET", "/fapi/v3/positionRisk", {})
            if isinstance(pos2, dict) and pos2.get("_auth_401"):
                return None
            if isinstance(pos2, list):
                items = pos2
            else:
                pos3 = self.signed("GET", "/fapi/v1/positionRisk", {})
                if isinstance(pos3, dict) and pos3.get("_auth_401"):
                    return None
                if isinstance(pos3, list):
                    items = pos3
        if not items:
            return {"amt": D0, "entry": D0, "side": None}
        for it in items:
            if str(it.get("symbol", "")) != self.cfg.SYMBOL:
                continue
            try:
                amt = d(it.get("positionAmt", "0"))
                entry = d(it.get("entryPrice", "0"))
            except Exception:
                amt, entry = D0, D0
            if abs(amt) <= self.cfg.RECONCILE_MIN_QTY_EPS:
                return {"amt": D0, "entry": entry, "side": None}
            side = "LONG" if amt > 0 else "SHORT"
            return {"amt": abs(amt), "entry": entry, "side": side}
        return {"amt": D0, "entry": D0, "side": None}

    def cancel_all_open_orders(self, auth_ok: bool) -> bool:
        if self.cfg.SIMULATION_MODE or (not auth_ok):
            return True
        r = self.signed("DELETE", "/fapi/v1/allOpenOrders", {"symbol": self.cfg.SYMBOL})
        if isinstance(r, dict) and r.get("_auth_401"):
            return False
        return bool(r)

    def get_funding_rate(self) -> Decimal:
        if self.cfg.SIMULATION_MODE:
            return Decimal("0.00005")
        dct = self.get("/fapi/v1/premiumIndex", {"symbol": self.cfg.SYMBOL})
        if isinstance(dct, dict):
            try:
                fr = dct.get("lastFundingRate", None)
                if fr is not None:
                    return d(fr)
            except Exception:
                pass
        return D0


# ── Helpers ──────────────────────────────────────────────────────────────────

def is_sig_error(resp: Any) -> bool:
    try:
        if isinstance(resp, dict):
            code = int(resp.get("code", 0))
            msg = str(resp.get("msg", "")).lower()
            return (code == -1022) or ("signature" in msg and "not valid" in msg)
    except Exception:
        pass
    return False
