"""Order placement: limit, IOC, maker loops, fill tracking."""

from __future__ import annotations

import logging
import time
from decimal import Decimal
from typing import Dict, Optional, Tuple

from core.helpers import D0, D1, d, round_step, qty_str, px_str, utc_ts, append_jsonl
from core.config import Config
from core.types import SymbolFilters
from exchange.client import ExchangeClient

LOG = logging.getLogger("aster")


# ── Single order ─────────────────────────────────────────────────────────────

def place_limit(
    cfg: Config, client: ExchangeClient, filt: SymbolFilters, auth_ok: bool,
    side: str, quantity: Decimal, price: Decimal, reduce_only: bool, tif: str
) -> Optional[dict]:
    if cfg.SIMULATION_MODE:
        return {
            "sim": True, "orderId": "SIM", "status": "FILLED",
            "avgPrice": str(price), "executedQty": str(quantity), "origQty": str(quantity),
        }
    if not auth_ok:
        return {"_auth_block": True}

    q = round_step(quantity, filt.qty_step)
    if q <= 0:
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "ORDER_SKIP_QTY", "qty": str(quantity)})
        return None
    px = round_step(price, filt.price_tick)
    if px <= 0:
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "ORDER_SKIP_PX", "px": str(price)})
        return None

    params: Dict[str, str] = {
        "symbol": cfg.SYMBOL, "side": side, "type": "LIMIT",
        "timeInForce": tif, "quantity": qty_str(q), "price": px_str(px),
    }
    if reduce_only:
        params["reduceOnly"] = "true"

    resp = client.signed("POST", "/fapi/v1/order", params)

    if isinstance(resp, dict) and "orderId" not in resp:
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {
            "ts": utc_ts(), "event": "ORDER_REJECT", "tif": tif,
            "side": side, "reduce_only": bool(reduce_only),
            "qty": params.get("quantity"), "price": params.get("price"),
            "resp": str(resp),
        })

    return resp


def get_order_info(cfg: Config, client: ExchangeClient, auth_ok: bool, order_id: str) -> Optional[dict]:
    if cfg.SIMULATION_MODE or (not auth_ok):
        return None
    info = client.signed("GET", "/fapi/v1/order", {"symbol": cfg.SYMBOL, "orderId": str(order_id)})
    if isinstance(info, dict) and info.get("_auth_401"):
        return None
    return info if isinstance(info, dict) else None


def cancel_order(cfg: Config, client: ExchangeClient, auth_ok: bool, order_id: str) -> bool:
    if cfg.SIMULATION_MODE:
        return True
    if not auth_ok:
        return False
    r = client.signed("DELETE", "/fapi/v1/order", {"symbol": cfg.SYMBOL, "orderId": str(order_id)})
    if isinstance(r, dict) and r.get("_auth_401"):
        return False
    return bool(r)


# ── Fill helpers ─────────────────────────────────────────────────────────────

def order_exec_qty(info: dict) -> Decimal:
    try:
        return d(info.get("executedQty", "0"))
    except Exception:
        return D0


def order_fill_price(info: dict) -> Optional[Decimal]:
    ap = info.get("avgPrice")
    if ap not in (None, "", "0", 0):
        try:
            px = d(ap)
            if px > 0:
                return px
        except Exception:
            pass
    try:
        eq = d(info.get("executedQty", "0"))
        cq = d(info.get("cummulativeQuoteQty", "0"))
        if eq > 0 and cq > 0:
            return cq / eq
    except Exception:
        pass
    return None


def wait_for_fill_or_timeout(
    cfg: Config, client: ExchangeClient, auth_ok: bool,
    order_id: str, life_sec: float
) -> Tuple[str, Decimal, Optional[Decimal], dict]:
    if cfg.SIMULATION_MODE:
        return "FILLED", D1, None, {"status": "FILLED", "executedQty": "1", "origQty": "1", "avgPrice": "0"}
    t0 = time.time()
    last: dict = {}
    last_exq = D0

    while time.time() - t0 <= float(life_sec):
        info = get_order_info(cfg, client, auth_ok, order_id)
        if info:
            last = info
            stt = str(info.get("status", ""))
            exq = order_exec_qty(info)
            avgp = order_fill_price(info)
            if stt == "FILLED":
                return "FILLED", exq, avgp, info
            if stt in ("CANCELED", "REJECTED", "EXPIRED"):
                return stt, exq, avgp, info
            if exq > last_exq:
                last_exq = exq
        time.sleep(0.12)

    info2 = get_order_info(cfg, client, auth_ok, order_id) or last or {}
    exq2 = order_exec_qty(info2) if info2 else D0
    avgp2 = order_fill_price(info2) if info2 else None
    stt2 = str(info2.get("status", "")) if info2 else ""

    if exq2 > 0 and stt2 not in ("FILLED", "CANCELED", "REJECTED", "EXPIRED"):
        return "PARTIALLY_FILLED", exq2, avgp2, info2
    return "TIMEOUT", exq2, avgp2, info2


def vwap_add(sum_px_qty: Decimal, sum_qty: Decimal, px: Optional[Decimal], qty: Decimal) -> Tuple[Decimal, Decimal]:
    if px is None or qty <= 0:
        return sum_px_qty, sum_qty
    return (sum_px_qty + (px * qty), sum_qty + qty)


# ── Price helpers ────────────────────────────────────────────────────────────

def maker_entry_px(side: str, best_bid: Decimal, best_ask: Decimal) -> Decimal:
    return best_bid if side == "BUY" else best_ask


def maker_exit_px(filt: SymbolFilters, pos: str, best_bid: Decimal, best_ask: Decimal) -> Tuple[str, Decimal]:
    tick = filt.price_tick
    max_off = tick * 2
    if best_ask <= best_bid:
        best_ask = best_bid + tick
    if pos == "LONG":
        px = best_ask
        px = max(best_ask - max_off, min(px, best_ask + max_off))
        return "SELL", px
    px = best_bid
    px = max(best_bid - max_off, min(px, best_bid + max_off))
    return "BUY", px


# ── Composite: maker loop ────────────────────────────────────────────────────

def place_maker_full(
    cfg: Config, client: ExchangeClient, filt: SymbolFilters, auth_ok: bool,
    side: str, qty_target: Decimal, px: Decimal, reduce_only: bool,
    life_sec: float, total_budget_sec: float
) -> Tuple[Decimal, Optional[Decimal], str]:

    if qty_target <= 0:
        return D0, None, "NO_QTY"
    if cfg.SIMULATION_MODE:
        return qty_target, px, "SIM_MAKER"
    if not auth_ok:
        return D0, None, "AUTH_BLOCK"

    t0 = time.time()
    remaining = round_step(qty_target, filt.qty_step)
    filled_total = D0
    sum_px_qty = D0
    sum_qty = D0
    last_status = "INIT"

    while remaining >= filt.min_qty and (time.time() - t0) <= float(total_budget_sec):
        resp = place_limit(cfg, client, filt, auth_ok, side, remaining, px, reduce_only=reduce_only, tif="GTX")

        if not resp or "orderId" not in resp:
            if isinstance(resp, dict) and resp.get("_auth_block"):
                return filled_total, (sum_px_qty / sum_qty) if sum_qty > 0 else None, "AUTH_BLOCK"
            last_status = "NO_ORDERID"
            break

        oid = str(resp["orderId"])
        stt, exq, avgp, info = wait_for_fill_or_timeout(cfg, client, auth_ok, oid, life_sec)
        last_status = stt

        # Always cancel non-filled maker orders
        if stt != "FILLED":
            _ = cancel_order(cfg, client, auth_ok, oid)

        if exq > 0:
            filled_total += exq
            use_px = avgp if avgp is not None else px
            sum_px_qty, sum_qty = vwap_add(sum_px_qty, sum_qty, use_px, exq)
            remaining = round_step(max(D0, qty_target - filled_total), filt.qty_step)
            append_jsonl(cfg.CENTRAL_LOG_JSONL, {
                "ts": utc_ts(), "event": "PARTIAL_FILL",
                "side": side, "reduce_only": bool(reduce_only),
                "status": stt, "exq": str(exq), "filled_total": str(filled_total),
                "remaining": str(remaining),
            })

        if remaining <= 0:
            break
        time.sleep(0.05)

    vwap = (sum_px_qty / sum_qty) if sum_qty > 0 else None
    if filled_total >= round_step(qty_target, filt.qty_step) and filled_total > 0:
        return filled_total, vwap, "FILLED_FULL"
    if filled_total > 0:
        return filled_total, vwap, f"PARTIAL({last_status})"
    return D0, None, f"NOFILL({last_status})"


# ── Composite: IOC ───────────────────────────────────────────────────────────

def place_ioc(
    cfg: Config, client: ExchangeClient, filt: SymbolFilters, auth_ok: bool,
    side: str, qty_target: Decimal, best_bid: Decimal, best_ask: Decimal,
    reduce_only: bool, slippage_ticks: int
) -> Tuple[Decimal, Optional[Decimal], str]:
    if qty_target <= 0:
        return D0, None, "NO_QTY"
    if cfg.SIMULATION_MODE:
        px = best_ask if side == "BUY" else best_bid
        return qty_target, px, "SIM_IOC"
    if not auth_ok:
        return D0, None, "AUTH_BLOCK"

    slip = filt.price_tick * slippage_ticks
    px = (best_ask + slip) if side == "BUY" else (best_bid - slip)
    resp = place_limit(cfg, client, filt, auth_ok, side, qty_target, px, reduce_only=reduce_only, tif="IOC")
    if not resp or "orderId" not in resp:
        if isinstance(resp, dict) and resp.get("_auth_block"):
            return D0, None, "AUTH_BLOCK"
        return D0, None, "NO_ORDERID"
    oid = str(resp["orderId"])
    stt, exq, avgp, _ = wait_for_fill_or_timeout(cfg, client, auth_ok, oid, cfg.HARDSTOP_IOC_LIFE_SEC)
    if stt in ("TIMEOUT", "NEW"):
        _ = cancel_order(cfg, client, auth_ok, oid)
    if exq > 0:
        return exq, avgp if avgp is not None else px, f"IOC_EXEC({stt})"
    return D0, None, f"IOC_NOFILL({stt})"
