"""Risk management: TP/SL, trailing, position sizing.

UPGRADE GUIDE: Modify take-profit / stop-loss logic, trailing
behavior, or sizing formulas here. Won't touch signals or orders.
"""

from __future__ import annotations

import time
import logging
from decimal import Decimal
from typing import Tuple

from core.helpers import D0, d, clamp, utc_ts, append_jsonl
from core.config import Config
from core.state import BotState
from core.types import Snapshot, SymbolFilters
from exchange.market import estimate_costs

LOG = logging.getLogger("aster")


# ── Sizing ───────────────────────────────────────────────────────────────────

def compute_target_notional(cfg: Config, available_usdt: Decimal, lev_eff: int) -> Decimal:
    lev_used = max(1, int(lev_eff))
    lev_dec = Decimal(str(lev_used))

    if cfg.USE_MARGIN_TARGET:
        base_notional = cfg.TARGET_MARGIN_USDT * lev_dec
    else:
        base_notional = cfg.TARGET_NOTIONAL_USDT

    want = base_notional
    if available_usdt > 0:
        max_margin = available_usdt * cfg.MAX_MARGIN_FRACTION_OF_AVAILABLE
        want = min(want, max_margin * lev_dec)

    return max(want * cfg.NOTIONAL_SAFETY_MULT, D0)


def calc_qty(cfg: Config, filt: SymbolFilters, mid: Decimal, available_usdt: Decimal, lev_eff: int) -> Tuple[Decimal, Decimal]:
    if mid <= 0:
        return D0, D0
    from core.helpers import round_step
    notional = compute_target_notional(cfg, available_usdt, lev_eff)
    q = round_step(notional / mid, filt.qty_step)
    if q < filt.min_qty:
        return D0, D0
    return q, q * mid


# ── TP / SL ──────────────────────────────────────────────────────────────────

def fixed_tp_sl(cfg: Config) -> Tuple[Decimal, Decimal]:
    tp = cfg.TP_USD_FIXED if cfg.TP_USD_FIXED > 0 else cfg.TP_USD_FLOOR
    sl = cfg.SL_USD_FIXED if cfg.SL_USD_FIXED > 0 else cfg.SL_USD_FLOOR
    return max(D0, tp), max(D0, sl)


def decide_tp_sl(cfg: Config, atr_price: Decimal, qty: Decimal, est_cost: Decimal) -> Tuple[Decimal, Decimal]:
    if cfg.ENFORCE_CONFIG_TPSL:
        return fixed_tp_sl(cfg)
    atr_usd = max(atr_price, cfg.ATR_MIN_PRICE) * qty
    tp = max(cfg.TP_USD_FLOOR, atr_usd * cfg.TP_ATR_MULT, est_cost * Decimal("1.30"))
    sl = max(cfg.SL_USD_FLOOR, atr_usd * cfg.SL_ATR_MULT)
    return tp, sl


# ── Trailing ─────────────────────────────────────────────────────────────────

def update_trailing(cfg: Config, st: BotState, snap: Snapshot, unreal: Decimal) -> None:
    if unreal > st.peak_unreal:
        st.peak_unreal = unreal
    if st.tp_usd <= 0 or st.is_flat():
        return
    if not st.tp_touched:
        return

    atr_usd = max(snap.atr_price, cfg.ATR_MIN_PRICE) * max(st.qty, D0)
    gap = clamp(atr_usd * cfg.TRAIL_ATR_GAP_MULT, Decimal("0.75"), Decimal("12.0"))
    be = st.entry_est_cost * cfg.BE_LOCK_COST_MULT
    st.trail_usd = max(st.trail_usd, max(be, st.peak_unreal - gap))


# ── Dynamic TP/SL refresh ───────────────────────────────────────────────────

def refresh_dynamic_tp_sl(cfg: Config, st: BotState, snap: Snapshot) -> None:
    if cfg.ENFORCE_CONFIG_TPSL:
        return
    if (not cfg.DYN_TPSL_ENABLE) or st.is_flat() or st.qty <= 0:
        return
    now = time.time()
    if (now - st.entry_time) < float(cfg.DYN_REQUIRE_HELD_SEC):
        return
    if st.last_tpsl_refresh and (now - st.last_tpsl_refresh) < float(cfg.DYN_TPSL_REFRESH_SEC):
        return
    st.last_tpsl_refresh = now

    base_tp, base_sl = decide_tp_sl(cfg, snap.atr_price, st.qty, st.entry_est_cost)

    if st.tp_init <= 0 and st.tp_usd > 0:
        st.tp_init = st.tp_usd
    if st.sl_init <= 0 and st.sl_usd > 0:
        st.sl_init = st.sl_usd

    if st.tp_usd <= 0 or st.sl_usd <= 0:
        st.tp_usd = base_tp
        st.sl_usd = base_sl
        st.tp_init = max(st.tp_init, st.tp_usd)
        st.sl_init = max(st.sl_init, st.sl_usd)
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {"ts": utc_ts(), "event": "DYN_TPSL_SEED", "tp": str(st.tp_usd), "sl": str(st.sl_usd)})
        return

    tp_cap = (st.tp_init if st.tp_init > 0 else st.tp_usd) * cfg.DYN_TP_WIDEN_MAX_MULT
    sl_floor = (st.sl_init if st.sl_init > 0 else st.sl_usd) * cfg.DYN_SL_MIN_TIGHTEN_MULT
    old_tp, old_sl = st.tp_usd, st.sl_usd

    desired_tp = min(tp_cap, max(st.tp_usd, base_tp))
    if desired_tp - st.tp_usd >= cfg.DYN_TP_WIDEN_MIN_STEP_USD:
        st.tp_usd = desired_tp

    desired_sl = max(sl_floor, min(st.sl_usd, base_sl))
    if st.sl_usd - desired_sl >= cfg.DYN_SL_TIGHTEN_MIN_STEP_USD:
        st.sl_usd = desired_sl

    if st.tp_usd != old_tp or st.sl_usd != old_sl:
        append_jsonl(cfg.CENTRAL_LOG_JSONL, {
            "ts": utc_ts(), "event": "DYN_TPSL_UPDATE",
            "tp_old": str(old_tp), "tp_new": str(st.tp_usd),
            "sl_old": str(old_sl), "sl_new": str(st.sl_usd),
        })
        LOG.info("DYN TP/SL: TP %s->%s | SL %s->%s", old_tp, st.tp_usd, old_sl, st.sl_usd)
