"""Entry decision logic: action selection and confirmation."""

from __future__ import annotations

from typing import Optional, Tuple

from core.helpers import log1p_pos
from core.config import Config
from core.state import BotState
from core.types import Snapshot
from learning.model import OnlineLogReg

from decimal import Decimal


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def _quality_score(cfg: Config, snap: Snapshot, vol_med: Decimal) -> float:
    spread_score = 1.0 - min(1.0, float(snap.spread_bps / max(Decimal('0.50'), cfg.MAX_SPREAD_BPS)))
    wall_score = min(1.0, float(snap.wall_total / max(Decimal('1'), cfg.MIN_WALL_TOTAL * Decimal('1.40'))))
    vol_ref = max(Decimal('0.50'), vol_med * cfg.VOL_EXPAND_MULT, cfg.MIN_VOL_BPS)
    vol_score = min(1.0, float(snap.vol_bps / vol_ref)) if vol_ref > 0 else 0.5
    signal_score = min(1.0, abs(float(snap.ofi)) / max(0.03, float(cfg.HEUR_OFI_MIN * Decimal('1.5'))))
    return _clamp01((spread_score * 0.30) + (wall_score * 0.25) + (vol_score * 0.25) + (signal_score * 0.20))


def _heuristic_direction(cfg: Config, snap: Snapshot) -> Tuple[Optional[str], float]:
    long_ok = (snap.ofi >= cfg.HEUR_OFI_MIN and snap.slope >= cfg.HEUR_SLOPE_MIN and snap.mid > snap.ma)
    short_ok = (snap.ofi <= -cfg.HEUR_OFI_MIN and snap.slope <= -cfg.HEUR_SLOPE_MIN and snap.mid < snap.ma)
    if long_ok and not short_ok:
        return 'LONG', 0.72
    if short_ok and not long_ok:
        return 'SHORT', 0.28
    return None, 0.50


def pick_action(cfg: Config, model: OnlineLogReg, snap: Snapshot, vol_med: Decimal) -> Tuple[Optional[str], float, str]:
    if snap.ma is None:
        return None, 0.5, "NO_MA"
    ma_gap_bps = float(((snap.mid - snap.ma) / snap.mid) * Decimal('10000')) if snap.mid > 0 else 0.0
    raw = {
        "ofi": float(snap.ofi),
        "ofi_prev": 0.0,
        "slope": float(snap.slope),
        "vol_bps": float(snap.vol_bps),
        "vol_med": float(vol_med),
        "spread_bps": float(snap.spread_bps),
        "wall_log": float(log1p_pos(snap.wall_total)),
        "ma_gap_bps": ma_gap_bps,
    }
    p_up_model = model.predict_proba(raw)
    if snap.spread_bps > cfg.MAX_SPREAD_BPS:
        return None, p_up_model, "SPREAD"
    if snap.wall_total < cfg.MIN_WALL_TOTAL:
        return None, p_up_model, "WALLS"
    if snap.vol_bps < cfg.MIN_VOL_BPS or snap.vol_bps > cfg.MAX_VOL_BPS:
        return None, p_up_model, "VOL_RANGE"
    if vol_med > 0 and snap.vol_bps < (vol_med * cfg.VOL_EXPAND_MULT):
        return None, p_up_model, "NO_VOL_EXPAND"
    q = _quality_score(cfg, snap, vol_med)
    if q < float(getattr(cfg, 'ENTRY_QUALITY_MIN', 0.46)):
        return None, p_up_model, 'LOW_QUALITY'
    heur_action, heur_prob = _heuristic_direction(cfg, snap)
    slope_bias = 0.5 + max(-0.10, min(0.10, float(snap.slope) * 0.035))
    flow_bias = 0.5 + max(-0.08, min(0.08, float(snap.ofi) * 0.30))
    structure_prob = _clamp01((slope_bias + flow_bias) * 0.5)
    if model.trained_examples >= cfg.MIN_MODEL_EXAMPLES_TO_TRUST:
        p_up = _clamp01((p_up_model * 0.60) + (heur_prob * 0.25) + (structure_prob * 0.15))
        conf = abs(p_up - 0.5)
        if conf >= cfg.MODEL_MIN_CONF:
            if p_up >= cfg.MODEL_LONG_TH:
                return 'LONG', p_up, 'MODEL_BLEND'
            if p_up <= cfg.MODEL_SHORT_TH:
                return 'SHORT', p_up, 'MODEL_BLEND'
            return None, p_up, 'MODEL_MID'
    if heur_action == 'LONG':
        return 'LONG', _clamp01((heur_prob * 0.70) + (structure_prob * 0.30)), 'HEUR'
    if heur_action == 'SHORT':
        return 'SHORT', _clamp01((heur_prob * 0.70) + (structure_prob * 0.30)), 'HEUR'
    return None, p_up_model, 'HEUR_NONE'


def confirm_action(cfg: Config, st: BotState, action: Optional[str]) -> bool:
    if action is None:
        st.confirm_streak_long = 0
        st.confirm_streak_short = 0
        return False
    if action == "LONG":
        st.confirm_streak_long += 1
        st.confirm_streak_short = 0
        return st.confirm_streak_long >= cfg.ENTRY_CONFIRM_TICKS
    st.confirm_streak_short += 1
    st.confirm_streak_long = 0
    return st.confirm_streak_short >= cfg.ENTRY_CONFIRM_TICKS
