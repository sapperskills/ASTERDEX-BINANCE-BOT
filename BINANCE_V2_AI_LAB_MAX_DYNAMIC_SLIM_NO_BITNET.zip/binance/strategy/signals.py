"""Signal computations: MA, slope, ATR, micro-vol.

UPGRADE GUIDE: Add new indicators here. They feed into Snapshot
and decision.py. No order logic here — pure signal math.
"""

from __future__ import annotations

from collections import deque
from decimal import Decimal
from typing import Deque, Optional

from core.helpers import D0, d
from core.config import Config
from exchange.market import RollingMinMax


def compute_ma(price_buf: Deque[Decimal], ma_length: int) -> Optional[Decimal]:
    if len(price_buf) < ma_length:
        return None
    return sum(price_buf) / d(ma_length)


def ma_slope_dir(ma_hist: Deque[Decimal], ma_slope_len: int) -> int:
    if len(ma_hist) < ma_slope_len:
        return 0
    if ma_hist[-1] > ma_hist[0]:
        return 1
    if ma_hist[-1] < ma_hist[0]:
        return -1
    return 0


def atr_update(tr_buf: Deque[Decimal], prev_mid: Optional[Decimal], mid: Decimal) -> None:
    if prev_mid is None or prev_mid <= 0 or mid <= 0:
        return
    tr_buf.append(abs(mid - prev_mid))


def atr_value(cfg: Config, tr_buf: Deque[Decimal], price_mm: RollingMinMax) -> Decimal:
    if len(tr_buf) < max(6, cfg.ATR_LEN // 3):
        return cfg.ATR_MIN_PRICE
    atr_tick = sum(tr_buf) / d(len(tr_buf))
    rng = price_mm.max - price_mm.min
    atr_rng = (rng / Decimal("4")) if rng > 0 else D0
    return max(atr_tick, atr_rng, cfg.ATR_MIN_PRICE)


def micro_vol_bps(price_mm: RollingMinMax, mid: Decimal, need_len: int) -> Decimal:
    if len(price_mm) < need_len or mid <= 0:
        return D0
    rng = price_mm.max - price_mm.min
    if rng <= 0:
        return D0
    return (rng / mid) * Decimal("10000")


def vol_median(vol_hist: Deque[Decimal]) -> Decimal:
    if not vol_hist:
        return D0
    xs = sorted(vol_hist)
    return xs[len(xs) // 2]
