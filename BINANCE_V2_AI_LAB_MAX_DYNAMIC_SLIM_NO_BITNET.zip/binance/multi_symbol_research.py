#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from research import run_research_engine


def main() -> None:
    parser = argparse.ArgumentParser(description="Multi-symbol strategy research engine (Aster / Binance)")
    parser.add_argument("--interval", default="5m", help="Kline interval, e.g. 1m, 5m, 15m, 1h")
    parser.add_argument("--limit", type=int, default=288, help="Klines per symbol")
    parser.add_argument("--top", type=int, default=25, help="Top symbols to keep in patch outputs")
    parser.add_argument("--out", default="research_output", help="Output directory")
    parser.add_argument("--symbols", default="", help="Optional comma-separated symbol allowlist")
    parser.add_argument("--base-url", default="https://fapi.asterdex.com",
                        help="Public API base URL (asterdex.com or binance.com)")
    args = parser.parse_args()

    symbols = [s.strip().upper() for s in args.symbols.split(",") if s.strip()] or None
    result = run_research_engine(
        out_dir=args.out,
        interval=args.interval,
        kline_limit=args.limit,
        top_n=args.top,
        symbols=symbols,
        base_url=args.base_url,
    )
    print(json.dumps(result, indent=2))
    print(f"\nWrote outputs to: {Path(args.out).resolve()}")


if __name__ == "__main__":
    main()
