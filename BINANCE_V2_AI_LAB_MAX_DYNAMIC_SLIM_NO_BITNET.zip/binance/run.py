#!/usr/bin/env python3
"""
ASTER Simple Edge v3.0 — Single Symbol Mode (backward compatible)

For multi-symbol mode, use run_unified.py instead.

Usage:
    python run.py                    # uses config.json in current dir
    python run.py /path/to/config.json
"""
# This is the original run.py preserved for backward compatibility.
# Import and re-export from the original location.

from __future__ import annotations

import logging
import sys
import time
import traceback
from collections import deque
from datetime import datetime
from decimal import Decimal, getcontext
from typing import Deque, Optional

getcontext().prec = 28

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(message)s",
    datefmt="%m-%d %H:%M:%S",
)
LOG = logging.getLogger("aster")

from core.helpers import D0, d, clamp, utc_ts, append_jsonl, file_exists, log1p_pos
from core.config import Config, load_config_json, per_symbol_paths
from core.state import BotState, state_load, state_save, rolling_wr
from core.types import (
    SymbolFilters, Snapshot,
    load_symbol_profile, apply_profile_to_cfg,
)
from exchange.client import ExchangeClient, is_sig_error
from exchange.market import (
    get_price, get_walls, spread_bps, order_flow_imbalance, RollingMinMax,
)
from exchange.orders import place_limit
from strategy.signals import compute_ma, ma_slope_dir, atr_update, atr_value, micro_vol_bps, vol_median
from strategy.risk import decide_tp_sl
from execution.entry import try_entry
from execution.exit_ import try_exit
from learning.model import OnlineLogReg
from learning.learner import Learner
from utils.reconcile import reconcile_with_exchange, boot_adopt_exchange_position
from utils.calibration import calibrate_symbol_profile


def load_symbol_info(cfg: Config, client: ExchangeClient, filt: SymbolFilters) -> None:
    info = client.get("/fapi/v1/exchangeInfo")
    if not info or "symbols" not in info:
        LOG.warning("exchangeInfo failed — using defaults")
        return
    for s in info["symbols"]:
        if s.get("symbol") != cfg.SYMBOL:
            continue
        for f_ in s.get("filters", []):
            if f_.get("filterType") == "LOT_SIZE":
                try:
                    filt.min_qty = d(f_["minQty"])
                    filt.qty_step = d(f_["stepSize"])
                except Exception:
                    pass
            if f_.get("filterType") in ("PRICE_FILTER", "PRICE"):
                try:
                    tick = f_.get("tickSize")
                    if tick:
                        filt.price_tick = d(tick)
                except Exception:
                    pass
        LOG.info("%s filters: minQty=%s step=%s tick=%s", cfg.SYMBOL, filt.min_qty, filt.qty_step, filt.price_tick)
        return


def set_leverage_live(cfg: Config, client: ExchangeClient, auth_ok: bool) -> bool:
    if cfg.SIMULATION_MODE or (not auth_ok):
        return True
    for attempt in range(3):
        r = client.signed("POST", "/fapi/v1/leverage", {"symbol": cfg.SYMBOL, "leverage": str(cfg.LEVERAGE)})
        if isinstance(r, dict) and r.get("_auth_401"):
            LOG.error("AUTH ERROR: leverage blocked (401)")
            return False
        if is_sig_error(r):
            LOG.warning("LEVERAGE SIG ERROR. Resyncing time attempt=%s", attempt + 1)
            client.sync_time()
            time.sleep(0.25 + 0.20 * attempt)
            continue
        if isinstance(r, dict) and ("leverage" in r or "symbol" in r):
            LOG.info("LEVERAGE SET OK: %s", r)
            return True
        if r:
            LOG.warning("LEVERAGE SET FAILED: %s", r)
            return False
    LOG.error("LEVERAGE SET FAILED after retries.")
    return False


def main() -> None:
    cfg = Config()
    config_path = sys.argv[1] if len(sys.argv) > 1 else "config.json"
    load_config_json(cfg, config_path)
    per_symbol_paths(cfg)

    if cfg.ENFORCE_CONFIG_TPSL:
        cfg.DYN_TPSL_ENABLE = False

    LOG.info("UNIFIED v3.0 [%s] — symbol=%s TP=%s SL=%s confirm=%s MA=%s slope=%s OFI=%s",
             cfg.EXCHANGE.upper() or "?", cfg.SYMBOL,
             (cfg.TP_USD_FIXED if cfg.TP_USD_FIXED > 0 else cfg.TP_USD_FLOOR),
             (cfg.SL_USD_FIXED if cfg.SL_USD_FIXED > 0 else cfg.SL_USD_FLOOR),
             cfg.ENTRY_CONFIRM_TICKS, cfg.MA_LENGTH, cfg.MA_SLOPE_LEN, cfg.HEUR_OFI_MIN)

    AUTH_OK = True
    if not cfg.SIMULATION_MODE and (not cfg.API_KEY or not cfg.API_SECRET):
        raise SystemExit("LIVE MODE requires API_KEY and API_SECRET in config.json.")

    client = ExchangeClient(cfg)
    client.sync_time()

    filt = SymbolFilters()
    load_symbol_info(cfg, client, filt)

    prof = load_symbol_profile(cfg)
    if prof:
        apply_profile_to_cfg(cfg, prof)
        LOG.info("PROFILE LOAD: gates: spread<=%s wall>=%s vol>=%s band=%s",
                 cfg.MAX_SPREAD_BPS, cfg.MIN_WALL_TOTAL, cfg.MIN_VOL_BPS, cfg.WALL_BAND_BPS_DEFAULT)
    if (not prof) and cfg.CALIB_ENABLE:
        calibrate_symbol_profile(cfg, client, filt)

    if not cfg.SIMULATION_MODE:
        ok = set_leverage_live(cfg, client, AUTH_OK)
        if not ok:
            AUTH_OK = False
            LOG.warning("AUTH/LEV FAILED -> AUTH_OK False.")

    model = OnlineLogReg(cfg)
    if model.load():
        LOG.info("Model loaded: %s examples", model.trained_examples)
    else:
        model.maybe_save(force=True)

    learner = Learner(cfg, model)

    st = state_load(cfg) or BotState(current_day=str(datetime.utcnow().date()))
    price_buf: Deque[Decimal] = deque(maxlen=cfg.MA_LENGTH)
    price_mm = RollingMinMax(maxlen=cfg.MA_LENGTH)
    ma_hist: Deque[Decimal] = deque(maxlen=cfg.MA_SLOPE_LEN)
    tr_buf: Deque[Decimal] = deque(maxlen=cfg.ATR_LEN)
    vol_hist: Deque[Decimal] = deque(maxlen=cfg.VOL_ROLL_LEN)

    LOG.info("Warming up...")
    for _ in range(180):
        mid = get_price(cfg, client)
        if mid > 0:
            price_mm.push(mid)
            price_buf.append(mid)
            atr_update(tr_buf, st.prev_mid, mid)
            st.prev_mid = mid
        time.sleep(0.20 if cfg.LIVE_PROFILE else 0.28)
    LOG.info("WARMUP COMPLETE")

    boot_adopt_exchange_position(cfg, client, filt, st, AUTH_OK, price_mm, price_buf, ma_hist, tr_buf, vol_hist)
    state_save(cfg, st)

    last_heartbeat = 0.0
    last_state_flush = 0.0

    def flush_state(force: bool = False) -> None:
        nonlocal last_state_flush
        now = time.time()
        if (not force) and (now - last_state_flush) < 2.0:
            return
        last_state_flush = now
        state_save(cfg, st)
        model.maybe_save(force=False)

    while True:
        try:
            if file_exists(cfg.KILL_SWITCH_FILE):
                LOG.warning("KILL SWITCH -> stopping.")
                flush_state(force=True)
                raise SystemExit("Killed by KILL.txt")

            now_dt = datetime.utcnow()
            if str(now_dt.date()) != str(st.current_day):
                LOG.info("NEW DAY: prev_pnl=%+.2f WR=%.0f%%", st.realized_day_pnl, float(rolling_wr(st.trade_outcomes) * 100))
                st.current_day = str(now_dt.date())
                st.realized_day_pnl = D0
                st.loss_streak = 0

            acct = client.get_account_cached(AUTH_OK)
            if acct:
                try:
                    w = d(acct.get("wallet_usdt", "0"))
                    if w > 0:
                        st.peak_wallet_usdt = max(st.peak_wallet_usdt, w)
                except Exception:
                    pass

            if time.time() - last_heartbeat >= cfg.HEARTBEAT_SEC:
                last_heartbeat = time.time()
                wr = float(rolling_wr(st.trade_outcomes) * 100)
                LOG.info("HEARTBEAT: pos=%s WR=%.0f%% model=%s gates: wall>=%s spread<=%s vol>=%s band=%s",
                         st.position or "FLAT", wr, model.trained_examples,
                         cfg.MIN_WALL_TOTAL, cfg.MAX_SPREAD_BPS, cfg.MIN_VOL_BPS, cfg.WALL_BAND_BPS_DEFAULT)

            if st.realized_day_pnl <= -cfg.MAX_DAILY_LOSS_USD:
                st.next_entry_time = max(st.next_entry_time, time.time() + 900.0)
            if st.loss_streak >= cfg.MAX_CONSEC_LOSSES:
                st.next_entry_time = max(st.next_entry_time, time.time() + 1200.0)

            mid = get_price(cfg, client)
            if mid <= 0:
                time.sleep(cfg.LOOP_SLEEP)
                continue

            depth = client.get_depth_cached()
            if not depth or not depth.get("bids") or not depth.get("asks"):
                time.sleep(cfg.LOOP_SLEEP)
                continue

            st.ofi_prev = float(st.ofi_ema)

            price_mm.push(mid)
            price_buf.append(mid)
            atr_update(tr_buf, st.prev_mid, mid)
            st.prev_mid = mid

            ma = compute_ma(price_buf, cfg.MA_LENGTH)
            if ma is not None:
                ma_hist.append(ma)
            slope = ma_slope_dir(ma_hist, cfg.MA_SLOPE_LEN)
            vol_bps_ = micro_vol_bps(price_mm, mid, cfg.MA_LENGTH)
            atr_p = atr_value(cfg, tr_buf, price_mm)

            wall_band = cfg.WALL_BAND_BPS_DEFAULT
            if vol_bps_ > 0:
                wall_band = clamp(
                    (wall_band * Decimal("0.90")) + (vol_bps_ * Decimal("1.1") * Decimal("0.10")),
                    cfg.WALL_BAND_BPS_MIN, cfg.WALL_BAND_BPS_MAX
                )

            best_bid, best_ask, spread, wall_total = get_walls(cfg, depth, mid, wall_band)
            sbps = spread_bps(mid, best_bid, best_ask)

            st.ofi_ema = order_flow_imbalance(depth, mid, st.ofi_ema, wall_band)
            ofi = st.ofi_ema

            if vol_bps_ > 0:
                vol_hist.append(vol_bps_)
            vm = vol_median(vol_hist) if len(vol_hist) >= 20 else (vol_bps_ if vol_bps_ > 0 else D0)

            snap = Snapshot(
                mid=mid, best_bid=best_bid, best_ask=best_ask,
                spread=spread, spread_bps=sbps, wall_total=wall_total,
                ofi=ofi, ma=ma, slope=slope,
                vol_bps=vol_bps_, atr_price=atr_p, wall_band_bps=wall_band
            )

            reconcile_with_exchange(cfg, client, filt, st, snap, AUTH_OK, force=False)

            if (not cfg.SIMULATION_MODE) and AUTH_OK and st.is_flat():
                from utils.reconcile import _norm_pos
                ex = client.get_position(AUTH_OK)
                if ex and _norm_pos(ex.get("side")) and d(ex.get("amt", "0")) > cfg.RECONCILE_MIN_QTY_EPS:
                    reconcile_with_exchange(cfg, client, filt, st, snap, AUTH_OK, force=True)

            ma_gap_bps = float(((mid - ma) / mid) * Decimal("10000")) if (ma is not None and mid > 0) else 0.0
            raw = {
                "ofi": float(ofi),
                "ofi_prev": float(st.ofi_prev),
                "slope": float(slope),
                "vol_bps": float(vol_bps_),
                "vol_med": float(vm),
                "spread_bps": float(sbps),
                "wall_log": float(log1p_pos(wall_total)),
                "ma_gap_bps": ma_gap_bps,
            }
            learner.push(mid, raw)
            learner.step(mid_now=mid, vol_bps=vol_bps_, spread_bps=sbps, cfg=cfg)

            append_jsonl(cfg.CENTRAL_LOG_JSONL, {
                "ts": utc_ts(), "event": "SNAP",
                "mid": str(mid), "ofi": str(ofi),
                "slope": slope, "vol_bps": str(vol_bps_), "vol_med": str(vm),
                "spread_bps": str(sbps), "wall_total": str(wall_total),
                "wall_band_bps": str(wall_band),
                "pos": st.position or "FLAT",
                "unreal": str(st.unreal(mid)) if not st.is_flat() else "0",
                "model_trained": model.trained_examples,
            })

            if not st.is_flat():
                closed = try_exit(cfg, client, filt, st, snap, AUTH_OK, acct)
                if closed:
                    flush_state(force=True)
            else:
                opened = try_entry(cfg, client, filt, st, snap, AUTH_OK, acct, model, vm)
                if opened:
                    flush_state(force=True)

            flush_state(force=False)
            time.sleep(0.35 if cfg.LIVE_PROFILE else cfg.LOOP_SLEEP)

        except KeyboardInterrupt:
            LOG.warning("STOPPED BY USER")
            flush_state(force=True)
            raise
        except SystemExit as e:
            LOG.warning("STOP: %s", e)
            flush_state(force=True)
            raise
        except Exception as e:
            LOG.error("LOOP ERROR: %s", e)
            traceback.print_exc()
            flush_state(force=True)
            time.sleep(0.85)


if __name__ == "__main__":
    main()
