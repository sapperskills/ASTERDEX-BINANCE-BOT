"""Multi-symbol orchestrator with sim-to-live promotion pipeline.

Supports both Aster DEX and Binance Futures — set BASE_URL in config.json:
  Aster:   https://fapi.asterdex.com
  Binance: https://fapi.binance.com

Both exchanges use identical /fapi/ REST endpoints, so the same trading
logic works on either. The EXCHANGE field is auto-detected from BASE_URL.

When SIMULATION_MODE = true (--sim):
    All breakout signals are sim-traded. No real orders. The system
    builds up sim performance data and the adaptive learner tunes
    parameters. Use this phase to let the engine learn the markets.

When SIMULATION_MODE = false (live):
    Breakout signals STILL go through sim first. Each symbol gets a
    sim runner that paper-trades it. When a symbol's sim performance
    meets the promotion gates (win rate, profit factor, trade count),
    a LIVE runner is spawned for that symbol with real orders. If live
    performance degrades, the symbol is demoted back to sim-only.

    This means the sim engine is ALWAYS running as a proving ground,
    even in live mode. Only proven breakouts get real money.
"""

from __future__ import annotations

import copy
import json
import logging
import os
import threading
import time
import traceback
from collections import deque
from datetime import datetime
from decimal import Decimal, getcontext
from typing import Any, Deque, Dict, List, Optional

getcontext().prec = 28

from core.helpers import D0, d, clamp, utc_ts, append_jsonl, file_exists, log1p_pos
from core.config import Config, load_config_json, per_symbol_paths
from core.state import BotState, state_load, state_save, rolling_wr
from core.types import (
    SymbolFilters, Snapshot, SymbolProfile,
    load_symbol_profile, apply_profile_to_cfg, save_symbol_profile,
)
from exchange.client import ExchangeClient, is_sig_error
from exchange.market import (
    get_price, get_walls, spread_bps, order_flow_imbalance, RollingMinMax,
)
from strategy.signals import compute_ma, ma_slope_dir, atr_update, atr_value, micro_vol_bps, vol_median
from execution.entry import try_entry
from execution.exit_ import try_exit
from learning.model import OnlineLogReg
from learning.learner import Learner
from learning.adaptive import AdaptiveLearner, TradeRecord
from learning.promotion import PromotionEngine, PromotionConfig, SimTradeResult
from learning.population import PopulationManager, PopulationConfig
from learning.pretrain import load_breakout_profile, pretrain_all_symbols
from agent.service import AgentService
from utils.reconcile import reconcile_with_exchange, boot_adopt_exchange_position
from utils.calibration import calibrate_symbol_profile
from scanner.market_scanner import MarketScanner, BreakoutSignal, ScannerConfig

LOG = logging.getLogger("aster.orchestrator")


class SymbolRunner:
    """Manages the trading loop for a single symbol.

    When is_sim=True, the Config has SIMULATION_MODE=True so all orders
    are paper. When is_sim=False, Config has SIMULATION_MODE=False and
    real orders flow to the exchange.
    """

    def __init__(
        self, cfg: Config, client: ExchangeClient, filt: SymbolFilters,
        model: OnlineLogReg, learner: Learner, st: BotState,
        adaptive: AdaptiveLearner, auth_ok: bool, is_sim: bool = True,
    ):
        self.cfg = cfg
        self.client = client
        self.filt = filt
        self.model = model
        self.learner = learner
        self.st = st
        self.adaptive = adaptive
        self.auth_ok = auth_ok
        self.is_sim = is_sim

        self.price_buf: Deque[Decimal] = deque(maxlen=cfg.MA_LENGTH)
        self.price_mm = RollingMinMax(maxlen=cfg.MA_LENGTH)
        self.ma_hist: Deque[Decimal] = deque(maxlen=cfg.MA_SLOPE_LEN)
        self.tr_buf: Deque[Decimal] = deque(maxlen=cfg.ATR_LEN)
        self.vol_hist: Deque[Decimal] = deque(maxlen=cfg.VOL_ROLL_LEN)

        self.last_heartbeat: float = 0.0
        self.last_state_flush: float = 0.0
        self.warmed_up: bool = False

    def warmup(self, ticks: int = 80) -> None:
        for _ in range(ticks):
            mid = get_price(self.cfg, self.client)
            if mid > 0:
                self.price_mm.push(mid)
                self.price_buf.append(mid)
                atr_update(self.tr_buf, self.st.prev_mid, mid)
                self.st.prev_mid = mid
            time.sleep(0.18)
        self.warmed_up = True
        tag = "SIM" if self.is_sim else "LIVE"
        LOG.info("[%s][%s] Warmup complete (%d ticks)", self.cfg.SYMBOL, tag, ticks)

    def tick(self, acct: dict) -> Optional[TradeRecord]:
        """Run one iteration. Returns TradeRecord if a trade closed."""
        cfg = self.cfg
        st = self.st
        client = self.client
        filt = self.filt

        mid = get_price(cfg, client)
        if mid <= 0:
            return None

        depth = client.get_depth_cached()
        if not depth or not depth.get("bids") or not depth.get("asks"):
            return None

        st.ofi_prev = float(st.ofi_ema)
        self.price_mm.push(mid)
        self.price_buf.append(mid)
        atr_update(self.tr_buf, st.prev_mid, mid)
        st.prev_mid = mid

        ma = compute_ma(self.price_buf, cfg.MA_LENGTH)
        if ma is not None:
            self.ma_hist.append(ma)
        slope = ma_slope_dir(self.ma_hist, cfg.MA_SLOPE_LEN)
        vol_bps_ = micro_vol_bps(self.price_mm, mid, cfg.MA_LENGTH)
        atr_p = atr_value(cfg, self.tr_buf, self.price_mm)

        wall_band = cfg.WALL_BAND_BPS_DEFAULT
        if vol_bps_ > 0:
            wall_band = clamp(
                (wall_band * Decimal("0.90")) + (vol_bps_ * Decimal("1.1") * Decimal("0.10")),
                cfg.WALL_BAND_BPS_MIN, cfg.WALL_BAND_BPS_MAX
            )

        best_bid, best_ask, spread, wall_total = get_walls(cfg, depth, mid, wall_band)
        sbps = spread_bps(mid, best_bid, best_ask)
        st.ofi_ema = order_flow_imbalance(depth, mid, st.ofi_ema, wall_band)
        ofi = st.ofi_ema

        if vol_bps_ > 0:
            self.vol_hist.append(vol_bps_)
        vm = vol_median(self.vol_hist) if len(self.vol_hist) >= 20 else (vol_bps_ if vol_bps_ > 0 else D0)

        snap = Snapshot(
            mid=mid, best_bid=best_bid, best_ask=best_ask,
            spread=spread, spread_bps=sbps, wall_total=wall_total,
            ofi=ofi, ma=ma, slope=slope,
            vol_bps=vol_bps_, atr_price=atr_p, wall_band_bps=wall_band
        )

        reconcile_with_exchange(cfg, client, filt, st, snap, self.auth_ok, force=False)

        # ── Extra reconcile safety: if local is flat but exchange has position ──
        if (not cfg.SIMULATION_MODE) and self.auth_ok and st.is_flat():
            ex = client.get_position(self.auth_ok)
            if ex:
                from utils.reconcile import _norm_pos
                ex_side = _norm_pos(ex.get("side"))
                ex_qty = d(ex.get("amt", "0"))
                if ex_side and ex_qty > cfg.RECONCILE_MIN_QTY_EPS:
                    reconcile_with_exchange(cfg, client, filt, st, snap, self.auth_ok, force=True)

        ma_gap_bps = float(((mid - ma) / mid) * Decimal("10000")) if (ma is not None and mid > 0) else 0.0
        raw = {
            "ofi": float(ofi), "ofi_prev": float(st.ofi_prev), "slope": float(slope),
            "vol_bps": float(vol_bps_), "vol_med": float(vm),
            "spread_bps": float(sbps), "wall_log": float(log1p_pos(wall_total)),
            "ma_gap_bps": ma_gap_bps,
        }
        self.learner.push(mid, raw)
        self.learner.step(mid_now=mid, vol_bps=vol_bps_, spread_bps=sbps, cfg=cfg)

        # ── Write SNAP to log so dashboard can read live market data ──
        # Throttle to heartbeat interval to prevent log bloat
        now_t = time.time()
        if now_t - self.last_heartbeat >= cfg.HEARTBEAT_SEC:
            self.last_heartbeat = now_t
            append_jsonl(cfg.CENTRAL_LOG_JSONL, {
                "ts": utc_ts(), "event": "SNAP",
                "mid": str(mid), "ofi": str(ofi),
                "slope": slope, "vol_bps": str(vol_bps_), "vol_med": str(vm),
                "spread_bps": str(sbps), "wall_total": str(wall_total),
                "wall_band_bps": str(wall_band),
                "pos": st.position or "FLAT",
                "unreal": str(st.unreal(mid)) if not st.is_flat() else "0",
                "model_trained": self.model.trained_examples,
            })

        trade_record = None

        if not st.is_flat():
            pre_pos = st.position
            pre_qty = st.qty
            pre_entry = st.entry_price
            pre_time = st.entry_time
            pre_day_pnl = st.realized_day_pnl  # capture before exit modifies it

            closed = try_exit(cfg, client, filt, st, snap, self.auth_ok, acct)
            if closed:
                # Use actual realized PnL from state (set by try_exit) rather than
                # estimated mid-price PnL which can be inaccurate
                actual_pnl = float(st.realized_day_pnl - pre_day_pnl)
                # Fallback to mid-based estimate if state was reset (e.g. day rollover)
                if actual_pnl == 0.0 and pre_qty > 0:
                    exit_px = float(mid)
                    if pre_pos == "LONG":
                        actual_pnl = (exit_px - float(pre_entry)) * float(pre_qty)
                    else:
                        actual_pnl = (float(pre_entry) - exit_px) * float(pre_qty)

                trade_record = TradeRecord(
                    symbol=cfg.SYMBOL,
                    direction=pre_pos or "UNKNOWN",
                    pnl=actual_pnl,
                    entry_price=float(pre_entry),
                    exit_price=float(mid),
                    held_sec=time.time() - pre_time,
                    exit_reason="EXIT",
                    regime="",
                )
                self._flush_state(force=True)
        else:
            opened = try_entry(cfg, client, filt, st, snap, self.auth_ok, acct, self.model, vm)
            if opened:
                self._flush_state(force=True)

        self._flush_state(force=False)
        return trade_record

    def _flush_state(self, force: bool = False) -> None:
        now = time.time()
        if not force and now - self.last_state_flush < 2.0:
            return
        self.last_state_flush = now
        state_save(self.cfg, self.st)
        self.model.maybe_save(force=False)


class MultiSymbolOrchestrator:
    """Orchestrates the sim-to-live pipeline across all symbols.

    Architecture:
        Scanner --> Breakout Signal --> Sim Runner (always)
                                            |
                                    passes promotion gates?
                                            |
                                    YES --> Live Runner (real orders)

    The per-symbol runner warmup is profile-aware and model-aware.
    Pretraining reduces the need for a long post-breakout delay, but we
    still seed live rolling buffers before decisions go live.
    """

    def _compute_spawn_warmup_ticks(self, cfg: Config, model: OnlineLogReg, has_profile: bool, is_live: bool) -> int:
        pretrained_examples = int(getattr(cfg, "PRETRAINED_MODEL_EXAMPLES", 100))
        trained_examples = int(getattr(model, "trained_examples", 0))
        is_pretrained = trained_examples >= pretrained_examples

        if is_live:
            if has_profile and is_pretrained:
                ticks = int(getattr(cfg, "LIVE_WARMUP_TICKS_PRETRAINED_PROFILED", 25))
            elif is_pretrained:
                ticks = int(getattr(cfg, "LIVE_WARMUP_TICKS_PRETRAINED", 35))
            else:
                ticks = int(getattr(cfg, "LIVE_WARMUP_TICKS_COLD", 60))
            tag = "LIVE"
        else:
            if has_profile and is_pretrained:
                ticks = int(getattr(cfg, "SIM_WARMUP_TICKS_PRETRAINED_PROFILED", 15))
            elif is_pretrained:
                ticks = int(getattr(cfg, "SIM_WARMUP_TICKS_PRETRAINED", 25))
            else:
                ticks = int(getattr(cfg, "SIM_WARMUP_TICKS_COLD", 50))
            tag = "SIM"

        ticks = max(8, ticks)
        LOG.info("[%s][%s] Warmup selected: %d ticks (profile=%s model_examples=%d threshold=%d)",
                 cfg.SYMBOL, tag, ticks, has_profile, trained_examples, pretrained_examples)
        return ticks

    def __init__(self, base_config_path: str = "config.json"):
        self.base_config_path = base_config_path
        self.base_cfg = Config()
        load_config_json(self.base_cfg, base_config_path)

        self.is_pure_sim = self.base_cfg.SIMULATION_MODE

        self.max_concurrent_live = min(5, max(1, int(os.environ.get("MAX_SYMBOLS", "3"))))
        self.max_concurrent_sim = min(15, max(3, int(os.environ.get("MAX_SIM_SYMBOLS", "8"))))
        self.max_portfolio_loss_usd = Decimal(os.environ.get("MAX_PORTFOLIO_LOSS", "100"))

        self.client = ExchangeClient(self.base_cfg)
        self.adaptive = AdaptiveLearner(persist_dir="adaptive_state")

        promo_cfg = PromotionConfig(
            min_sim_trades=int(os.environ.get("MIN_SIM_TRADES", "5")),
            min_sim_win_rate=float(os.environ.get("MIN_SIM_WR", "0.55")),
            min_sim_profit_factor=float(os.environ.get("MIN_SIM_PF", "1.20")),
            max_live_symbols=self.max_concurrent_live,
            use_pretrain_prior=os.environ.get("PROMO_USE_PRETRAIN_PRIOR", "true").strip().lower() not in {"0", "false", "no", "off"},
            promotion_score_threshold=float(os.environ.get("PROMO_SCORE_THRESHOLD", "0.56")),
            sim_score_weight=float(os.environ.get("PROMO_SIM_WEIGHT", "0.55")),
            pretrain_score_weight=float(os.environ.get("PROMO_PRETRAIN_WEIGHT", "0.25")),
            breakout_conf_weight=float(os.environ.get("PROMO_BREAKOUT_WEIGHT", "0.20")),
            min_sim_trades_floor=int(os.environ.get("PROMO_MIN_SIM_TRADES_FLOOR", "3")),
            max_min_trades_reduction=int(os.environ.get("PROMO_MAX_TRADE_REDUCTION", "2")),
            pretrain_bonus_threshold=float(os.environ.get("PROMO_PRETRAIN_BONUS_TH", "0.55")),
            breakout_bonus_threshold=float(os.environ.get("PROMO_BREAKOUT_BONUS_TH", "0.45")),
        )
        self.promotion = PromotionEngine(config=promo_cfg)

        scanner_cfg = ScannerConfig(
            scan_interval_sec=float(os.environ.get("SCAN_INTERVAL", "10")),
            deep_scan_interval_sec=float(os.environ.get("DEEP_SCAN_INTERVAL", "30")),
            breakout_threshold=float(os.environ.get("BREAKOUT_THRESHOLD", "0.45")),
            top_n_research=int(os.environ.get("TOP_N_RESEARCH", "30")),
            fast_candidate_limit=int(os.environ.get("FAST_CANDIDATE_LIMIT", "20")),
            min_fast_abs_momentum_bps=float(os.environ.get("FAST_MIN_MOMENTUM_BPS", "0.5")),
            max_concurrent_symbols=self.max_concurrent_sim,
            base_url=self.base_cfg.BASE_URL,
        )
        self.scanner = MarketScanner(config=scanner_cfg, on_signal=self._on_breakout_signal)

        pop_cfg = PopulationConfig(
            target_live_min=max(1, int(os.environ.get("POP_TARGET_LIVE_MIN", "1"))),
            target_live_max=max(1, int(os.environ.get("POP_TARGET_LIVE_MAX", str(self.max_concurrent_live)))),
            target_sim_min=max(1, int(os.environ.get("POP_TARGET_SIM_MIN", "3"))),
            target_sim_max=max(2, int(os.environ.get("POP_TARGET_SIM_MAX", str(self.max_concurrent_sim)))),
            healthy_live_wr=float(os.environ.get("POP_HEALTHY_LIVE_WR", "0.52")),
            healthy_live_pnl_floor=float(os.environ.get("POP_HEALTHY_LIVE_PNL", "0.0")),
            stress_live_loss_streak=int(os.environ.get("POP_STRESS_LOSS_STREAK", "2")),
            stress_live_dd_pnl=float(os.environ.get("POP_STRESS_LIVE_PNL", "-10.0")),
            update_interval_sec=float(os.environ.get("POP_UPDATE_INTERVAL_SEC", "15")),
        )
        self.population = PopulationManager(config=pop_cfg)

        self._sim_runners: Dict[str, SymbolRunner] = {}
        self._sim_threads: Dict[str, threading.Thread] = {}
        self._sim_stops: Dict[str, threading.Event] = {}

        self._live_runners: Dict[str, SymbolRunner] = {}
        self._live_threads: Dict[str, threading.Thread] = {}
        self._live_stops: Dict[str, threading.Event] = {}

        self._lock = threading.Lock()
        self._pending_signals: List[BreakoutSignal] = []

        self.portfolio_pnl = Decimal("0")
        self.portfolio_day = ""
        self.auth_ok = True
        self.agent = AgentService(base_dir=os.path.dirname(os.path.abspath(base_config_path)) or ".", interval_sec=float(getattr(self.base_cfg, "AI_LAB_INTERVAL_SEC", 120.0))) if getattr(self.base_cfg, "AI_LAB_ENABLE", True) else None

    def run(self) -> None:
        LOG.info("=" * 66)
        exchange_name = self.base_cfg.EXCHANGE.upper() or "UNKNOWN"
        LOG.info("  UNIFIED v5.0 [%s] — Homeostatic Population Engine", exchange_name)
        LOG.info("=" * 66)
        if self.is_pure_sim:
            LOG.info("  Mode: PURE SIMULATION (no live orders)")
            LOG.info("  All breakouts will be sim-traded to build performance data.")
        else:
            LOG.info("  Mode: HYBRID SIM -> LIVE")
            LOG.info("  Breakouts sim-traded first. Promoted to LIVE when proven.")
            LOG.info("  Promotion gates: %d trades, %.0f%% WR, %.1fx PF",
                     self.promotion.config.min_sim_trades,
                     self.promotion.config.min_sim_win_rate * 100,
                     self.promotion.config.min_sim_profit_factor)
        LOG.info("  Max live symbols: %d | Max sim symbols: %d",
                 self.max_concurrent_live, self.max_concurrent_sim)
        LOG.info("  Max portfolio daily loss: $%s", self.max_portfolio_loss_usd)
        LOG.info("=" * 66)

        if not self.is_pure_sim:
            if not self.base_cfg.API_KEY or not self.base_cfg.API_SECRET:
                raise SystemExit("LIVE MODE requires API_KEY and API_SECRET in config.json.")
            self.client.sync_time()

        for sym in self.promotion.get_promoted_symbols():
            LOG.info("Restoring promoted symbol from prior session: %s", sym)

        if self.agent:
            try:
                self.agent.run_once()
                self.agent.start()
            except Exception as e:
                LOG.warning("AI lab agent failed to start: %s", e)
        self.scanner.start()
        LOG.info("Market scanner started — detecting breakouts...")

        # ── Pre-train models from kline data ─────────────────────────────
        # Wait briefly for scanner to do its first fast scan and build candidate list
        LOG.info("Waiting for scanner to build initial symbol list...")
        for _ in range(12):
            time.sleep(2.5)
            candidates = self.scanner._fast_candidates[:]
            if candidates:
                break
        if candidates:
            LOG.info("Pre-training ML models from kline history for %d candidates...", len(candidates))
            from research.client import PublicFuturesClient
            pretrain_client = PublicFuturesClient(base_url=self.base_cfg.BASE_URL)
            pretrain_results = pretrain_all_symbols(
                client=pretrain_client,
                symbols=candidates[:20],  # top 20 candidates
                cfg=self.base_cfg,
                kline_interval="5m",
                kline_limit=500,
                horizon=12,
                threshold_bps=3.0,
                epochs=3,
            )
            good_models = {sym: r for sym, r in pretrain_results.items() if r.val_accuracy >= 0.52}
            breakout_profiles = {sym: p for sym in pretrain_results.keys() if (p := load_breakout_profile(sym)) is not None}
            if breakout_profiles:
                self.scanner.set_breakout_profiles(breakout_profiles)
            for sym, result in pretrain_results.items():
                prof = breakout_profiles.get(sym)
                self.promotion.set_symbol_prior(
                    symbol=sym,
                    pretrain_score=float(getattr(result, "val_accuracy", 0.0)),
                    breakout_confidence=float(getattr(prof, "confidence", 0.0)) if prof is not None else 0.0,
                    val_accuracy=float(getattr(result, "val_accuracy", 0.0)),
                    labeled_examples=int(getattr(prof, "labeled_examples", 0)) if prof is not None else int(getattr(result, "samples", 0)),
                )
            LOG.info("Pre-trained %d models, %d with val_acc >= 52%%: %s",
                     len(pretrain_results), len(good_models),
                     ", ".join(f"{s}({r.val_accuracy:.0%})" for s, r in
                               sorted(good_models.items(), key=lambda x: x[1].val_accuracy, reverse=True)[:8]))
            if breakout_profiles:
                LOG.info("Loaded %d breakout profiles from pretrain data", len(breakout_profiles))
            if pretrain_results:
                LOG.info("Promotion engine updated with %d pretrain priors", len(pretrain_results))
        else:
            LOG.warning("No scanner candidates yet — skipping pre-training")

        try:
            while True:
                now_dt = datetime.utcnow()
                today = str(now_dt.date())

                if today != self.portfolio_day:
                    if self.portfolio_day:
                        LOG.info("NEW DAY: portfolio_pnl=%+.2f", self.portfolio_pnl)
                    self.portfolio_day = today
                    self.portfolio_pnl = Decimal("0")

                if not self.is_pure_sim and self.portfolio_pnl <= -self.max_portfolio_loss_usd:
                    LOG.warning("PORTFOLIO LOSS LIMIT — pausing live entries for 60s")
                    time.sleep(60)
                    continue

                if file_exists(self.base_cfg.KILL_SWITCH_FILE):
                    LOG.warning("KILL SWITCH")
                    self._stop_all()
                    raise SystemExit("Killed by KILL.txt")

                self._process_signals()

                if not self.is_pure_sim:
                    self._check_promotions()
                    self._check_demotions()

                for sym in list(self._live_runners.keys()):
                    if self.adaptive.should_pause_symbol(sym):
                        LOG.warning("ADAPTIVE PAUSE live runner: %s", sym)
                        self._stop_live_runner(sym)

                self._cleanup_dead_threads()

                sim_active = list(self._sim_runners.keys())
                live_active = list(self._live_runners.keys())
                promo_summary = self.promotion.summary()
                pop_state = self.population.maybe_update(
                    promotion_engine=self.promotion,
                    scanner=self.scanner,
                    sim_count=len(sim_active),
                    live_count=len(live_active),
                    max_live_symbols=self.max_concurrent_live,
                    max_sim_symbols=self.max_concurrent_sim,
                )

                if sim_active or live_active or pop_state:
                    LOG.info("STATUS: sim=%d live=%d promoted=%d pnl=%+.2f mode=%s quality=%.3f | sim:[%s] live:[%s]",
                             len(sim_active), len(live_active),
                             promo_summary["promoted_count"],
                             self.portfolio_pnl,
                             pop_state.get("mode", "NORMAL"),
                             float(pop_state.get("quality", 0.0)),
                             ",".join(sim_active[:5]),
                             ",".join(live_active))

                # Periodic persist so dashboard stays updated even between trades
                self.adaptive.persist(force=False)

                time.sleep(5.0)

        except KeyboardInterrupt:
            LOG.warning("STOPPED BY USER")
        except SystemExit as e:
            LOG.warning("STOP: %s", e)
        finally:
            self._stop_all()
            self.scanner.stop()
            if self.agent:
                self.agent.stop()
            self.adaptive.persist(force=True)
            self.promotion._persist_state()

    def _on_breakout_signal(self, signal: BreakoutSignal) -> None:
        with self._lock:
            self._pending_signals.append(signal)

    def _process_signals(self) -> None:
        with self._lock:
            signals = self._pending_signals[:]
            self._pending_signals.clear()

        for signal in sorted(signals, key=lambda s: s.score, reverse=True):
            sym = signal.symbol
            agent_override = self.agent.get_symbol_override(sym) if self.agent else {}
            if agent_override:
                allow_regimes = agent_override.get("ALLOW_REGIMES") or []
                signal_regime = getattr(signal.snapshot, "regime", "") if signal.snapshot is not None else ""
                if getattr(self.base_cfg, "AI_LAB_REQUIRE_REGIME_FILTER", True) and allow_regimes and signal_regime and signal_regime not in allow_regimes:
                    LOG.info("AI_LAB blocked %s: regime=%s not in %s", sym, signal_regime, allow_regimes)
                    continue
                signal.score += float(getattr(self.base_cfg, "AI_LAB_SCORE_BOOST", 0.03))
            if sym in self._sim_runners or sym in self._live_runners:
                continue
            sim_cap = self.population.controls(self.max_concurrent_live, self.max_concurrent_sim).get("sim_cap", self.max_concurrent_sim)
            if len(self._sim_runners) >= sim_cap:
                break

            LOG.info("SPAWNING SIM runner: %s (breakout_score=%.3f, dir=%s)",
                     sym, signal.score,
                     "LONG" if signal.direction > 0 else "SHORT")
            try:
                self._spawn_sim_runner(sym, signal)
            except Exception as e:
                LOG.error("Failed to spawn sim runner for %s: %s", sym, e)

    def _check_promotions(self) -> None:
        newly_promoted = self.promotion.check_promotions()
        for sym in newly_promoted:
            if sym in self._live_runners:
                continue
            LOG.info(">>> PROMOTING %s to LIVE trading <<<", sym)
            try:
                self._spawn_live_runner(sym)
            except Exception as e:
                LOG.error("Failed to promote %s to live: %s", sym, e)

    def _check_demotions(self) -> None:
        demoted = self.promotion.check_demotions()
        for sym in demoted:
            LOG.warning("<<< DEMOTING %s back to SIM-only >>>", sym)
            self._stop_live_runner(sym)

    def _spawn_sim_runner(self, symbol: str, signal: BreakoutSignal) -> None:
        cfg = Config()
        load_config_json(cfg, self.base_config_path)
        cfg.SYMBOL = symbol
        cfg.SIMULATION_MODE = True
        per_symbol_paths(cfg)
        cfg.STATE_FILE = f"SIM_{cfg.STATE_FILE}"
        cfg.TRADE_LOG = f"SIM_{cfg.TRADE_LOG}"
        cfg.CENTRAL_LOG_JSONL = f"SIM_{cfg.CENTRAL_LOG_JSONL}"
        cfg.LEARNING_LOG_JSONL = f"SIM_{cfg.LEARNING_LOG_JSONL}"
        cfg.MODEL_FILE = f"SIM_{cfg.MODEL_FILE}"
        cfg.PROFILE_FILE = f"SIM_{cfg.PROFILE_FILE}"

        if signal.recommendation:
            patch = signal.recommendation.patch
            self.adaptive.set_prior(symbol, patch)
            current_patch = self.adaptive.get_current_patch(symbol)
            self._apply_patch_to_config(cfg, current_patch)
        agent_override = self.agent.get_symbol_override(symbol) if self.agent else {}
        if agent_override:
            for k in ("MAX_SPREAD_BPS", "MIN_WALL_TOTAL", "TP_USD_FIXED", "SL_USD_FIXED",
                      "TRAIL_START_FRAC_TP", "TRAIL_ATR_GAP_MULT", "BREAK_EVEN_AFTER_FRAC_TP",
                      "STAGNATION_MIN_UNREAL_USD"):
                if k in agent_override:
                    try:
                        setattr(cfg, k, Decimal(str(agent_override[k])))
                    except Exception:
                        pass
            for k in ("MAX_HOLD_SEC", "STAGNATION_HOLD_SEC"):
                if k in agent_override:
                    try:
                        setattr(cfg, k, float(agent_override[k]))
                    except Exception:
                        pass
            if "MIN_OFI_ABS" in agent_override:
                try:
                    cfg.HEUR_OFI_MIN = Decimal(str(agent_override["MIN_OFI_ABS"]))
                except Exception:
                    pass

        client = ExchangeClient(cfg)
        filt = SymbolFilters()
        self._load_symbol_filters(cfg, client, filt)

        prof = load_symbol_profile(cfg)
        has_profile = prof is not None
        if prof:
            apply_profile_to_cfg(cfg, prof)
        elif cfg.CALIB_ENABLE:
            prof = calibrate_symbol_profile(cfg, client, filt, profile_exists=False)
            has_profile = prof is not None

        model = OnlineLogReg(cfg)
        if model.load():
            LOG.info("[SIM][%s] Model loaded: %d examples", symbol, model.trained_examples)
        else:
            model.maybe_save(force=True)

        learner = Learner(cfg, model)
        st = state_load(cfg) or BotState(current_day=str(datetime.utcnow().date()))
        runner = SymbolRunner(cfg, client, filt, model, learner, st, self.adaptive, True, is_sim=True)

        stop_event = threading.Event()
        self._sim_stops[symbol] = stop_event
        breakout_score = signal.score

        def run_sim():
            try:
                warmup_ticks = self._compute_spawn_warmup_ticks(cfg, model, has_profile, is_live=False)
                runner.warmup(ticks=warmup_ticks)
                state_save(cfg, st)
                acct = {}
                while not stop_event.is_set():
                    try:
                        if file_exists(cfg.KILL_SWITCH_FILE):
                            break
                        now_dt = datetime.utcnow()
                        if str(now_dt.date()) != str(st.current_day):
                            st.current_day = str(now_dt.date())
                            st.realized_day_pnl = D0
                            st.loss_streak = 0

                        trade_record = runner.tick(acct)
                        if trade_record:
                            sim_result = SimTradeResult(
                                symbol=symbol,
                                direction=trade_record.direction,
                                pnl=trade_record.pnl,
                                entry_price=trade_record.entry_price,
                                exit_price=trade_record.exit_price,
                                held_sec=trade_record.held_sec,
                                exit_reason=trade_record.exit_reason,
                                breakout_score=breakout_score,
                            )
                            self.promotion.record_sim_trade(sim_result)

                            snap = self.scanner.get_snapshot(symbol)
                            if snap:
                                trade_record.regime = snap.regime
                            adjustment = self.adaptive.record_trade(trade_record)
                            if adjustment:
                                self._apply_patch_to_config(cfg, adjustment)

                        time.sleep(cfg.LOOP_SLEEP)
                    except Exception as e:
                        LOG.error("[SIM][%s] Tick error: %s", symbol, e)
                        time.sleep(1.0)
            except Exception as e:
                LOG.error("[SIM][%s] Fatal error: %s", symbol, e)
                traceback.print_exc()
            finally:
                state_save(cfg, st)
                model.maybe_save(force=True)
                self.scanner.mark_inactive(symbol)
                LOG.info("[SIM][%s] Runner stopped", symbol)

        thread = threading.Thread(target=run_sim, name=f"Sim-{symbol}", daemon=True)
        self._sim_runners[symbol] = runner
        self._sim_threads[symbol] = thread
        self.scanner.mark_active(symbol)
        thread.start()

    def _spawn_live_runner(self, symbol: str) -> None:
        if self.is_pure_sim:
            LOG.warning("Cannot spawn live runner in pure-sim mode")
            return

        cfg = Config()
        load_config_json(cfg, self.base_config_path)
        cfg.SYMBOL = symbol
        cfg.SIMULATION_MODE = False
        per_symbol_paths(cfg)

        current_patch = self.adaptive.get_current_patch(symbol)
        self._apply_patch_to_config(cfg, current_patch)
        agent_override = self.agent.get_symbol_override(symbol) if self.agent else {}
        if agent_override:
            for k in ("MAX_SPREAD_BPS", "MIN_WALL_TOTAL", "TP_USD_FIXED", "SL_USD_FIXED",
                      "TRAIL_START_FRAC_TP", "TRAIL_ATR_GAP_MULT", "BREAK_EVEN_AFTER_FRAC_TP",
                      "STAGNATION_MIN_UNREAL_USD"):
                if k in agent_override:
                    try:
                        setattr(cfg, k, Decimal(str(agent_override[k])))
                    except Exception:
                        pass
            for k in ("MAX_HOLD_SEC", "STAGNATION_HOLD_SEC"):
                if k in agent_override:
                    try:
                        setattr(cfg, k, float(agent_override[k]))
                    except Exception:
                        pass
            if "MIN_OFI_ABS" in agent_override:
                try:
                    cfg.HEUR_OFI_MIN = Decimal(str(agent_override["MIN_OFI_ABS"]))
                except Exception:
                    pass

        client = ExchangeClient(cfg)
        client.sync_time()

        filt = SymbolFilters()
        self._load_symbol_filters(cfg, client, filt)
        self._set_leverage(cfg, client)

        prof = load_symbol_profile(cfg)
        has_profile = prof is not None
        if prof:
            apply_profile_to_cfg(cfg, prof)
        elif cfg.CALIB_ENABLE:
            prof = calibrate_symbol_profile(cfg, client, filt, profile_exists=False)
            has_profile = prof is not None

        model = OnlineLogReg(cfg)
        sim_model_file = f"SIM_{cfg.MODEL_FILE}"
        if os.path.exists(sim_model_file):
            cfg_tmp = copy.copy(cfg)
            cfg_tmp.MODEL_FILE = sim_model_file
            model_tmp = OnlineLogReg(cfg_tmp)
            if model_tmp.load():
                model.features = model_tmp.features
                model.w = dict(model_tmp.w)
                model.b = model_tmp.b
                model.norm = model_tmp.norm
                model.trained_examples = model_tmp.trained_examples
                LOG.info("[LIVE][%s] Warm-started model from sim: %d examples",
                         symbol, model.trained_examples)
        elif model.load():
            LOG.info("[LIVE][%s] Model loaded: %d examples", symbol, model.trained_examples)
        else:
            model.maybe_save(force=True)

        learner = Learner(cfg, model)
        st = state_load(cfg) or BotState(current_day=str(datetime.utcnow().date()))

        # If loaded state has a position, validate it against exchange BEFORE warming up.
        # This prevents stale positions from a prior session being traded on.
        if not st.is_flat() and self.auth_ok and not cfg.SIMULATION_MODE:
            LOG.info("[LIVE][%s] Loaded state has position %s qty=%s — will verify with exchange after warmup",
                     symbol, st.position, st.qty)

        runner = SymbolRunner(cfg, client, filt, model, learner, st,
                              self.adaptive, self.auth_ok, is_sim=False)

        stop_event = threading.Event()
        self._live_stops[symbol] = stop_event

        def run_live():
            try:
                warmup_ticks = self._compute_spawn_warmup_ticks(cfg, model, has_profile, is_live=True)
                runner.warmup(ticks=warmup_ticks)
                boot_adopt_exchange_position(cfg, client, filt, st, self.auth_ok,
                                             runner.price_mm, runner.price_buf,
                                             runner.ma_hist, runner.tr_buf, runner.vol_hist)
                state_save(cfg, st)
                LOG.info("[LIVE][%s] Post-boot state: pos=%s qty=%s entry=%s",
                         symbol, st.position or "FLAT", st.qty, st.entry_price)
                acct = client.get_account_cached(self.auth_ok)

                while not stop_event.is_set():
                    try:
                        if file_exists(cfg.KILL_SWITCH_FILE):
                            break
                        now_dt = datetime.utcnow()
                        if str(now_dt.date()) != str(st.current_day):
                            st.current_day = str(now_dt.date())
                            st.realized_day_pnl = D0
                            st.loss_streak = 0

                        acct = client.get_account_cached(self.auth_ok)
                        trade_record = runner.tick(acct)

                        if trade_record:
                            is_win = trade_record.pnl > 0
                            self.promotion.record_live_trade(symbol, trade_record.pnl, is_win)
                            self.portfolio_pnl += d(str(trade_record.pnl))

                            snap = self.scanner.get_snapshot(symbol)
                            if snap:
                                trade_record.regime = snap.regime
                            adjustment = self.adaptive.record_trade(trade_record)
                            if adjustment:
                                self._apply_patch_to_config(cfg, adjustment)

                            LOG.info("[LIVE][%s] TRADE: %s pnl=%+.4f portfolio=%+.2f",
                                     symbol, trade_record.direction,
                                     trade_record.pnl, self.portfolio_pnl)

                        time.sleep(0.35 if cfg.LIVE_PROFILE else cfg.LOOP_SLEEP)
                    except Exception as e:
                        LOG.error("[LIVE][%s] Tick error: %s", symbol, e)
                        traceback.print_exc()
                        time.sleep(1.0)
            except Exception as e:
                LOG.error("[LIVE][%s] Fatal error: %s", symbol, e)
                traceback.print_exc()
            finally:
                state_save(cfg, st)
                model.maybe_save(force=True)
                LOG.info("[LIVE][%s] Runner stopped", symbol)

        thread = threading.Thread(target=run_live, name=f"Live-{symbol}", daemon=True)
        self._live_runners[symbol] = runner
        self._live_threads[symbol] = thread
        thread.start()
        LOG.info("[LIVE][%s] LIVE runner started — REAL ORDERS ACTIVE", symbol)

    def _stop_sim_runner(self, symbol: str) -> None:
        stop = self._sim_stops.get(symbol)
        if stop:
            stop.set()
        thread = self._sim_threads.get(symbol)
        if thread:
            thread.join(timeout=10)
        self._sim_runners.pop(symbol, None)
        self._sim_threads.pop(symbol, None)
        self._sim_stops.pop(symbol, None)
        self.scanner.mark_inactive(symbol)

    def _stop_live_runner(self, symbol: str) -> None:
        stop = self._live_stops.get(symbol)
        if stop:
            stop.set()
        thread = self._live_threads.get(symbol)
        if thread:
            thread.join(timeout=15)
        self._live_runners.pop(symbol, None)
        self._live_threads.pop(symbol, None)
        self._live_stops.pop(symbol, None)

    def _stop_all(self) -> None:
        for sym in list(self._live_runners.keys()):
            self._stop_live_runner(sym)
        for sym in list(self._sim_runners.keys()):
            self._stop_sim_runner(sym)

    def _cleanup_dead_threads(self) -> None:
        for store, threads, stops, do_scanner in [
            (self._sim_runners, self._sim_threads, self._sim_stops, True),
            (self._live_runners, self._live_threads, self._live_stops, False),
        ]:
            dead = [sym for sym, t in threads.items() if not t.is_alive()]
            for sym in dead:
                store.pop(sym, None)
                threads.pop(sym, None)
                stops.pop(sym, None)
                if do_scanner:
                    self.scanner.mark_inactive(sym)

    def _apply_patch_to_config(self, cfg: Config, patch: Dict[str, Any]) -> None:
        for key, val in patch.items():
            if hasattr(cfg, key):
                try:
                    cur = getattr(cfg, key)
                    if isinstance(cur, Decimal):
                        setattr(cfg, key, Decimal(str(val)))
                    elif isinstance(cur, int):
                        setattr(cfg, key, int(val))
                    elif isinstance(cur, float):
                        setattr(cfg, key, float(val))
                    elif isinstance(cur, bool):
                        setattr(cfg, key, bool(val))
                    else:
                        setattr(cfg, key, val)
                except Exception:
                    pass

    def _load_symbol_filters(self, cfg: Config, client: ExchangeClient, filt: SymbolFilters) -> None:
        info = client.get("/fapi/v1/exchangeInfo")
        if not info or "symbols" not in info:
            return
        for s in info["symbols"]:
            if s.get("symbol") != cfg.SYMBOL:
                continue
            for f_ in s.get("filters", []):
                if f_.get("filterType") == "LOT_SIZE":
                    try:
                        filt.min_qty = d(f_["minQty"])
                        filt.qty_step = d(f_["stepSize"])
                    except Exception:
                        pass
                if f_.get("filterType") in ("PRICE_FILTER", "PRICE"):
                    try:
                        tick = f_.get("tickSize")
                        if tick:
                            filt.price_tick = d(tick)
                    except Exception:
                        pass

    def _set_leverage(self, cfg: Config, client: ExchangeClient) -> None:
        if cfg.SIMULATION_MODE:
            return
        for attempt in range(3):
            r = client.signed("POST", "/fapi/v1/leverage",
                              {"symbol": cfg.SYMBOL, "leverage": str(cfg.LEVERAGE)})
            if isinstance(r, dict) and ("leverage" in r or "symbol" in r):
                return
            if is_sig_error(r):
                client.sync_time()
                time.sleep(0.3)
            else:
                break
