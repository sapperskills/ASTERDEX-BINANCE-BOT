#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    parser = argparse.ArgumentParser(description="Merge a generated config patch into an existing config.json")
    parser.add_argument("--config", required=True, help="Path to existing config.json")
    parser.add_argument("--patch", required=True, help="Path to generated patch file")
    parser.add_argument("--out", default="", help="Optional output path; defaults to <config stem>_patched.json")
    args = parser.parse_args()

    config_path = Path(args.config)
    patch_path = Path(args.patch)
    cfg = load_json(config_path)
    patch = load_json(patch_path)

    if "patch" in patch and isinstance(patch["patch"], dict):
        updates = patch["patch"]
    elif "strategy_patch" in patch and isinstance(patch["strategy_patch"], dict):
        updates = patch["strategy_patch"]
    else:
        updates = patch

    for key, value in updates.items():
        cfg[key] = value

    out_path = Path(args.out) if args.out else config_path.with_name(f"{config_path.stem}_patched.json")
    out_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    print(f"Wrote merged config to: {out_path}")


if __name__ == "__main__":
    main()
