#!/usr/bin/env python3
"""
Unified v5.0 — Sim-to-Live Promotion Trading Engine (Aster / Binance)

Supports both Aster DEX and Binance Futures via the same /fapi/ endpoints.
Set BASE_URL in config.json to select exchange:
  Aster:   https://fapi.asterdex.com
  Binance: https://fapi.binance.com

How it works:
    --sim (SIMULATION_MODE=true):
        Scans all markets for breakouts, paper-trades them, builds up
        per-symbol performance data (win rate, PF, drawdown). No real
        money is used. Run this first to let the engine learn.

    Without --sim (SIMULATION_MODE=false in config.json):
        Breakouts are STILL sim-traded first as a proving ground. When
        a symbol passes the promotion gates (default: 5 trades, 55% WR,
        1.2x PF), it is automatically promoted to LIVE with real orders.
        If live performance degrades, the symbol is demoted back to sim.

        The sim engine runs in parallel at all times — it's the pipeline
        that feeds proven opportunities into live trading.

Modes:
    python run_unified.py --sim                    # Pure sim (learn markets)
    python run_unified.py                          # Hybrid sim→live (auto-promote)
    python run_unified.py --single BTCUSDT         # Single-symbol mode
    python run_unified.py --research               # Research scan only

Environment variables:
    MAX_SYMBOLS         Max concurrent LIVE symbols (default: 3)
    MAX_SIM_SYMBOLS     Max concurrent SIM symbols (default: 8)
    MAX_PORTFOLIO_LOSS  Daily portfolio loss limit USD (default: 100)
    SCAN_INTERVAL       Seconds between market scans (default: 30)
    BREAKOUT_THRESHOLD  Min breakout score to trade (default: 0.45)
    MIN_SIM_TRADES      Sim trades needed for promotion (default: 5)
    MIN_SIM_WR          Min sim win rate for promotion (default: 0.55)
    MIN_SIM_PF          Min sim profit factor for promotion (default: 1.20)
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from decimal import getcontext

getcontext().prec = 28

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(name)-20s %(message)s",
    datefmt="%m-%d %H:%M:%S",
)
LOG = logging.getLogger("aster")


def run_single_symbol(config_path: str, symbol: str = "") -> None:
    """Run original single-symbol mode (backward compatible)."""
    from core.config import Config, load_config_json, per_symbol_paths

    cfg = Config()
    load_config_json(cfg, config_path)
    if symbol:
        cfg.SYMBOL = symbol.strip().upper()
    per_symbol_paths(cfg)

    import run as original_run
    sys.argv = [sys.argv[0], config_path]
    original_run.main()


def run_multi_symbol(config_path: str) -> None:
    """Run the sim-to-live multi-symbol orchestrator."""
    from core.config import Config, load_config_json, load_json_file
    cfg = Config()
    load_config_json(cfg, config_path)
    if getattr(cfg, "DASHBOARD_AUTOSTART", False):
        try:
            from dashboard_web import start_dashboard_server
            if start_dashboard_server(getattr(cfg, "DASHBOARD_HOST", "127.0.0.1"), int(getattr(cfg, "DASHBOARD_PORT", 8765))):
                LOG.info("Dashboard web started at http://%s:%s", getattr(cfg, "DASHBOARD_HOST", "127.0.0.1"), int(getattr(cfg, "DASHBOARD_PORT", 8765)))
        except Exception as e:
            LOG.warning("Dashboard autostart failed: %s", e)
    from orchestrator import MultiSymbolOrchestrator
    orch = MultiSymbolOrchestrator(base_config_path=config_path)
    orch.run()


def run_research(config_path: str, interval: str, limit: int, top_n: int, out_dir: str, symbols: str) -> None:
    """Run research scan only."""
    from research import run_research_engine
    from core.config import Config, load_config_json

    cfg = Config()
    load_config_json(cfg, config_path)

    sym_list = [s.strip().upper() for s in symbols.split(",") if s.strip()] if symbols else None
    result = run_research_engine(
        out_dir=out_dir,
        interval=interval,
        kline_limit=limit,
        top_n=top_n,
        symbols=sym_list,
        base_url=cfg.BASE_URL,
    )
    print(json.dumps(result, indent=2))
    print(f"\nWrote outputs to: {os.path.abspath(out_dir)}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Unified v5.0 — Sim-to-Live Promotion Trading Engine (Aster / Binance)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--config", default="config.json", help="Path to base config.json")
    parser.add_argument("--sim", action="store_true",
                        help="Pure simulation mode — no live orders, just learn")

    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--single", metavar="SYMBOL", help="Single-symbol mode (e.g. BTCUSDT or ASTERUSDT)")
    mode.add_argument("--research", action="store_true", help="Run research scan only")
    mode.add_argument("--multi", action="store_true",
                      help="Multi-symbol sim→live mode")

    parser.add_argument("--interval", default="5m", help="Kline interval for research")
    parser.add_argument("--limit", type=int, default=288, help="Klines per symbol for research")
    parser.add_argument("--top", type=int, default=25, help="Top N symbols in research output")
    parser.add_argument("--out", default="research_output", help="Research output directory")
    parser.add_argument("--symbols", default="", help="Comma-separated symbol filter")

    args = parser.parse_args()

    temp_config_path = None
    from core.config import Config, load_config_json, load_json_file

    # Handle --sim flag: create temp config with SIMULATION_MODE=true
    if args.sim:
        os.environ["UNIFIED_SIM"] = "1"
        import json as _json
        import tempfile
        raw = load_json_file(args.config)
        raw["SIMULATION_MODE"] = True
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, dir=".") as tf:
            _json.dump(raw, tf, indent=2)
            temp_config_path = tf.name
            args.config = tf.name
        LOG.info("SIMULATION MODE — all trading is paper, building performance data")
    else:
        # Verify config has SIMULATION_MODE=false for live
        import json as _json
        raw = load_json_file(args.config)
        if raw.get("SIMULATION_MODE", True):
            LOG.info("Config has SIMULATION_MODE=true — running as pure sim.")
            LOG.info("Set SIMULATION_MODE=false in config.json + add API keys for live promotion.")
    cfg_boot = Config()
    load_config_json(cfg_boot, args.config)

    print()
    print("=" * 66)
    print("  Unified Trading Engine v5.0 (Aster / Binance)")
    print("  Sim-to-Live Promotion Trading Engine")
    print("=" * 66)
    if args.sim:
        print("  Mode: PURE SIMULATION — building breakout performance data")
    elif not args.single and not args.research:
        print("  Mode: HYBRID SIM→LIVE — proven breakouts auto-promoted to live")
    print()

    try:
        if args.single:
            LOG.info("Mode: SINGLE SYMBOL (%s)", args.single)
            run_single_symbol(args.config, args.single)
        elif args.research:
            LOG.info("Mode: RESEARCH SCAN")
            run_research(args.config, args.interval, args.limit, args.top, args.out, args.symbols)
        else:
            LOG.info("Mode: MULTI-SYMBOL SIM→LIVE PIPELINE")
            run_multi_symbol(args.config)
    finally:
        if temp_config_path and os.path.exists(temp_config_path):
            try:
                os.remove(temp_config_path)
            except OSError:
                LOG.warning("Failed to remove temp config: %s", temp_config_path)


if __name__ == "__main__":
    main()
